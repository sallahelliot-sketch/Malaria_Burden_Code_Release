# Changelog

## 2.0.0 — 2026-10-14 (revision in response to peer review)

### Added
- `src/malaria_burden/revision.py`: analyses for manuscript Sections 4.7–4.9 and Appendices G–L
  - gradient boosting and random forest under all seven evaluation regimes, with nested tuning (reviewer C4);
  - Platt and isotonic recalibration of Naïve Bayes (and logistic regression), nested in training folds (C3);
  - thresholds fixed from training years only: 2003–2018 and 2003–2009 medians, fold-specific and expanding-window (C2);
  - one family of 28 persistence-versus-learner tests with Holm and Bonferroni adjustment (M6);
  - minimal detectable differences and simulated power of the paired label comparison (M7);
  - external grounding against the High Burden to High Impact list, estimated death counts and reported cases (C1, M8);
  - a prospective review-targeting scenario on rolling-origin predictions (C1);
  - a continuous-rate companion scored by CRPS (M9).
- `data/external/`: archived GHO extracts `MALARIA_EST_DEATHS.json` and `MALARIA_TOTAL_CASES.json`.
- Tables 9–10, G1–G2, H1, I1, J1–J2, K1–K2, L1; Figures 9, 10 and J1.
- 32 consistency checks (181 in total) and a unit test of the revision helpers.
- Notebook section 11 runs the revision analyses.

### Fixed
- `pipeline.py`: `data_audit.json` and `results.json` are written as UTF-8. On Windows the default code page could not
  encode characters such as "≤", and the run stopped after the analyses had finished.
- Equation numbers cited in docstrings and comments now match the manuscript.

### Unchanged
- Every primary result. The complete pipeline was re-executed under Python 3.14.3 (NumPy 2.5.4, pandas 3.0.6,
  SciPy 1.18.1, scikit-learn 1.9.1) and reproduced every value reported in version 1.0.0 (8,090 of 8,092 stored values identical; two unreported
  audit values differ in the fourth decimal).

## 1.0.0 — 2026-10-11
- Initial release accompanying the submitted manuscript.
