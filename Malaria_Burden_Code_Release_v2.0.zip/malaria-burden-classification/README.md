# Leakage-Controlled Classification of National Malaria Mortality Burden

**Naïve Bayes, logistic regression and a persistence benchmark on World Health Organization estimates**

This repository is the complete, self-verifying code release for the study *Leakage-Controlled Classification of
National Malaria Mortality Burden From World Health Organization Estimates: Naïve Bayes, Logistic Regression and a
Persistence Benchmark*. One command rebuilds the analytical dataset from the archived WHO export, reruns every
experiment, writes every table and figure of the manuscript and its supplementary appendices, and finishes with
181 automated consistency checks.

> **Version 2.0.0 (revision).** Adds the analyses requested in peer review (manuscript Sections 4.7–4.9,
> Appendices G–L): gradient boosting and random forest under all seven regimes, Platt and isotonic recalibration of
> Naïve Bayes, thresholds fixed from training years only, all 28 persistence-versus-learner tests with Holm and
> Bonferroni adjustment, power analysis, external grounding (High Burden to High Impact list, estimated death counts,
> reported cases), a prospective review-targeting scenario and a continuous-rate companion scored by CRPS. It also
> fixes a Windows-only failure (JSON audit files are now written as UTF-8). See `CHANGELOG.md`.

---

## Key findings

| | Naïve Bayes | Logistic regression | Lagged-rate logistic model | Persistence rule |
|---|---:|---:|---:|---:|
| Hold-out accuracy (592 records) | 95.27 % | 96.79 % | 97.97 % | 98.14 % |
| 10-fold CV accuracy (M ± SD) | 95.94 ± 1.42 | 97.41 ± 1.23 | 97.92 ± 0.81 | 97.77 ± 0.84 |
| Country-grouped CV accuracy | 96.00 % | 97.01 % | 97.87 % | 97.77 % |
| Rolling-origin accuracy, 2010–2024 | 95.99 % | 97.18 % | 98.00 % | 97.77 % |
| Hold-out logarithmic loss | 0.6287 | 0.0995 | 0.0723 | n/r |
| Hold-out calibration slope | 0.27 | 1.35 | 1.31 | n/r |
| AUC of uncertainty for class transitions | .754 | .887 | .944 | n/r |

1. **Logistic regression is the better of the two learners.** Across ten matched folds it exceeds Naïve Bayes in
   accuracy, precision, F1 and AUC after Holm correction, with equal recall, and its logarithmic loss is about six
   times lower. Naïve Bayes places 96.79 % of its hold-out probabilities below .01
   or above .99 (calibration slope 0.27).
2. **A rule that fits nothing is at least as accurate as both.** Carrying last year's class forward matches or
   exceeds both learners in all seven evaluation regimes. It significantly exceeds Naïve Bayes wherever tested and is
   never significantly outperformed by logistic regression (repeated 10×10 CV, corrected resampled *t*:
   persistence − LR = +0.42 points,
   *p* = .249).
3. **The reason is inertia.** The year-*t* rate correlates .991 with the rate at
   *t* − 1, and only 44 of 1,973 country-years (2.23 %) change
   class between consecutive observations. Persistence is wrong on exactly those transitions and right everywhere else.
4. **What a fitted model adds is calibrated uncertainty.** Logistic-regression uncertainty ranks transitions above
   stable records (AUC = .887); reviewing the least certain 5 % of
   country-years captures 18 of the 44 transitions,
   about eight times the yield of random review.
5. **More capacity does not help (added in revision).** Gradient boosting and a random forest approach persistence by
   imitating it and never exceed it significantly; across all 28 persistence-versus-learner tests no learner is
   significantly more accurate, before or after family-wise adjustment, also when the threshold is fixed from training
   years only.
6. **Prospectively, the simplest calibrated model targets review best (added in revision).** Reviewing the five least
   certain country-years per year (2010–2024, trained on earlier years only), the one-variable lagged-rate model
   captures far more class transitions than logistic regression; the transitions track routinely reported cases.

---

## Repository structure

```
.
├── README.md                     this file
├── requirements.txt              pinned dependencies (exact versions used for the published results)
├── LICENSE                       MIT licence for the code (the WHO data keep WHO's terms)
├── CITATION.cff                  citation metadata
├── CHANGELOG.md                  what changed between versions
├── data/
│   ├── DATA.md                   provenance, schema, access routes, cleaning, licence
│   ├── data_raw_WHO_malaria_mortality.xlsx   WHO GHO export, unmodified
│   └── external/                 GHO extracts used for external grounding (deaths, reported cases)
├── src/malaria_burden/           the analysis package
│   ├── config.py                 every constant (seed, partitions, grids) declared once
│   ├── data.py                   acquisition, cleaning, lagged features, leakage gate, descriptives
│   ├── models.py                 Naïve Bayes, logistic regression, persistence rule
│   ├── metrics.py                discrimination, Brier, log loss, ECE, calibration slope/intercept
│   ├── inference.py              McNemar, DeLong, paired bootstrap, fold t, Holm, corrected resampled t
│   ├── experiments.py            every experiment reported in the paper
│   ├── revision.py               analyses added in peer review (Appendices G–L)
│   ├── pipeline.py               end-to-end orchestration and audit-file export
│   ├── figures.py                every figure (drawn from computed objects, never transcribed numbers)
│   ├── tables.py                 every table, formatted as reported
│   └── checks.py                 the automated consistency audit
├── scripts/
│   └── run_analysis.py           one command reproduces everything
├── notebooks/
│   └── malaria_burden_classification.ipynb   step-by-step walk-through (same functions, same results)
└── tests/
    └── test_pipeline.py          fast tests of record accounting, leakage gate and metrics
```

`results/` and `data/cleaned_WHO_malaria_dataset.xlsx` are created on the first run and are git-ignored.

---

## The dataset

| Item | Value |
|---|---|
| Publisher | World Health Organization, Global Health Observatory (GHO) |
| Indicator | Estimated malaria mortality rate (per 100 000 population) |
| Indicator code | `MALARIA_EST_MORTALITY` |
| Unit | Deaths per 100,000 population (modelled estimate with lower and upper uncertainty bounds) |
| Export analysed | 2,659 records × 34 fields; 110 countries; 2000–2024; WHO last-modified date 2025-12-19 |
| Spatial unit | Country (the export contains country records only) |

**Links**

- GHO portal: <https://www.who.int/data/gho>
- GHO malaria theme: <https://www.who.int/data/gho/data/themes/malaria>
- OData endpoint (machine-readable): <https://ghoapi.azureedge.net/api/MALARIA_EST_MORTALITY>
- OData API documentation: <https://www.who.int/data/gho/info/gho-odata-api>
- World Malaria Report series (context for the estimates): <https://www.who.int/teams/global-malaria-programme/reports>

The exact export used for the published results is included in `data/`, so the analysis reproduces offline. The
loader falls back to the OData API only if that file is absent; WHO revises the estimates periodically, so a fresh
download may differ from the archived export. See [`data/DATA.md`](data/DATA.md) for the field mapping and both
access routes.

### From export to analytical dataset

| Stage | Action | Before | After | Removed |
|---|---|---:|---:|---:|
| Source | GHO export, `MALARIA_EST_MORTALITY` | — | 2,659 | — |
| Step 1 | Removed duplicate country-year keys | 2,659 | 2,659 | 0 |
| Step 2 | Removed records missing the estimate or either bound | 2,659 | 2,658 | 1 |
| Step 3 | Removed 19 countries with a zero rate in every year | 2,658 | 2,243 | 415 |
| Step 4 | Removed each country's first 3 observed years | 2,243 | 1,973 | 270 |
| Final | Analytical dataset | — | 1,973 | — |

No value is imputed. The final reduction follows from the feature map: the three-year trend needs three earlier
observations, so each of the 90 retained countries loses its first three.

| Property | Value |
|---|---|
| Records | 1,973 country-years |
| Countries / WHO regions | 90 / 5 |
| Years | 2003–2024 |
| Label | `HighBurden` = 1 if the year-*t* rate ≥ τ = 4.88 (sample median) |
| Class balance | High 987 · Low 986 |
| Class transitions | 44 (17 low→high, 27 high→low) |

| WHO region | Records | Countries | High-burden | Prevalence | Transitions |
|---|---:|---:|---:|---:|---:|
| Africa | 986 | 45 | 819 | 83.1 % | 23 |
| Americas | 417 | 19 | 13 | 3.1 % | 10 |
| Western Pacific | 240 | 11 | 63 | 26.2 % | 7 |
| South-East Asia | 176 | 8 | 19 | 10.8 % | 2 |
| Eastern Mediterranean | 154 | 7 | 73 | 47.4 % | 2 |

### Variables and the leakage gate

| Field | Role | Definition |
|---|---|---|
| `WHO_Region` | Predictor | WHO region, one-hot encoded (5 indicators) |
| `Year` | Predictor | Reporting year *t* |
| `Prev_Rate` | Predictor | Rate at the preceding observation, *r*(*c*, *t*−1) |
| `Prev_Width` | Predictor | Interval width at the preceding observation |
| `Trend_3yr` | Predictor | *r*(*c*, *t*−1) − *r*(*c*, *t*−3): change across the three most recent observations |
| `Baseline_Rate` | Predictor | Rate at the country's first observation in the export |
| `MortalityRate`, `Rate_Low`, `Rate_High`, `Interval_Width` | **Excluded** | Year-*t* quantities; they construct the label |
| `HighBurden` | Target | 1 if `MortalityRate` ≥ τ |

Because the label is a deterministic function of `MortalityRate`, any year-*t* field would return the answer rather
than predict it. `build_design_matrix()` asserts that none of the four excluded fields reaches the design matrix and
halts the pipeline otherwise. For 1,970 records the preceding
observation is year *t* − 1; for 3 zero-rate records (China 2022
and 2024, French Guiana 2024) the export omits a year and the preceding observation is *t* − 2.

---

## Method in brief

- **Learners:** Gaussian Naïve Bayes (priors by relative frequency) and L2-penalised logistic regression (C = 1,
  lbfgs, 2,000 iterations), both on inputs standardised inside each training partition; decision threshold 0.5; no
  hyperparameter search in the primary analyses.
- **Reference rules:** persistence 1(*r*(*c*, *t*−1) ≥ τ); a lagged-rate logistic model on log(1 + previous rate);
  majority class; stratified random.
- **Evaluation regimes:** stratified 70/30 hold-out (1,381 / 592); stratified 10-fold CV; repeated 10×10 CV;
  country-grouped 10-fold CV; country-disjoint 70/30 split (63 / 27 countries); prospective split (≤2018 | ≥2019);
  rolling origin (train on all earlier years, test each year 2010–2024).
- **Inference:** exact McNemar, DeLong, 10,000-replicate paired bootstrap, paired fold *t* with Holm correction,
  Nadeau–Bengio corrected resampled *t* for repeated CV.
- **Probabilistic quality:** Brier score, logarithmic loss, expected calibration error (10 bins), calibration slope
  and calibration-in-the-large.
- **Transitions and review:** accuracy on class transitions versus stable records; AUC of the uncertainty
  −|*p* − 0.5| for transitions; risk–coverage (deferral) analysis.
- **Sensitivity:** thresholds at the 25th–75th percentiles; ablations; leave-one-out refitting; permutation
  importance; bootstrap coefficient intervals; log-transformed inputs; nested tuning; learning curves; runtime.

---

## Getting started

```bash
# 1. obtain the code (clone this repository or download it as a ZIP) and enter its folder
cd malaria-burden-classification

# 2. create an environment and install the pinned dependencies
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt

# 3. reproduce every number, table and figure (about 4 minutes for the primary analyses
#    plus about 20 minutes for the revision analyses, mostly the tree ensembles)
python scripts/run_analysis.py

# optional: the step-by-step notebook (identical results)
jupyter lab notebooks/malaria_burden_classification.ipynb

# optional: fast tests
pytest -q            # or: python tests/test_pipeline.py
```

The paired bootstrap (10,000 replicates) accounts for most of the runtime.

### What a run produces

| Output | Contents |
|---|---|
| `data/cleaned_WHO_malaria_dataset.xlsx` | Analytical dataset, data dictionary, cleaning summary |
| `results/data_audit.json` | Every dataset figure: provenance, accounting, descriptives, regions, transitions |
| `results/results.json` | Every performance, inference, calibration, robustness and sensitivity figure |
| `results/tables/table_*.csv`, `all_tables.xlsx` | Every table, formatted as reported (Tables 1–10 and A1–L1) |
| `results/figures/*.png` | Every figure at 300 dpi (Figures 1–10, B1–F1 and J1) |
| `results/consistency_checks.txt` | The automated audit, one line per check |

### Where each exhibit comes from

| Exhibit | Function |
|---|---|
| Table 1, Figure 1, Figure 2 | `data.build_dataset`, `data.describe_sample`, `figures.fig_framework`, `figures.fig_sample_structure` |
| Tables 3–4, Figures 3–4 | `experiments.run_holdout` |
| Table 5 | `experiments.run_cv` |
| Table 6, Figure 5 | `run_repeated_cv`, `run_grouped_cv`, `run_robustness`, `run_rolling_origin` |
| Table 7, Figure 6 | `run_transitions`, `run_selective` |
| Figure 7, Table E1 | `run_threshold_sensitivity` |
| Table 8, Figure 8 | `run_contribution` |
| Tables E2–E3, Figure E1 | `run_contribution`, `run_learner_sensitivity`, `run_learning_curve` |
| Tables F1–F3, Figure F1 | `run_error_localisation`, `run_selective`, `run_timing` |
| Table 9, Figure 9, Tables G1–G2, H1 | `revision.run_flexible`, `revision.run_recalibration` |
| Table I1 | `revision.run_anchored_threshold` |
| Tables J1–J2, Figure J1 | `revision.run_multiplicity`, `revision.run_power` |
| Table 10, Figure 10, Tables K1–K2 | `revision.run_external`, `revision.run_review_scenario` |
| Table L1 | `revision.run_continuous` |

---

## Reproducibility

| Control | Setting |
|---|---|
| Seed | 1992 for every stochastic step (splits, folds, bootstrap, permutations, learning-curve subsamples, random rule) |
| Standardisation | Re-estimated inside every training partition |
| Test-set use | Hold-out labels scored once, after the protocol was fixed; no configuration selected on evaluated data |
| Executed environment | Python 3.13.16; NumPy 2.5.3; pandas 3.0.5; SciPy 1.18.1; scikit-learn 1.9.1; Matplotlib 3.11.2; openpyxl 3.1.5 (version 2.0 re-executed on Windows with Python 3.14.3, NumPy 2.5.4, pandas 3.0.6) |
| Audit | 181 automated checks at the end of every run; any failure raises |

With the pinned versions a clean run reproduces every reported value; the notebook and the script produce identical
`results.json` files apart from the runtime measurements, which depend on hardware.

---

## Citation

Please cite the study (see `CITATION.cff`) and the World Health Organization as the source of the estimates:

> World Health Organization. *Global Health Observatory: Estimated malaria mortality rate (per 100 000 population)*
> (indicator `MALARIA_EST_MORTALITY`). Geneva: World Health Organization. <https://www.who.int/data/gho>

## Licence

Code and notebook: MIT (see `LICENSE`). The WHO data keep WHO's own terms of use (see `data/DATA.md`) and are not
covered by the code licence.

## Scope

The outcome is a modelled estimate dichotomised at a sample median, the predictors come from one annual national
indicator, and validation is internal to the WHO series. The code supports statements about association and
predictive margin, not causation. These limits are discussed in the manuscript.

## Contact

Martin Konadu Boamah, Department of Information Technology Education, Faculty of Technical Education, University of
Skills Training and Entrepreneurial Development (USTED), Kumasi, Ghana.
