# Data

## Contents

| File | Description | Tracked |
|---|---|---|
| `data_raw_WHO_malaria_mortality.xlsx` | WHO Global Health Observatory export, exactly as downloaded | yes |
| `cleaned_WHO_malaria_dataset.xlsx` | Analytical dataset written by every run (data, dictionary, cleaning summary) | no (generated) |
| `external/MALARIA_EST_DEATHS.json` | GHO OData extract, estimated number of malaria deaths (external grounding, Appendix K) | yes |
| `external/MALARIA_TOTAL_CASES.json` | GHO OData extract, reported malaria cases, presumed + confirmed (external grounding, Appendix K) | yes |

## Provenance

| Item | Value |
|---|---|
| Publisher | World Health Organization, Global Health Observatory |
| Indicator | Estimated malaria mortality rate (per 100 000 population) |
| Indicator code | `MALARIA_EST_MORTALITY` |
| Unit | Deaths per 100,000 population |
| Records / fields | 2,659 / 34 |
| Countries / years | 110 / 2000–2024 |
| WHO last-modified date in the export | 2025-12-19 |

The indicator is a **modelled estimate**, not a death count. Each country-year carries a point estimate and the lower
and upper bounds of its uncertainty interval; intervals are widest where civil registration is weakest.

## Obtaining the data yourself

### Route A: OData API (no account or key)

```python
import pandas as pd
records = pd.DataFrame(list(pd.read_json(
    "https://ghoapi.azureedge.net/api/MALARIA_EST_MORTALITY")["value"]))
country = records[records["SpatialDimType"] == "COUNTRY"]
```

| API field | Used as |
|---|---|
| `SpatialDim` | `Country` (ISO3 code) |
| `ParentLocation` | `WHO_Region` |
| `TimeDim` | `Year` |
| `NumericValue` | `MortalityRate` |
| `Low` / `High` | `Rate_Low` / `Rate_High` |

Documentation: <https://www.who.int/data/gho/info/gho-odata-api>

### Route B: portal export

1. Open <https://www.who.int/data/gho/data/themes/malaria>.
2. Select *Estimated malaria mortality rate (per 100 000 population)*.
3. Export as `.xlsx` and save it here as `data_raw_WHO_malaria_mortality.xlsx`.

The export starts with two rows describing the applied filters, so the loader reads it with `skiprows=2`. Columns used:

| Export column | Used as |
|---|---|
| `Location` | `Country` |
| `ParentLocation` | `WHO_Region` |
| `Period` | `Year` |
| `FactValueNumeric` | `MortalityRate` |
| `FactValueNumericLow` / `FactValueNumericHigh` | `Rate_Low` / `Rate_High` |
| `Location type` | filter: `Country` only |

The loader raises an error if any of these columns is missing, which signals a change in the export schema. WHO revises
the estimates periodically; the archived export is the authority for the published results.

## Cleaning performed by the code

| Step | Action | Before | After | Removed |
|---|---|---:|---:|---:|
| 1 | Removed duplicate country-year keys | 2,659 | 2,659 | 0 |
| 2 | Removed records missing the estimate or either bound | 2,659 | 2,658 | 1 |
| 3 | Removed 19 countries with a zero rate in every year | 2,658 | 2,243 | 415 |
| 4 | Removed each country's first 3 observed years | 2,243 | 1,973 | 270 |

The 19 countries removed at step 3 report a zero estimate in every year:
Armenia, Azerbaijan, Democratic People's Republic of Korea, Egypt, El Salvador, Georgia, Iraq, Kazakhstan, Kyrgyzstan, Morocco, Oman, Paraguay, Saudi Arabia, Syrian Arab Republic, Tajikistan, Turkmenistan, Türkiye, United Arab Emirates, Uzbekistan.

No value is imputed. The four year-*t* fields (`MortalityRate`, `Rate_Low`, `Rate_High`, `Interval_Width`) remain in
the cleaned workbook because they define the label and stratify error reporting, but an assertion prevents them from
entering any model.

## External series used for grounding (added in version 2.0)

Two further GHO indicators were downloaded unmodified from the OData API on 2026-10-14 (WHO last-modified date
2025-12-19) and archived in `external/`. The loader (`revision.load_gho_series`) reads the archived file and falls back
to the API only if it is absent. Countries are matched by ISO3 code (`SpatialDimValueCode` in the mortality export,
`SpatialDim` in the API); all 90 analysed countries match.

| File | Indicator | Coverage | Use |
|---|---|---|---|
| `MALARIA_EST_DEATHS.json` | Estimated number of malaria deaths | 110 countries, 2000–2024 | 95%-of-deaths stratum; deaths in transition country-years |
| `MALARIA_TOTAL_CASES.json` | Total malaria cases reported by national programmes (presumed + confirmed) | 103 countries, 2015–2024 | direction of reported cases around class transitions |

The High Burden to High Impact country list (WHO and RBM Partnership to End Malaria, 2018) is declared in `config.py`.

Two candidate references could not be archived. The GHO indicator *Malaria – number of reported deaths*
(`MALARIA001`) returns no records through the API, and the IHME Global Burden of Disease malaria estimates are
distributed under terms that prohibit redistribution. Users with GBD access can compare the transitions with those
estimates by adapting `revision.run_external`.

## Licence

WHO makes Global Health Observatory content available under its own terms of use (Creative Commons
Attribution-NonCommercial-ShareAlike 3.0 IGO for most GHO data). Check the current terms on the WHO website before
redistributing the export or derivatives. The copy here is unmodified and is included only so that the analysis
reproduces exactly.
