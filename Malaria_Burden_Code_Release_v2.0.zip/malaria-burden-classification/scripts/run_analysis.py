#!/usr/bin/env python
"""Reproduce every number, table and figure of the study from the archived WHO export.

Usage (from the repository root):
    python scripts/run_analysis.py

Outputs (all regenerated on every run):
    data/cleaned_WHO_malaria_dataset.xlsx   analytical dataset, data dictionary, cleaning summary
    results/data_audit.json                 every dataset figure
    results/results.json                    every performance and inference figure
    results/tables/table_*.csv              every table, formatted as reported
    results/tables/all_tables.xlsx          the same tables in one workbook
    results/figures/*.png                   every figure (300 dpi)
    results/consistency_checks.txt          the automated audit, one line per check
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import pandas as pd  # noqa: E402

from malaria_burden import config as C  # noqa: E402
from malaria_burden.checks import check_all  # noqa: E402
from malaria_burden.figures import make_all  # noqa: E402
from malaria_burden.pipeline import run_all  # noqa: E402
from malaria_burden.tables import build_all  # noqa: E402


def main() -> None:
    audit, results, state = run_all(verbose=True)
    figures = make_all(audit, results, state)
    print(f"figures written: {len(figures)}")
    tables = build_all(audit, results, write=True)
    with pd.ExcelWriter(C.TABLE_DIR / "all_tables.xlsx", engine="openpyxl") as writer:
        for key, t in tables.items():
            pd.DataFrame(t["rows"], columns=t["columns"]).to_excel(writer, sheet_name=f"Table {key}", index=False)
    print(f"tables written: {len(tables)}")
    checks = check_all(audit, results, state, figure_paths=figures, verbose=True)
    (C.RESULTS_DIR / "consistency_checks.txt").write_text(
        "\n".join(f"{'PASS' if ok else 'FAIL'}  {msg}" for ok, msg in checks) + "\n", encoding="utf-8")
    h = results["holdout"]
    print(f"\nanalytical dataset : {audit['final_rows']} records, {audit['final_countries']} countries, "
          f"{audit['final_year_range'][0]}-{audit['final_year_range'][1]}, threshold {audit['median_threshold']:.2f}")
    for n in ("NB", "LR"):
        print(f"hold-out {n:<3}       : accuracy {h[n]['accuracy']:.2f}%, AUC {h[n]['auc']:.4f}, "
              f"log loss {h['calibration'][n]['log_loss']:.4f}")
    print(f"persistence rule   : accuracy {h['baselines']['persistence']['accuracy']:.2f}%")


if __name__ == "__main__":
    main()
