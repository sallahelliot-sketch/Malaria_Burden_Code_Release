"""Leakage-controlled classification of national malaria mortality burden.

Naive Bayes versus logistic regression on the World Health Organization Global Health
Observatory indicator MALARIA_EST_MORTALITY, benchmarked against a persistence rule.
"""
__version__ = "1.0.0"
