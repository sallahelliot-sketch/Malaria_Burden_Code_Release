"""Automated internal-consistency audit.

Every check compares two independently computed quantities that must agree. A clean run
of check_all() is the evidence that the tables, figures and audit files share one
evidence trail. Any failure raises AssertionError.
"""
from __future__ import annotations

import numpy as np

from . import config as C

TOL = 5e-4  # stored values are rounded to four decimals


def check_all(audit: dict, results: dict, state: dict, figure_paths=None, verbose: bool = True) -> list:
    S = state["study"]
    checks: list[tuple[bool, str]] = []

    def check(ok, msg):
        checks.append((bool(ok), msg))

    h = results["holdout"]
    # ---------------- dataset accounting
    steps = audit["cleaning_steps"]
    check(steps[0]["before"] == audit["raw_rows"], "cleaning starts from the raw record count")
    check(all(steps[i]["after"] == steps[i + 1]["before"] for i in range(len(steps) - 1)),
          "each cleaning step starts where the previous ended")
    check(all(s["before"] - s["after"] == s["removed"] for s in steps), "removed counts reconcile")
    check(steps[-1]["after"] == audit["final_rows"] == len(S.y), "final record count reconciles")
    check(audit["class_counts"]["High"] + audit["class_counts"]["Low"] == audit["final_rows"],
          "class counts sum to the analytical sample")
    check(sum(r["records"] for r in audit["region_table"]) == audit["final_rows"], "regional records sum")
    check(sum(r["high_burden"] for r in audit["region_table"]) == audit["class_counts"]["High"],
          "regional high-burden counts sum")
    check(sum(r["countries"] for r in audit["region_table"]) == audit["final_countries"], "regional countries sum")
    check(sum(r["transitions"] for r in audit["region_table"]) == audit["transitions"]["n"], "regional transitions sum")
    check(audit["transitions"]["low_to_high"] + audit["transitions"]["high_to_low"] == audit["transitions"]["n"],
          "transition directions sum")
    check(steps[-1]["removed"] == C.MIN_HISTORY_YEARS * audit["final_countries"],
          "history reduction equals three years per retained country")
    check(sum(y["records"] for y in audit["by_year"]) == audit["final_rows"], "records by year sum")
    check(audit["lag_gap"]["records_previous_observation_is_t_minus_1"]
          + audit["lag_gap"]["records_previous_observation_is_earlier"] == audit["final_rows"], "lag-gap audit sums")

    # ---------------- leakage gate
    check(not set(S.features) & set(C.LEAKAGE_EXCLUDED), "no year-t quantity among the features")
    check(len(S.features) == 10, "design matrix has ten columns")

    # ---------------- partitions
    check(len(S.idx_train) + len(S.idx_test) == len(S.y), "hold-out partition is exhaustive")
    check(len(set(S.idx_train) & set(S.idx_test)) == 0, "hold-out partition is disjoint")
    check(h["test_high"] == h["test_low"] == 296, "hold-out test set is balanced 296/296")
    cd = results["robustness"]["country_disjoint"]
    check(cd["shared_countries"] == 0, "country-disjoint partition shares no country")
    check(cd["train_countries"] + cd["test_countries"] == audit["final_countries"], "country-disjoint covers all countries")
    check(results["grouped_cv"]["shared_countries_total"] == 0, "grouped CV never shares a country across a fold")
    tp = results["robustness"]["temporal"]
    check(tp["train_n"] + tp["test_n"] == audit["final_rows"], "temporal partition is exhaustive")

    # ---------------- confusion matrices reconcile with metrics
    for name, block in (("NB", h["NB"]), ("LR", h["LR"]), ("PERSIST", h["baselines"]["persistence"]),
                        ("LAG", h["baselines"]["lag_model"])):
        cm = block["confusion"]
        tot = sum(cm.values())
        acc = 100 * (cm["tn"] + cm["tp"]) / tot
        pre = 100 * cm["tp"] / (cm["tp"] + cm["fp"])
        rec = 100 * cm["tp"] / (cm["tp"] + cm["fn"])
        check(tot == h["test_n"], f"{name} confusion matrix covers the test set")
        check(abs(acc - block["accuracy"]) < TOL, f"{name} accuracy reconciles with confusion matrix")
        check(abs(pre - block["precision"]) < TOL, f"{name} precision reconciles with confusion matrix")
        check(abs(rec - block["recall"]) < TOL, f"{name} recall reconciles with confusion matrix")
        check(abs(2 * pre * rec / (pre + rec) - block["f1"]) < TOL, f"{name} F1 reconciles")
        check(int((state["preds"][name] != S.y[S.idx_test]).sum()) == cm["fp"] + cm["fn"],
              f"{name} stored labels reproduce the error count")

    # ---------------- McNemar discordant cells reconcile with error counts
    m = h["mcnemar"]
    err = {n: h[n]["confusion"]["fp"] + h[n]["confusion"]["fn"] for n in ("NB", "LR")}
    err["PERSIST"] = h["baselines"]["persistence"]["confusion"]["fp"] + h["baselines"]["persistence"]["confusion"]["fn"]
    check(err["NB"] - err["LR"] == m["LR_vs_NB"]["n10"] - m["LR_vs_NB"]["n01"], "McNemar LR-NB reconciles with errors")
    check(err["LR"] - err["PERSIST"] == m["PERSIST_vs_LR"]["n10"] - m["PERSIST_vs_LR"]["n01"],
          "McNemar persistence-LR reconciles with errors")
    check(err["NB"] - err["PERSIST"] == m["PERSIST_vs_NB"]["n10"] - m["PERSIST_vs_NB"]["n01"],
          "McNemar persistence-NB reconciles with errors")
    check(abs(h["delong"]["LR_vs_NB"]["auc_a"] - h["LR"]["auc"]) < TOL and
          abs(h["delong"]["LR_vs_NB"]["auc_b"] - h["NB"]["auc"]) < TOL, "DeLong AUCs equal reported AUCs")

    # ---------------- persistence errors are exactly the transitions
    te = S.idx_test
    check(int(S.transition[te].sum()) == err["PERSIST"], "hold-out persistence errors equal hold-out transitions")
    tr = results["transitions_cv"]
    check(tr["stable"]["n"] + tr["transition"]["n"] == audit["final_rows"], "transition strata sum")
    check(tr["transition"]["n"] == audit["transitions"]["n"], "transition count matches the audit")
    check(tr["stable"]["accuracy_PERSIST"] == 100.0 and tr["transition"]["accuracy_PERSIST"] == 0.0,
          "persistence is correct on every stable record and no transition")
    check(tr["low_to_high"]["n"] + tr["high_to_low"]["n"] == tr["transition"]["n"], "transition directions reconcile")
    for n in ("NB", "LR", "LAG"):
        check(tr["low_to_high"][f"correct_{n}"] + tr["high_to_low"][f"correct_{n}"] == tr["transition"][f"correct_{n}"],
              f"{n} transition directions reconcile")
        check(abs(tr["all"][f"accuracy_{n}"] - 100 * (tr["stable"][f"correct_{n}"] + tr["transition"][f"correct_{n}"])
                  / audit["final_rows"]) < TOL, f"{n} out-of-fold accuracy reconciles across strata")
    check(abs(tr["all"]["accuracy_PERSIST"] - results["grouped_cv"]["pooled"]["PERSIST"]["accuracy"]) < TOL,
          "full-sample persistence accuracy is partition-invariant")

    # ---------------- cross-validation coherence
    cv = results["cv"]
    for n in ("NB", "LR", "LAG"):
        check(len(cv["folds"][n]["accuracy"]) == C.N_FOLDS, f"{n} has ten fold estimates")
        check(abs(np.mean(cv["folds"][n]["accuracy"]) - cv["summary"][n]["accuracy"]["mean"]) < TOL,
              f"{n} CV mean reconciles with folds")
    check(results["repeated_cv"]["resamples"] == C.N_FOLDS * C.N_REPEATS, "repeated CV has 100 resamples")
    ns = results["learner_sensitivity"]["nested_tuning"]["summary"]
    for n in ("NB", "LR"):
        check(abs(ns[f"{n}_default"]["accuracy"]["mean"] - cv["summary"][n]["accuracy"]["mean"]) < TOL,
              f"nested-tuning default {n} reproduces primary CV")
    for k, v in cv["paired_LR_vs_NB"].items():
        check(v["p_holm"] >= v["p_t"] - 1e-12, f"Holm-adjusted p not below raw p ({k})")

    # ---------------- sensitivity analyses reproduce the primary analysis at the primary setting
    med = [r for r in results["threshold_sensitivity"] if r["quantile"] == 0.5][0]
    check(abs(med["threshold"] - audit["median_threshold"]) < TOL, "median threshold reproduced")
    check(abs(med["accuracy_LR"] - h["LR"]["accuracy"]) < TOL and abs(med["accuracy_NB"] - h["NB"]["accuracy"]) < TOL,
          "threshold sensitivity at the median reproduces the hold-out")
    check(abs(med["persistence_accuracy"] - h["baselines"]["persistence"]["accuracy"]) < TOL,
          "threshold sensitivity reproduces persistence")
    check(abs(med["cv_accuracy_LR"] - cv["summary"]["LR"]["accuracy"]["mean"]) < TOL,
          "threshold sensitivity reproduces CV accuracy")
    full = [r for r in results["learning_curve"] if r["fraction"] == 1.0][0]
    check(abs(full["accuracy_LR"] - h["LR"]["accuracy"]) < TOL and abs(full["log_loss_NB"]
          - h["calibration"]["NB"]["log_loss"]) < TOL, "learning curve at full size reproduces the hold-out")
    cb = results["contribution"]["lr_coefficient_bootstrap"]
    check(all(v["ci95"][0] <= v["estimate"] <= v["ci95"][1] for v in cb.values()),
          "every coefficient lies inside its bootstrap interval")
    check(all(abs(cb[f]["estimate"] - h["lr_coefficients"][f]) < TOL for f in cb), "bootstrap table uses fitted coefficients")

    # ---------------- error localisation sums
    el = results["error_localisation"]
    for n in ("NB", "LR", "PERSIST"):
        check(sum(r[f"errors_{n}"] for r in el["region"]) == err[n], f"{n} regional errors sum to total")
        check(sum(b[f"errors_{n}"] for b in el["distance_bands"]) == err[n], f"{n} distance-band errors sum")
    check(sum(r["n"] for r in el["region"]) == h["test_n"], "regional test records sum")
    check(sum(b["n"] for b in el["distance_bands"]) == h["test_n"], "distance-band records sum")
    check(el["persistence_failures"]["all_are_transitions"], "every persistence failure is a transition")

    # ---------------- rolling origin
    ro = results["rolling_origin"]
    check(sum(r["test_n"] for r in ro["by_year"]) == ro["pooled"]["test_n"], "rolling-origin test records sum")
    check(sum(r["transitions"] for r in ro["by_year"]) == ro["pooled"]["transitions"], "rolling-origin transitions sum")
    check(ro["pooled"]["years_persistence_ge_LR"] + ro["pooled"]["years_LR_gt_PERSIST"] == len(ro["by_year"]),
          "rolling-origin year comparison is exhaustive")
    check(all(r["train_n"] > 0 and r["year"] > S.years[S.idx_train].min() for r in ro["by_year"]),
          "every rolling-origin year has prior training data")

    # ---------------- risk-coverage
    for row in results["selective_cv"]["rows"]:
        check(row["deferred_n"] + row["retained_n"] == audit["final_rows"], "risk-coverage partitions the sample")
        check(row["transitions_deferred"] <= row["transitions_total"], "deferred transitions bounded")
    full_cov = [r for r in results["selective_cv"]["rows"] if r["coverage"] == 1.0 and r["model"] == "LR"][0]
    check(abs(full_cov["accuracy_model_retained"] - tr["all"]["accuracy_LR"]) < TOL,
          "risk-coverage at full coverage reproduces out-of-fold accuracy")

    # ---------------- calibration bins
    for n in ("NB", "LR", "LAG"):
        check(sum(b["n"] for b in h["calibration"][n]["bins"]) == h["test_n"], f"{n} calibration bins cover test set")

    # ---------------- analyses added at revision
    rv = results.get("revision")
    if rv is not None:
        fx = rv["flexible"]
        for n in ("GBM", "RF"):
            cm = fx["holdout"][n]["confusion"]
            m_ = fx["holdout"][n]["mcnemar_PERSIST_vs"]
            check(sum(cm.values()) == h["test_n"], f"{n} confusion matrix covers the test set")
            check((cm["fp"] + cm["fn"]) - err["PERSIST"] == m_["n10"] - m_["n01"],
                  f"McNemar persistence-{n} reconciles with errors")
            u = fx["transitions_cv"][n]
            check(u["transitions_n"] == audit["transitions"]["n"], f"{n} transition count matches the audit")
            check(fx["rolling_origin"][n]["years_persistence_ge"] <= len(ro["by_year"]), f"{n} rolling-origin years bounded")
        check(abs(np.mean(fx["cv"]["persistence_folds"]) - cv["summary"]["PERSIST"]["accuracy"]["mean"]) < TOL,
              "flexible-learner CV uses the primary folds (persistence reproduced)")
        check(abs(fx["repeated_cv"]["persistence_check"] - results["repeated_cv"]["summary"]["PERSIST"]["accuracy"]["mean"]) < TOL,
              "flexible-learner repeated CV uses the primary resamples")
        check(fx["rolling_origin"]["test_n"] == ro["pooled"]["test_n"], "flexible-learner rolling origin covers the same years")
        mu = rv["multiplicity"]
        check(mu["family_size"] == 28, "multiplicity family holds 7 regimes x 4 learners")
        check(all(r["p_holm"] >= r["p"] - 1e-12 and r["p_bonferroni"] >= r["p_holm"] - 1e-12 for r in mu["rows"]),
              "Bonferroni >= Holm >= raw p for every test")
        rc = rv["recalibration"]["cv"]
        check(abs(rc["NB_raw"]["accuracy"] - tr["all"]["accuracy_NB"]) < TOL and
              abs(rc["LR_raw"]["accuracy"] - tr["all"]["accuracy_LR"]) < TOL,
              "recalibration analysis reproduces the uncalibrated out-of-fold predictions")
        sel5 = [r for r in results["selective_cv"]["rows"] if r["model"] == "LR" and r["coverage"] == 0.95][0]
        check(rc["LR_raw"]["captured_5"] == sel5["transitions_deferred"], "5% deferral reproduces the risk-coverage table")
        an = rv["anchored_threshold"]
        tau_pre = float(np.median(S.clean.loc[S.clean["Year"] <= C.TEMPORAL_CUTOFF, "MortalityRate"]))
        check(abs(an["pre2019_anchor"]["tau"] - tau_pre) < TOL, "pre-2019 anchor equals the training-year median")
        for k in ("pre2019_anchor", "pre2010_anchor"):
            b = an[k]
            check(b["low_to_high"] + b["high_to_low"] == b["transitions"], f"{k} transition directions sum")
            check(b["high"] + b["low"] == audit["final_rows"], f"{k} classes sum to the sample")
        re_ = an["rolling_expanding_tau"]
        check(sum(r["transitions"] for r in re_["by_year"]) == re_["transitions"], "expanding-threshold transitions sum")
        ex = rv["external"]
        check(ex["iso3_unmatched"] == 0, "every country maps to an ISO3 code")
        ds = ex["death_share"]
        check(ds["high_and_top"] + ds["high_not_top"] + ds["low_and_top"] + ds["low_not_top"] == ds["n"],
              "death-share cross-tabulation sums")
        check(ex["interval_check"]["transitions_interval_contains_tau"] + ex["interval_check"]["transitions_interval_robust"]
              == audit["transitions"]["n"], "interval check partitions the transitions")
        sc = rv["review_scenario"]
        check(sc["transitions"] == ro["pooled"]["transitions"], "review scenario sees the rolling-origin transitions")
        check(len(sc["transition_list"]) == sc["transitions"], "transition list is complete")
        check(all(v["captured"] <= min(v["flags"], v["transitions"]) for v in sc["summary"].values()),
              "captured transitions bounded by reviews and transitions")
        check(sc["missed_LR"]["n"] + sc["caught_LR"]["n"] == sc["transitions"], "caught and missed transitions sum")
        co = rv["continuous"]
        check(abs(co["cv"]["RW"]["class_accuracy"] - tr["all"]["accuracy_PERSIST"]) < TOL,
              "random-walk forecast implies exactly the persistence labels (CV)")
        check(abs(co["rolling"]["RW"]["class_accuracy"] - ro["pooled"]["PERSIST"]["accuracy"]) < TOL,
              "random-walk forecast implies exactly the persistence labels (rolling origin)")
        pw = rv["power"]
        check(pw["min_corrections_given_new_errors"][0]["min_transitions_corrected"] == 6,
              "exact McNemar needs six uncontested corrections")
        check(pw["holdout_transitions"] == err["PERSIST"], "power analysis uses the hold-out transitions")

    # ---------------- figures exist
    if figure_paths is not None:
        check(all(p.exists() and p.stat().st_size > 10_000 for p in figure_paths), "every figure file was written")

    failed = [d for ok, d in checks if not ok]
    if verbose:
        print(f"{sum(ok for ok, _ in checks)}/{len(checks)} consistency checks passed")
        for d in failed:
            print("  FAILED:", d)
    assert not failed, f"{len(failed)} consistency check(s) failed"
    return checks
