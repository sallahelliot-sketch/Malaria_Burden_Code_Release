"""Study-wide configuration.

Every constant that shapes a reported number is declared here once and imported
everywhere else, so that no value can drift between modules.
"""
from __future__ import annotations

from pathlib import Path

# ---------------------------------------------------------------------------
# Randomness
# ---------------------------------------------------------------------------
SEED = 1992  # governs every stochastic step in the analysis

# ---------------------------------------------------------------------------
# Data source
# ---------------------------------------------------------------------------
INDICATOR_CODE = "MALARIA_EST_MORTALITY"
INDICATOR_NAME = "Estimated malaria mortality rate (per 100 000 population)"
SOURCE_NAME = "World Health Organization Global Health Observatory"
GHO_ODATA_URL = f"https://ghoapi.azureedge.net/api/{INDICATOR_CODE}"
RAW_FILENAME = "data_raw_WHO_malaria_mortality.xlsx"
CLEAN_FILENAME = "cleaned_WHO_malaria_dataset.xlsx"
EXPORT_PREAMBLE_ROWS = 2  # the portal export carries two rows describing applied filters

# ---------------------------------------------------------------------------
# Dataset construction
# ---------------------------------------------------------------------------
MIN_HISTORY_YEARS = 3  # lag needed to form the three-year trend
NUMERIC_PREDICTORS = ["Year", "Prev_Rate", "Prev_Width", "Trend_3yr", "Baseline_Rate"]
HISTORY_PREDICTORS = ["Prev_Rate", "Trend_3yr", "Baseline_Rate"]
# Quantities measured in the classified year t. They construct the label and are
# withheld from every model; build_design_matrix() asserts that none reaches X.
LEAKAGE_EXCLUDED = ["MortalityRate", "Rate_Low", "Rate_High", "Interval_Width"]

# ---------------------------------------------------------------------------
# Evaluation protocol
# ---------------------------------------------------------------------------
TEST_FRACTION = 0.30
N_FOLDS = 10
N_REPEATS = 10                 # repeated stratified ten-fold cross-validation
DECISION_THRESHOLD = 0.50      # operating point for both classifiers
LR_MAX_ITER = 2000
TEMPORAL_CUTOFF = 2018         # prospective partition: train <= 2018, test >= 2019
ROLLING_FIRST_TEST_YEAR = 2010 # rolling-origin evaluation: first year scored

# ---------------------------------------------------------------------------
# Inference and probabilistic quality
# ---------------------------------------------------------------------------
N_BOOTSTRAP = 10_000           # paired bootstrap replicates on the hold-out rows
N_COEF_BOOTSTRAP = 2_000       # bootstrap refits for coefficient intervals
N_PERMUTATION = 200            # permutation-importance shuffles per predictor
N_CALIBRATION_BINS = 10
EXTREME_PROBABILITY = 0.01     # predictions below .01 or above .99 are "extreme"

# ---------------------------------------------------------------------------
# Sensitivity analyses
# ---------------------------------------------------------------------------
THRESHOLD_QUANTILES = [0.25, 0.40, 0.50, 0.60, 0.75]
LEARNING_FRACTIONS = [0.05, 0.10, 0.20, 0.30, 0.50, 0.70, 1.00]
LEARNING_REPEATS = 50
LR_C_GRID = [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]
NB_SMOOTHING_GRID = [1e-12, 1e-9, 1e-6, 1e-3, 1e-1]
N_TIMING_REPEATS = 50
COVERAGE_LEVELS = [1.00, 0.99, 0.98, 0.97, 0.96, 0.95, 0.925, 0.90]

# ---------------------------------------------------------------------------
# Analyses added at revision (Appendices G-L)
# ---------------------------------------------------------------------------
RF_TREES = 500                 # random forest size
N_JOBS = -1                    # tree fitting in parallel; results do not depend on it (seeded)
GBM_GRID = [{"max_depth": d, "learning_rate": lr, "n_estimators": ne}
            for d in (2, 3, 4) for lr in (0.05, 0.1) for ne in (100, 300)]
RF_GRID = [{"min_samples_leaf": leaf, "max_features": mf} for leaf in (1, 5, 20) for mf in ("sqrt", None)]
SCORE_CLIP = 50.0              # log-odds clip before recalibration (NB scores can reach |s| > 1,000)
POWER_STABLE_ERROR_RATES = [0.0, 0.005, 0.0114, 0.02]   # 0.0114 = LR's out-of-fold stable error rate
POWER_CORRECTION_FRACTIONS = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
POWER_SIMULATIONS = 2000
# WHO / RBM Partnership "High Burden to High Impact" countries (launched November 2018)
HBHI_ISO3 = ["BFA", "CMR", "COD", "GHA", "IND", "MLI", "MOZ", "NER", "NGA", "TZA", "UGA"]
HBHI_LAUNCH_YEAR = 2018
DEATH_SHARE = 0.95             # countries jointly carrying 95% of estimated deaths in a year
REVIEW_K = [3, 5, 9]           # country-years reviewed per year in the review scenario
REVIEW_K_PRIMARY = 5           # about 5.5% of the ~90 country-years classified each year

# ---------------------------------------------------------------------------
# Error localisation
# ---------------------------------------------------------------------------
DISTANCE_BANDS = [(0, 1), (1, 2), (2, 5), (5, 20), (20, float("inf"))]
DISTANCE_LABELS = ["≤ 1", "> 1–2", "> 2–5", "> 5–20", "> 20"]
NEAR_THRESHOLD_BAND = 2.0


def find_project_root(start: Path | None = None) -> Path:
    """Locate the repository root by walking up to the folder holding requirements.txt."""
    here = (start or Path.cwd()).resolve()
    for candidate in (here, *here.parents):
        if (candidate / "requirements.txt").exists() or (candidate / ".git").exists():
            return candidate
    return here


PROJECT_ROOT = find_project_root(Path(__file__).resolve().parent)
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
FIGURE_DIR = RESULTS_DIR / "figures"
TABLE_DIR = RESULTS_DIR / "tables"
EXTERNAL_DIR = DATA_DIR / "external"   # archived GHO extracts used for external grounding
RAW_PATH = DATA_DIR / RAW_FILENAME
CLEAN_PATH = DATA_DIR / CLEAN_FILENAME
