"""Acquisition, cleaning, feature construction and the leakage gate."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from . import config as C


# ---------------------------------------------------------------------------
# Acquisition
# ---------------------------------------------------------------------------
def load_raw_from_export(path: Path = C.RAW_PATH) -> pd.DataFrame:
    """Read the Global Health Observatory portal export and map it onto the study's names."""
    raw = pd.read_excel(path, skiprows=C.EXPORT_PREAMBLE_ROWS)
    required = ["Location", "ParentLocation", "Period", "FactValueNumeric",
                "FactValueNumericLow", "FactValueNumericHigh", "Location type"]
    missing = [c for c in required if c not in raw.columns]
    if missing:
        raise ValueError(f"the export schema has changed; absent columns: {missing}")
    country = raw.loc[raw["Location type"] == "Country", required[:-1]].copy()
    country.columns = ["Country", "WHO_Region", "Year", "MortalityRate", "Rate_Low", "Rate_High"]
    country["Year"] = country["Year"].astype(int)
    return country.reset_index(drop=True)


def load_raw_from_api(url: str = C.GHO_ODATA_URL) -> pd.DataFrame:
    """Fetch the indicator from the GHO OData endpoint (used only when no local export exists).

    The API identifies countries by ISO3 code rather than by name; the analysis groups
    and splits on this identifier, so the two routes yield the same partitions in kind.
    """
    records = pd.DataFrame(list(pd.read_json(url)["value"]))
    country = records[records["SpatialDimType"] == "COUNTRY"].copy()
    out = pd.DataFrame({
        "Country": country["SpatialDim"],
        "WHO_Region": country["ParentLocation"],
        "Year": country["TimeDim"].astype(int),
        "MortalityRate": country["NumericValue"],
        "Rate_Low": country["Low"],
        "Rate_High": country["High"],
    })
    return out.reset_index(drop=True)


def load_raw(path: Path = C.RAW_PATH) -> pd.DataFrame:
    """Prefer the archived portal export; fall back to the OData API."""
    return load_raw_from_export(path) if Path(path).exists() else load_raw_from_api()


def raw_provenance(path: Path = C.RAW_PATH) -> dict:
    """Describe the raw export exactly as received (fields, records, countries, years)."""
    raw = pd.read_excel(path, skiprows=C.EXPORT_PREAMBLE_ROWS)
    out = {
        "raw_fields": int(raw.shape[1]),
        "raw_rows_total": int(raw.shape[0]),
        "date_modified": str(pd.to_datetime(raw["DateModified"]).max().date())
        if "DateModified" in raw.columns else None,
    }
    return out


# ---------------------------------------------------------------------------
# Cleaning and feature construction (Algorithm 1)
# ---------------------------------------------------------------------------
def build_dataset(raw: pd.DataFrame, threshold_quantile: float = 0.5) -> tuple[pd.DataFrame, dict]:
    """Clean the extract, engineer the lagged predictors and derive the threshold label.

    Returns the analytical frame and an audit dictionary recording every reduction.
    """
    audit: dict = {
        "indicator": C.INDICATOR_NAME, "indicator_code": C.INDICATOR_CODE,
        "source": C.SOURCE_NAME, "raw_rows": int(len(raw)),
        "countries_raw": int(raw["Country"].nunique()),
        "year_range_raw": [int(raw["Year"].min()), int(raw["Year"].max())],
    }
    steps = []
    d = raw.copy()

    n0 = len(d)
    d = d.drop_duplicates(["Country", "Year"])
    steps.append(("Removed duplicate country-year keys", n0, len(d)))

    n0 = len(d)
    d = d.dropna(subset=["MortalityRate", "Rate_Low", "Rate_High"])
    steps.append(("Removed records missing the estimate or either bound", n0, len(d)))

    n0 = len(d)
    peak = d.groupby("Country")["MortalityRate"].max()
    malaria_free = sorted(peak[peak == 0].index)
    d = d[~d["Country"].isin(malaria_free)].copy()
    steps.append((f"Removed {len(malaria_free)} countries with a zero rate in every year", n0, len(d)))
    audit["malaria_free_countries"] = {"count": len(malaria_free), "names": malaria_free}

    # Lagged predictors, computed strictly within each country's own history
    d = d.sort_values(["Country", "Year"]).reset_index(drop=True)
    g = d.groupby("Country", sort=False)
    d["Interval_Width"] = d["Rate_High"] - d["Rate_Low"]
    d["Prev_Rate"] = g["MortalityRate"].shift(1)
    d["Prev_Width"] = g["Interval_Width"].shift(1)
    d["Rate_3yr_Ago"] = g["MortalityRate"].shift(C.MIN_HISTORY_YEARS)
    d["Trend_3yr"] = d["Prev_Rate"] - d["Rate_3yr_Ago"]
    d["Baseline_Rate"] = g["MortalityRate"].transform("first")
    d["Baseline_Year"] = g["Year"].transform("first")
    d["Prev_Year"] = g["Year"].shift(1)

    n0 = len(d)
    d = d.dropna(subset=["Prev_Rate", "Prev_Width", "Trend_3yr"])
    steps.append((f"Removed each country's first {C.MIN_HISTORY_YEARS} observed years", n0, len(d)))
    d = d.reset_index(drop=True)

    # The label
    threshold = float(np.quantile(d["MortalityRate"], threshold_quantile))
    d["HighBurden"] = (d["MortalityRate"] >= threshold).astype(int)
    d["Burden_Label"] = np.where(d["HighBurden"] == 1, "High", "Low")
    d["Prev_HighBurden"] = (d["Prev_Rate"] >= threshold).astype(int)
    d["Transition"] = (d["HighBurden"] != d["Prev_HighBurden"]).astype(int)

    audit["cleaning_steps"] = [
        {"step": s, "before": int(b), "after": int(a), "removed": int(b - a)} for s, b, a in steps
    ]
    audit["threshold_quantile"] = threshold_quantile
    audit["median_threshold"] = round(threshold, 4)
    audit["final_rows"] = int(len(d))
    audit["final_countries"] = int(d["Country"].nunique())
    audit["final_year_range"] = [int(d["Year"].min()), int(d["Year"].max())]
    audit["regions"] = int(d["WHO_Region"].nunique())
    audit["class_counts"] = {"High": int(d["HighBurden"].sum()),
                             "Low": int((1 - d["HighBurden"]).sum())}
    audit["class_pct"] = {k: round(100 * v / len(d), 2) for k, v in audit["class_counts"].items()}
    gap = d["Year"] - d["Prev_Year"]
    audit["lag_gap"] = {
        "records_previous_observation_is_t_minus_1": int((gap == 1).sum()),
        "records_previous_observation_is_earlier": int((gap > 1).sum()),
        "detail": [{"country": c, "year": int(y), "previous_year": int(py),
                    "rate": float(r), "previous_rate": float(pr)}
                   for c, y, py, r, pr in d.loc[gap > 1, ["Country", "Year", "Prev_Year",
                                                          "MortalityRate", "Prev_Rate"]].itertuples(index=False)],
    }
    return d, audit


def build_design_matrix(d: pd.DataFrame) -> tuple[pd.DataFrame, np.ndarray, list[str]]:
    """Assemble the modelled design matrix and assert that no year-t quantity reaches it."""
    region_dummies = pd.get_dummies(d["WHO_Region"], prefix="Region").astype(float)
    X = pd.concat([d[C.NUMERIC_PREDICTORS].reset_index(drop=True),
                   region_dummies.reset_index(drop=True)], axis=1)
    leaked = [c for c in X.columns if c in C.LEAKAGE_EXCLUDED]
    assert not leaked, f"LEAKAGE GATE: year-t quantities reached the design matrix: {leaked}"
    return X, d["HighBurden"].to_numpy(), list(X.columns)


# ---------------------------------------------------------------------------
# Sample description
# ---------------------------------------------------------------------------
def describe_sample(d: pd.DataFrame, audit: dict) -> dict:
    """Descriptives, regional composition, class means, correlations and persistence structure."""
    audit["descriptives"] = {
        c: {"mean": round(float(d[c].mean()), 4), "sd": round(float(d[c].std(ddof=1)), 4),
            "p25": round(float(d[c].quantile(.25)), 4), "p50": round(float(d[c].quantile(.50)), 4),
            "p75": round(float(d[c].quantile(.75)), 4), "min": round(float(d[c].min()), 4),
            "max": round(float(d[c].max()), 4)}
        for c in C.NUMERIC_PREDICTORS + ["MortalityRate"]
    }
    region = (d.groupby("WHO_Region")
                .agg(records=("HighBurden", "size"), high_burden=("HighBurden", "sum"),
                     prevalence=("HighBurden", "mean"), countries=("Country", "nunique"),
                     transitions=("Transition", "sum"))
                .sort_values("records", ascending=False))
    audit["region_table"] = [
        {"region": k, "records": int(v.records), "countries": int(v.countries),
         "high_burden": int(v.high_burden),
         "high_prevalence_pct": round(100 * float(v.prevalence), 1),
         "transitions": int(v.transitions)}
        for k, v in region.iterrows()
    ]
    audit["class_means"] = {
        c: {"High": round(float(d.loc[d.HighBurden == 1, c].mean()), 4),
            "Low": round(float(d.loc[d.HighBurden == 0, c].mean()), 4),
            "High_sd": round(float(d.loc[d.HighBurden == 1, c].std(ddof=1)), 4),
            "Low_sd": round(float(d.loc[d.HighBurden == 0, c].std(ddof=1)), 4)}
        for c in C.NUMERIC_PREDICTORS
    }
    audit["point_biserial"] = {
        c: round(float(np.corrcoef(d[c], d["HighBurden"])[0, 1]), 4) for c in C.NUMERIC_PREDICTORS
    }
    numeric = d[C.NUMERIC_PREDICTORS]
    audit["predictor_correlation"] = {
        a: {b: round(float(numeric[a].corr(numeric[b])), 4) for b in C.NUMERIC_PREDICTORS}
        for a in C.NUMERIC_PREDICTORS
    }
    # Temporal inertia of the indicator and of the label
    audit["lag1_correlation_rate"] = round(float(d["MortalityRate"].corr(d["Prev_Rate"])), 4)
    audit["lag1_correlation_log_rate"] = round(float(
        np.log1p(d["MortalityRate"]).corr(np.log1p(d["Prev_Rate"]))), 4)
    audit["transitions"] = {
        "n": int(d["Transition"].sum()),
        "pct": round(100 * float(d["Transition"].mean()), 2),
        "low_to_high": int(((d.Prev_HighBurden == 0) & (d.HighBurden == 1)).sum()),
        "high_to_low": int(((d.Prev_HighBurden == 1) & (d.HighBurden == 0)).sum()),
        "countries_with_any": int(d.loc[d.Transition == 1, "Country"].nunique()),
    }
    by_year = (d.groupby("Year")
                 .agg(records=("HighBurden", "size"), high=("HighBurden", "sum"),
                      median_rate=("MortalityRate", "median"), transitions=("Transition", "sum")))
    audit["by_year"] = [
        {"year": int(y), "records": int(v.records), "high": int(v.high),
         "high_pct": round(100 * v.high / v.records, 2), "median_rate": round(float(v.median_rate), 4),
         "transitions": int(v.transitions)} for y, v in by_year.iterrows()
    ]
    by_region_year = d.groupby(["WHO_Region", "Year"])["HighBurden"].mean().unstack(0)
    audit["prevalence_by_region_year"] = {
        r: {int(y): round(100 * float(v), 2) for y, v in by_region_year[r].dropna().items()}
        for r in by_region_year.columns
    }
    years_per_country = d.groupby("Country")["Year"].size()
    audit["years_per_country"] = {"min": int(years_per_country.min()),
                                  "median": float(years_per_country.median()),
                                  "max": int(years_per_country.max())}
    return audit


def write_clean_workbook(d: pd.DataFrame, audit: dict, path: Path = C.CLEAN_PATH) -> Path:
    """Persist the analytical dataset with a data dictionary and a cleaning summary."""
    cols = ["Country", "WHO_Region", "Year", "MortalityRate", "Rate_Low", "Rate_High",
            "Interval_Width", "Prev_Rate", "Prev_Width", "Trend_3yr", "Baseline_Rate",
            "HighBurden", "Burden_Label", "Prev_HighBurden", "Transition"]
    tau = audit["median_threshold"]
    dictionary = pd.DataFrame([
        ("Country", "Identifier", "Country name", f"{audit['final_countries']} endemic countries"),
        ("WHO_Region", "Predictor", "WHO region, one-hot encoded", f"{audit['regions']} regions"),
        ("Year", "Predictor", "Reporting year t", "-".join(map(str, audit["final_year_range"]))),
        ("MortalityRate", "Excluded", "Estimated rate in year t; derives the target only", "float >= 0"),
        ("Rate_Low", "Excluded", "Lower uncertainty bound in year t", "float >= 0"),
        ("Rate_High", "Excluded", "Upper uncertainty bound in year t", "float >= 0"),
        ("Interval_Width", "Excluded", "Rate_High - Rate_Low in year t", "float >= 0"),
        ("Prev_Rate", "Predictor", "Estimated mortality rate in year t-1", "float >= 0"),
        ("Prev_Width", "Predictor", "Uncertainty interval width in year t-1", "float >= 0"),
        ("Trend_3yr", "Predictor", "Rate in year t-1 minus rate in year t-4", "float"),
        ("Baseline_Rate", "Predictor", "Country's first observed rate in the series", "float >= 0"),
        ("HighBurden", "Target", f"1 if MortalityRate >= {tau:.2f}", "0 = Low, 1 = High"),
        ("Burden_Label", "Target", "Readable burden label", "Low, High"),
        ("Prev_HighBurden", "Reference rule", f"1 if Prev_Rate >= {tau:.2f} (persistence prediction)", "0, 1"),
        ("Transition", "Reporting only", "1 if the class in year t differs from the class in year t-1", "0, 1"),
    ], columns=["Variable", "Role", "Description", "Values / Range"])
    summary = pd.DataFrame(audit["cleaning_steps"])
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        d[cols].round(4).to_excel(writer, sheet_name="Cleaned Data", index=False)
        dictionary.to_excel(writer, sheet_name="Data Dictionary", index=False)
        summary.to_excel(writer, sheet_name="Cleaning Summary", index=False)
    return path
