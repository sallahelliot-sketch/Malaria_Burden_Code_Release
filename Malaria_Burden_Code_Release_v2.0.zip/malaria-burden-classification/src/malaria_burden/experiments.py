"""Every experiment reported in the study, in the order of the manuscript.

Each function receives the objects it needs explicitly and returns plain dictionaries,
so that results.json is a complete, traceable record of every reported number.
"""
from __future__ import annotations

import time

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score, roc_curve, precision_recall_curve
from sklearn.model_selection import (GroupShuffleSplit, RepeatedStratifiedKFold, StratifiedGroupKFold,
                                     StratifiedKFold, train_test_split)
from sklearn.preprocessing import StandardScaler

from . import config as C
from .data import build_dataset, build_design_matrix
from .inference import (corrected_resampled_t, delong_test, holm, mcnemar, paired_bootstrap,
                        paired_fold_tests)
from .metrics import (brier, discrimination, label_scores, logloss, probabilistic_profile)
from .models import fit_and_score, fit_predict, label, make_learners, persistence_rule

LEARNERS = ("NB", "LR")
FOLD_METRICS = ("accuracy", "precision", "recall", "f1", "auc", "brier", "log_loss")
TEST_FAMILY = ("accuracy", "precision", "recall", "f1", "auc")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def lag_feature(prev_rate: np.ndarray) -> np.ndarray:
    """Single input of the univariable lagged-rate model: log(1 + previous-year rate)."""
    return np.log1p(prev_rate).reshape(-1, 1)


def fit_lag_model(prev_tr, y_tr, prev_te) -> np.ndarray:
    """Univariable logistic model on the standardised log previous-year rate.

    It is the probabilistic counterpart of the persistence rule: it uses the same single
    quantity but returns a fitted probability rather than a bare label.
    """
    scaler = StandardScaler().fit(lag_feature(prev_tr))
    model = LogisticRegression(max_iter=C.LR_MAX_ITER, random_state=C.SEED)
    model.fit(scaler.transform(lag_feature(prev_tr)), y_tr)
    return model.predict_proba(scaler.transform(lag_feature(prev_te)))[:, 1]


def score_block(y_true, proba: dict, labels: dict) -> dict:
    """Discrimination and probabilistic scores for every rule that emits a probability."""
    out = {}
    for name, p in proba.items():
        s = discrimination(y_true, labels[name], p)
        s["brier"] = brier(y_true, p)
        s["log_loss"] = logloss(y_true, p)
        out[name] = s
    return out


def summarise_folds(folds: dict) -> dict:
    return {n: {m: {"mean": round(float(np.mean(v)), 4), "sd": round(float(np.std(v, ddof=1)), 4)}
                for m, v in metrics.items()} for n, metrics in folds.items()}


def signed_log1p(x: np.ndarray) -> np.ndarray:
    return np.sign(x) * np.log1p(np.abs(x))


# ---------------------------------------------------------------------------
# Study context: dataset, design matrix and the primary hold-out partition
# ---------------------------------------------------------------------------
class Study:
    """Holds the analytical dataset, design matrix and primary partition."""

    def __init__(self, clean: pd.DataFrame, audit: dict):
        self.clean = clean
        self.audit = audit
        self.threshold = audit["median_threshold"]
        X, self.y, self.features = build_design_matrix(clean)
        self.X = X.to_numpy()
        self.groups = clean["Country"].to_numpy()
        self.years = clean["Year"].to_numpy()
        self.regions = clean["WHO_Region"].to_numpy()
        self.rate_t = clean["MortalityRate"].to_numpy()   # error localisation only, never a feature
        self.prev_rate = clean["Prev_Rate"].to_numpy()    # persistence rule and lag model
        self.transition = clean["Transition"].to_numpy()
        self.rng = np.random.default_rng(C.SEED)          # stratified random reference rule
        self.idx_train, self.idx_test = train_test_split(
            np.arange(len(self.y)), test_size=C.TEST_FRACTION, stratify=self.y, random_state=C.SEED)


# ---------------------------------------------------------------------------
# Hold-out partition: classifiers, reference rules, paired inference, calibration
# ---------------------------------------------------------------------------
def run_holdout(S: Study) -> tuple[dict, dict, dict]:
    tr, te = S.idx_train, S.idx_test
    y_tr, y_te = S.y[tr], S.y[te]
    metrics, proba, preds = fit_and_score(S.X[tr], y_tr, S.X[te], y_te, S.features)
    res = {
        "train_n": int(len(tr)), "test_n": int(len(te)),
        "test_high": int(y_te.sum()), "test_low": int((1 - y_te).sum()),
        "lr_coefficients": metrics.pop("_lr_coefficients"),
        "lr_intercept": metrics.pop("_lr_intercept"),
        "nb_theta": metrics.pop("_nb_theta"), "nb_var": metrics.pop("_nb_var"),
        "nb_prior": metrics.pop("_nb_prior"),
    }
    for name in LEARNERS:
        res[name] = metrics[name]

    # Reference rules (Equation 12 and the two chance floors)
    persistence = persistence_rule(S.prev_rate[te], S.threshold)
    majority_class = int(np.bincount(y_tr).argmax())
    majority = np.full_like(y_te, majority_class)
    random_proba = S.rng.random(len(y_te))
    random_pred = (random_proba >= 0.5).astype(int)
    lag_p = fit_lag_model(S.prev_rate[tr], y_tr, S.prev_rate[te])
    lag_pred = label(lag_p)
    res["baselines"] = {
        "persistence": {"rule": f"HighBurden(t) = 1 if Prev_Rate >= {S.threshold:.2f}",
                        **label_scores(y_te, persistence)},
        "majority": {"predicted_class": "High" if majority_class == 1 else "Low",
                     **label_scores(y_te, majority)},
        "random": {**label_scores(y_te, random_pred),
                   "auc": round(float(roc_auc_score(y_te, random_proba)), 4)},
        "lag_model": {**label_scores(y_te, lag_pred),
                      "auc": round(float(roc_auc_score(y_te, lag_p)), 4)},
    }
    for name in LEARNERS:
        res[name].update({k: v for k, v in label_scores(y_te, preds[name]).items()
                          if k in ("specificity", "mcc", "balanced_accuracy")})
    preds_all = {**preds, "PERSIST": persistence, "LAG": lag_pred}
    proba_all = {**proba, "LAG": lag_p}

    # Paired inference (Equation 15, DeLong and the bootstrap)
    res["mcnemar"] = {
        "LR_vs_NB": mcnemar(preds_all["LR"], preds_all["NB"], y_te),
        "PERSIST_vs_LR": mcnemar(preds_all["PERSIST"], preds_all["LR"], y_te),
        "PERSIST_vs_NB": mcnemar(preds_all["PERSIST"], preds_all["NB"], y_te),
        "LR_vs_LAG": mcnemar(preds_all["LR"], preds_all["LAG"], y_te),
    }
    res["delong"] = {
        "LR_vs_NB": delong_test(y_te, proba["LR"], proba["NB"]),
        "LR_vs_LAG": delong_test(y_te, proba["LR"], lag_p),
    }
    res["bootstrap"] = paired_bootstrap(y_te, {k: preds_all[k] for k in ("NB", "LR", "PERSIST")}, proba)
    res["bootstrap_replicates"] = C.N_BOOTSTRAP

    # Probabilistic quality (Equations 18-20)
    res["calibration"] = {name: probabilistic_profile(y_te, proba_all[name], preds_all[name])
                          for name in ("NB", "LR", "LAG")}
    res["calibration"]["PERSIST"] = {k: v for k, v in label_scores(y_te, persistence).items()
                                     if k in ("mcc", "balanced_accuracy", "specificity")}
    nb_one = proba["NB"] >= 0.995
    res["calibration"]["NB"]["n_assigned_one"] = int(nb_one.sum())
    res["calibration"]["NB"]["pct_low_among_assigned_one"] = round(
        100 * float((y_te[nb_one] == 0).mean()), 2) if nb_one.any() else None

    # Curves for the figures
    curves = {}
    for name in ("NB", "LR", "LAG"):
        fpr, tpr, _ = roc_curve(y_te, proba_all[name])
        prec, rec, _ = precision_recall_curve(y_te, proba_all[name])
        curves[name] = {"fpr": fpr.tolist(), "tpr": tpr.tolist(),
                        "precision": prec.tolist(), "recall": rec.tolist()}
    res["curves"] = curves
    return res, preds_all, proba_all


# ---------------------------------------------------------------------------
# Stratified ten-fold cross-validation (primary repeated-partition evidence)
# ---------------------------------------------------------------------------
def run_cv(S: Study) -> tuple[dict, dict]:
    cv = StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
    folds = {n: {m: [] for m in FOLD_METRICS} for n in ("NB", "LR", "LAG")}
    folds["PERSIST"] = {m: [] for m in ("accuracy", "precision", "recall", "f1")}
    oof = {n: np.zeros(len(S.y)) for n in ("NB", "LR", "LAG")}
    fold_id = np.zeros(len(S.y), dtype=int)
    for k, (tr, va) in enumerate(cv.split(S.X, S.y)):
        fold_id[va] = k
        proba, _ = fit_predict(S.X[tr], S.y[tr], S.X[va])
        proba["LAG"] = fit_lag_model(S.prev_rate[tr], S.y[tr], S.prev_rate[va])
        for name, p in proba.items():
            oof[name][va] = p
            for metric, value in discrimination(S.y[va], label(p), p).items():
                folds[name][metric].append(value)
            folds[name]["brier"].append(brier(S.y[va], p))
            folds[name]["log_loss"].append(logloss(S.y[va], p))
        pers = persistence_rule(S.prev_rate[va], S.threshold)
        for metric, value in label_scores(S.y[va], pers).items():
            if metric in folds["PERSIST"]:
                folds["PERSIST"][metric].append(value)

    res = {"summary": summarise_folds(folds),
           "folds": {n: {m: [round(float(x), 4) for x in v] for m, v in mm.items()}
                     for n, mm in folds.items()}}
    paired = {m: paired_fold_tests(folds["LR"][m], folds["NB"][m]) for m in TEST_FAMILY}
    for m, adj in zip(TEST_FAMILY, holm([paired[m]["p_t"] for m in TEST_FAMILY])):
        paired[m]["p_holm"] = adj
    res["paired_LR_vs_NB"] = paired
    res["paired_probabilistic_LR_vs_NB"] = {
        m: paired_fold_tests(folds["LR"][m], folds["NB"][m]) for m in ("brier", "log_loss")}
    res["paired_PERSIST_vs_LR"] = {m: paired_fold_tests(folds["PERSIST"][m], folds["LR"][m])
                                   for m in ("accuracy", "f1")}
    res["paired_PERSIST_vs_NB"] = {m: paired_fold_tests(folds["PERSIST"][m], folds["NB"][m])
                                   for m in ("accuracy", "f1")}
    res["paired_LR_vs_LAG"] = {m: paired_fold_tests(folds["LR"][m], folds["LAG"][m])
                               for m in ("accuracy", "auc", "brier", "log_loss")}
    # Pooled out-of-fold calibration over the full sample
    res["oof_calibration"] = {n: probabilistic_profile(S.y, oof[n], label(oof[n]))
                              for n in ("NB", "LR", "LAG")}
    return res, {"oof": oof, "fold_id": fold_id}


def run_repeated_cv(S: Study) -> dict:
    """Repeated stratified ten-fold cross-validation (10 x 10 = 100 resamples)."""
    rcv = RepeatedStratifiedKFold(n_splits=C.N_FOLDS, n_repeats=C.N_REPEATS, random_state=C.SEED)
    metrics = ("accuracy", "f1", "auc", "brier", "log_loss")
    folds = {n: {m: [] for m in metrics} for n in ("NB", "LR", "LAG")}
    folds["PERSIST"] = {m: [] for m in ("accuracy", "f1")}
    n_tr = n_te = None
    for tr, va in rcv.split(S.X, S.y):
        n_tr, n_te = len(tr), len(va)
        proba, _ = fit_predict(S.X[tr], S.y[tr], S.X[va])
        proba["LAG"] = fit_lag_model(S.prev_rate[tr], S.y[tr], S.prev_rate[va])
        for name, p in proba.items():
            d = discrimination(S.y[va], label(p), p)
            folds[name]["accuracy"].append(d["accuracy"]); folds[name]["f1"].append(d["f1"])
            folds[name]["auc"].append(d["auc"])
            folds[name]["brier"].append(brier(S.y[va], p))
            folds[name]["log_loss"].append(logloss(S.y[va], p))
        pers = label_scores(S.y[va], persistence_rule(S.prev_rate[va], S.threshold))
        folds["PERSIST"]["accuracy"].append(pers["accuracy"]); folds["PERSIST"]["f1"].append(pers["f1"])
    res = {"resamples": len(folds["LR"]["accuracy"]), "summary": summarise_folds(folds),
           "folds": {n: {m: [round(float(x), 4) for x in v] for m, v in mm.items()}
                     for n, mm in folds.items()}}
    res["corrected_t"] = {
        "LR_vs_NB_accuracy": corrected_resampled_t(folds["LR"]["accuracy"], folds["NB"]["accuracy"], n_tr, n_te),
        "LR_vs_NB_auc": corrected_resampled_t(folds["LR"]["auc"], folds["NB"]["auc"], n_tr, n_te),
        "LR_vs_NB_log_loss": corrected_resampled_t(folds["LR"]["log_loss"], folds["NB"]["log_loss"], n_tr, n_te),
        "LR_vs_NB_brier": corrected_resampled_t(folds["LR"]["brier"], folds["NB"]["brier"], n_tr, n_te),
        "PERSIST_vs_LR_accuracy": corrected_resampled_t(folds["PERSIST"]["accuracy"], folds["LR"]["accuracy"], n_tr, n_te),
        "PERSIST_vs_NB_accuracy": corrected_resampled_t(folds["PERSIST"]["accuracy"], folds["NB"]["accuracy"], n_tr, n_te),
        "LR_vs_LAG_log_loss": corrected_resampled_t(folds["LR"]["log_loss"], folds["LAG"]["log_loss"], n_tr, n_te),
        "LR_vs_LAG_accuracy": corrected_resampled_t(folds["LR"]["accuracy"], folds["LAG"]["accuracy"], n_tr, n_te),
    }
    res["share_resamples_persistence_ge_LR_pct"] = round(100 * float(np.mean(
        np.array(folds["PERSIST"]["accuracy"]) >= np.array(folds["LR"]["accuracy"]))), 1)
    return res


# ---------------------------------------------------------------------------
# Robustness: country-disjoint and prospective partitions
# ---------------------------------------------------------------------------
def evaluate_partition(S: Study, tr, te, label_text: str) -> dict:
    metrics, proba, preds = fit_and_score(S.X[tr], S.y[tr], S.X[te], S.y[te])
    lag_p = fit_lag_model(S.prev_rate[tr], S.y[tr], S.prev_rate[te])
    for name in LEARNERS:
        metrics[name]["brier"] = round(brier(S.y[te], proba[name]), 4)
        metrics[name]["log_loss"] = round(logloss(S.y[te], proba[name]), 4)
    metrics["LAG"] = {**{k: round(v, 4) for k, v in discrimination(S.y[te], label(lag_p), lag_p).items()},
                      "brier": round(brier(S.y[te], lag_p), 4), "log_loss": round(logloss(S.y[te], lag_p), 4)}
    pers = persistence_rule(S.prev_rate[te], S.threshold)
    metrics["PERSIST"] = label_scores(S.y[te], pers)
    metrics["mcnemar_PERSIST_vs_LR"] = mcnemar(pers, preds["LR"], S.y[te])
    metrics["mcnemar_PERSIST_vs_NB"] = mcnemar(pers, preds["NB"], S.y[te])
    trans = S.transition[te] == 1
    metrics["transitions"] = {
        "n": int(trans.sum()),
        **{f"correct_{n}": int((preds[n][trans] == S.y[te][trans]).sum()) for n in LEARNERS},
    }
    return {"label": label_text, "train_n": int(len(tr)), "test_n": int(len(te)),
            "test_high": int(S.y[te].sum()), "test_low": int((1 - S.y[te]).sum()), **metrics}


def run_robustness(S: Study) -> dict:
    splitter = GroupShuffleSplit(n_splits=1, test_size=C.TEST_FRACTION, random_state=C.SEED)
    g_tr, g_te = next(splitter.split(S.X, S.y, groups=S.groups))
    cd = evaluate_partition(S, g_tr, g_te, "Country-disjoint 70/30")
    cd["train_countries"] = int(pd.Series(S.groups[g_tr]).nunique())
    cd["test_countries"] = int(pd.Series(S.groups[g_te]).nunique())
    cd["shared_countries"] = int(len(set(S.groups[g_tr]) & set(S.groups[g_te])))
    t_tr = np.where(S.years <= C.TEMPORAL_CUTOFF)[0]
    t_te = np.where(S.years > C.TEMPORAL_CUTOFF)[0]
    tp = evaluate_partition(S, t_tr, t_te, f"Prospective temporal (train <= {C.TEMPORAL_CUTOFF})")
    tp["train_years"] = [int(S.years[t_tr].min()), int(S.years[t_tr].max())]
    tp["test_years"] = [int(S.years[t_te].min()), int(S.years[t_te].max())]
    return {"country_disjoint": cd, "temporal": tp,
            "_indices": {"cd_train": g_tr, "cd_test": g_te}}


def run_grouped_cv(S: Study) -> dict:
    """Country-grouped stratified ten-fold cross-validation: no country on both sides of a fold."""
    cv = StratifiedGroupKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
    metrics = ("accuracy", "f1", "auc", "brier", "log_loss")
    folds = {n: {m: [] for m in metrics} for n in ("NB", "LR", "LAG")}
    folds["PERSIST"] = {m: [] for m in ("accuracy", "f1")}
    oof = {n: np.zeros(len(S.y)) for n in ("NB", "LR", "LAG")}
    shared = 0
    for tr, va in cv.split(S.X, S.y, groups=S.groups):
        shared += len(set(S.groups[tr]) & set(S.groups[va]))
        proba, _ = fit_predict(S.X[tr], S.y[tr], S.X[va])
        proba["LAG"] = fit_lag_model(S.prev_rate[tr], S.y[tr], S.prev_rate[va])
        for name, p in proba.items():
            oof[name][va] = p
            d = discrimination(S.y[va], label(p), p) if len(np.unique(S.y[va])) > 1 else None
            folds[name]["accuracy"].append(100 * accuracy_score(S.y[va], label(p)))
            folds[name]["f1"].append(d["f1"] if d else np.nan)
            folds[name]["auc"].append(d["auc"] if d else np.nan)
            folds[name]["brier"].append(brier(S.y[va], p))
            folds[name]["log_loss"].append(logloss(S.y[va], p))
        pers = label_scores(S.y[va], persistence_rule(S.prev_rate[va], S.threshold))
        folds["PERSIST"]["accuracy"].append(pers["accuracy"]); folds["PERSIST"]["f1"].append(pers["f1"])
    pooled = {}
    pers_all = persistence_rule(S.prev_rate, S.threshold)
    for n in ("NB", "LR", "LAG"):
        d = discrimination(S.y, label(oof[n]), oof[n])
        pooled[n] = {**{k: round(v, 4) for k, v in d.items()},
                     "brier": round(brier(S.y, oof[n]), 4), "log_loss": round(logloss(S.y, oof[n]), 4)}
    pooled["PERSIST"] = label_scores(S.y, pers_all)
    paired = {m: paired_fold_tests(folds["PERSIST"][m], folds["LR"][m]) for m in ("accuracy",)}
    return {"summary": summarise_folds(folds), "pooled": pooled, "shared_countries_total": shared,
            "folds": {n: {m: [round(float(x), 4) for x in v] for m, v in mm.items()}
                      for n, mm in folds.items()},
            "paired_PERSIST_vs_LR": paired,
            "paired_LR_vs_NB": {m: paired_fold_tests(folds["LR"][m], folds["NB"][m])
                                for m in ("accuracy", "auc", "log_loss")},
            "_oof": oof}


def run_rolling_origin(S: Study) -> dict:
    """Expanding-window evaluation: for each year Y, train on years < Y and score year Y."""
    rows, pooled_idx = [], []
    pooled = {n: [] for n in ("NB", "LR", "LAG")}
    for year in range(C.ROLLING_FIRST_TEST_YEAR, int(S.years.max()) + 1):
        tr = np.where(S.years < year)[0]
        te = np.where(S.years == year)[0]
        proba, _ = fit_predict(S.X[tr], S.y[tr], S.X[te])
        proba["LAG"] = fit_lag_model(S.prev_rate[tr], S.y[tr], S.prev_rate[te])
        pers = persistence_rule(S.prev_rate[te], S.threshold)
        row = {"year": year, "train_n": int(len(tr)), "test_n": int(len(te)),
               "test_high": int(S.y[te].sum()), "transitions": int(S.transition[te].sum())}
        for n, p in proba.items():
            row[f"accuracy_{n}"] = round(100 * accuracy_score(S.y[te], label(p)), 4)
            row[f"log_loss_{n}"] = round(logloss(S.y[te], p), 4)
            pooled[n].append(p)
        row["accuracy_PERSIST"] = round(100 * accuracy_score(S.y[te], pers), 4)
        rows.append(row)
        pooled_idx.append(te)
    idx = np.concatenate(pooled_idx)
    y = S.y[idx]
    pers = persistence_rule(S.prev_rate[idx], S.threshold)
    summary = {"test_n": int(len(idx)), "years": [C.ROLLING_FIRST_TEST_YEAR, int(S.years.max())],
               "transitions": int(S.transition[idx].sum())}
    preds = {}
    for n in ("NB", "LR", "LAG"):
        p = np.concatenate(pooled[n])
        preds[n] = label(p)
        summary[n] = {**{k: round(v, 4) for k, v in discrimination(y, preds[n], p).items()},
                      "brier": round(brier(y, p), 4), "log_loss": round(logloss(y, p), 4)}
    summary["PERSIST"] = label_scores(y, pers)
    summary["mcnemar_PERSIST_vs_LR"] = mcnemar(pers, preds["LR"], y)
    summary["mcnemar_PERSIST_vs_NB"] = mcnemar(pers, preds["NB"], y)
    summary["years_persistence_ge_LR"] = int(sum(r["accuracy_PERSIST"] >= r["accuracy_LR"] for r in rows))
    summary["years_LR_gt_PERSIST"] = int(sum(r["accuracy_LR"] > r["accuracy_PERSIST"] for r in rows))
    trans = S.transition[idx] == 1
    summary["transition_correct"] = {n: int((preds[n][trans] == y[trans]).sum()) for n in ("NB", "LR", "LAG")}
    return {"by_year": rows, "pooled": summary}


# ---------------------------------------------------------------------------
# Transition analysis on out-of-fold predictions
# ---------------------------------------------------------------------------
def run_transitions(S: Study, oof: dict) -> dict:
    """Separate country-years whose class changed from t-1 to t from those that did not."""
    pers = persistence_rule(S.prev_rate, S.threshold)
    out = {}
    for stratum, mask in (("stable", S.transition == 0), ("transition", S.transition == 1),
                          ("all", np.ones_like(S.transition, dtype=bool))):
        row = {"n": int(mask.sum()), "high": int(S.y[mask].sum())}
        for n in ("NB", "LR", "LAG"):
            row[f"accuracy_{n}"] = round(100 * accuracy_score(S.y[mask], label(oof[n][mask])), 4)
            row[f"correct_{n}"] = int((label(oof[n][mask]) == S.y[mask]).sum())
            row[f"mean_p_true_{n}"] = round(float(np.mean(np.where(S.y[mask] == 1, oof[n][mask],
                                                                     1 - oof[n][mask]))), 4)
        row["accuracy_PERSIST"] = round(100 * accuracy_score(S.y[mask], pers[mask]), 4)
        row["correct_PERSIST"] = int((pers[mask] == S.y[mask]).sum())
        out[stratum] = row
    for direction, mask in (("low_to_high", (S.transition == 1) & (S.y == 1)),
                            ("high_to_low", (S.transition == 1) & (S.y == 0))):
        out[direction] = {"n": int(mask.sum()),
                          **{f"correct_{n}": int((label(oof[n][mask]) == S.y[mask]).sum())
                             for n in ("NB", "LR", "LAG")}}
    # Does the fitted probability flag the transitions as uncertain?
    for n in ("NB", "LR", "LAG"):
        unc = np.abs(oof[n] - 0.5)
        out[f"median_margin_{n}"] = {"stable": round(float(np.median(unc[S.transition == 0])), 4),
                                     "transition": round(float(np.median(unc[S.transition == 1])), 4)}
        if len(np.unique(S.transition)) > 1:
            out[f"auc_uncertainty_flags_transition_{n}"] = round(float(
                roc_auc_score(S.transition, -unc)), 4)
    return out


def run_selective(S: Study, oof: dict) -> dict:
    """Risk-coverage analysis on out-of-fold probabilities.

    Country-years are ordered by the fitted model's margin |p - 0.5|; the least certain
    fraction (1 - coverage) is deferred for review. For each coverage level the table
    records the accuracy of the model and of the persistence rule on the retained records
    and how many transitions and model errors fall in the deferred set.
    """
    pers = persistence_rule(S.prev_rate, S.threshold)
    n = len(S.y)
    rows = []
    for name in ("NB", "LR", "LAG"):
        p = oof[name]
        margin = np.abs(p - 0.5)
        order = np.lexsort((np.arange(n), margin))  # ascending margin, ties broken by index
        model_err = label(p) != S.y
        for cov in C.COVERAGE_LEVELS:
            k_defer = int(round((1 - cov) * n))
            deferred = np.zeros(n, dtype=bool)
            deferred[order[:k_defer]] = True
            keep = ~deferred
            rows.append({
                "model": name, "coverage": cov, "deferred_n": int(k_defer), "retained_n": int(keep.sum()),
                "accuracy_model_retained": round(100 * float(accuracy_score(S.y[keep], label(p[keep]))), 4),
                "accuracy_persistence_retained": round(100 * float(accuracy_score(S.y[keep], pers[keep])), 4),
                "transitions_deferred": int(S.transition[deferred].sum()),
                "transitions_total": int(S.transition.sum()),
                "model_errors_deferred": int(model_err[deferred].sum()),
                "model_errors_total": int(model_err.sum()),
            })
    return {"rows": rows}


# ---------------------------------------------------------------------------
# Threshold sensitivity
# ---------------------------------------------------------------------------
def run_threshold_sensitivity(raw: pd.DataFrame) -> list[dict]:
    rows = []
    for q in C.THRESHOLD_QUANTILES:
        d, a = build_dataset(raw, threshold_quantile=q)
        Sq = Study(d, a)
        tr, te = Sq.idx_train, Sq.idx_test
        metrics, proba, preds = fit_and_score(Sq.X[tr], Sq.y[tr], Sq.X[te], Sq.y[te])
        pers = persistence_rule(Sq.prev_rate[te], Sq.threshold)
        row = {"quantile": q, "threshold": round(Sq.threshold, 4),
               "high_pct": a["class_pct"]["High"], "transition_pct": round(100 * float(Sq.transition.mean()), 2),
               "persistence_accuracy": round(100 * accuracy_score(Sq.y[te], pers), 4),
               "persistence_f1": label_scores(Sq.y[te], pers)["f1"]}
        for n in LEARNERS:
            row[f"accuracy_{n}"] = metrics[n]["accuracy"]
            row[f"f1_{n}"] = metrics[n]["f1"]
            row[f"auc_{n}"] = metrics[n]["auc"]
            row[f"log_loss_{n}"] = round(logloss(Sq.y[te], proba[n]), 4)
            row[f"brier_{n}"] = round(brier(Sq.y[te], proba[n]), 4)
        row["mcnemar_PERSIST_vs_LR_p"] = mcnemar(pers, preds["LR"], Sq.y[te])["p"]
        # Ten-fold cross-validated accuracy, same protocol as the primary analysis
        cv = StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
        acc = {n: [] for n in ("NB", "LR", "PERSIST")}
        for ftr, fva in cv.split(Sq.X, Sq.y):
            p, _ = fit_predict(Sq.X[ftr], Sq.y[ftr], Sq.X[fva])
            for n in LEARNERS:
                acc[n].append(100 * accuracy_score(Sq.y[fva], label(p[n])))
            acc["PERSIST"].append(100 * accuracy_score(Sq.y[fva],
                                                       persistence_rule(Sq.prev_rate[fva], Sq.threshold)))
        for n, v in acc.items():
            row[f"cv_accuracy_{n}"] = round(float(np.mean(v)), 4)
        rows.append(row)
    return rows


# ---------------------------------------------------------------------------
# Predictor contribution
# ---------------------------------------------------------------------------
PREDICTOR_GROUPS = {
    "Prev_Rate": ["Prev_Rate"], "Prev_Width": ["Prev_Width"], "Trend_3yr": ["Trend_3yr"],
    "Baseline_Rate": ["Baseline_Rate"], "Year": ["Year"], "WHO_Region": None,  # filled at run time
}


def _groups(S: Study) -> dict:
    g = dict(PREDICTOR_GROUPS)
    g["WHO_Region"] = [f for f in S.features if f.startswith("Region_")]
    return g


def refit_subset(S: Study, cols: list[str]) -> dict:
    ix = [S.features.index(f) for f in cols]
    tr, te = S.idx_train, S.idx_test
    proba, _ = fit_predict(S.X[tr][:, ix], S.y[tr], S.X[te][:, ix])
    y_te = S.y[te]
    out = {}
    for n, p in proba.items():
        d = discrimination(y_te, label(p), p)
        out[n] = {**{k: round(v, 4) for k, v in d.items()},
                  "brier": round(brier(y_te, p), 4), "log_loss": round(logloss(y_te, p), 4)}
    return out


def run_contribution(S: Study, holdout: dict, proba: dict) -> dict:
    groups = _groups(S)
    tr, te = S.idx_train, S.idx_test
    res = {}
    # (a) leave-one-predictor-out refitting, both learners
    loo = {}
    for g, cols in groups.items():
        retained = [f for f in S.features if f not in cols]
        loo[g] = refit_subset(S, retained)
    res["leave_one_out"] = loo
    # (b) ablations
    context = [f for f in S.features if f.startswith("Region_")] + ["Year", "Prev_Width"]
    history = ["Prev_Rate", "Trend_3yr", "Baseline_Rate"]
    res["ablation"] = {
        "context_only": {"features": context, **refit_subset(S, context)},
        "history_only": {"features": history, **refit_subset(S, history)},
        "prev_rate_only": {"features": ["Prev_Rate"], **refit_subset(S, ["Prev_Rate"])},
        "prev_rate_and_width": {"features": ["Prev_Rate", "Prev_Width"],
                                **refit_subset(S, ["Prev_Rate", "Prev_Width"])},
    }
    # (c) bootstrap intervals for the standardised logistic coefficients
    gen = np.random.default_rng(C.SEED)
    Xtr, ytr = S.X[tr], S.y[tr]
    coefs = []
    for _ in range(C.N_COEF_BOOTSTRAP):
        s = gen.choice(len(ytr), size=len(ytr), replace=True)
        if len(np.unique(ytr[s])) < 2:
            continue
        sc = StandardScaler().fit(Xtr[s])
        m = LogisticRegression(max_iter=C.LR_MAX_ITER, random_state=C.SEED).fit(sc.transform(Xtr[s]), ytr[s])
        coefs.append(m.coef_[0])
    coefs = np.array(coefs)
    res["lr_coefficient_bootstrap"] = {
        f: {"estimate": holdout["lr_coefficients"][f],
            "ci95": [round(float(np.percentile(coefs[:, j], 2.5)), 4),
                     round(float(np.percentile(coefs[:, j], 97.5)), 4)],
            "odds_ratio_per_sd": round(float(np.exp(holdout["lr_coefficients"][f])), 4)}
        for j, f in enumerate(S.features)}
    res["lr_coefficient_bootstrap_replicates"] = int(len(coefs))
    # (d) permutation importance on the hold-out rows, predictor groups permuted jointly
    proba_fit, fitted = fit_predict(S.X[tr], S.y[tr], S.X[te])
    scaler = StandardScaler().fit(S.X[tr])
    Z_te = scaler.transform(S.X[te])
    y_te = S.y[te]
    gen = np.random.default_rng(C.SEED)
    perm = {}
    for g, cols in groups.items():
        ix = [S.features.index(f) for f in cols]
        drops = {n: {"log_loss": [], "auc": [], "accuracy": []} for n in LEARNERS}
        for _ in range(C.N_PERMUTATION):
            order = gen.permutation(len(y_te))
            Zp = Z_te.copy()
            Zp[:, ix] = Z_te[order][:, ix]
            for n in LEARNERS:
                p = fitted[n].predict_proba(Zp)[:, 1]
                drops[n]["log_loss"].append(logloss(y_te, p) - logloss(y_te, proba_fit[n]))
                drops[n]["auc"].append(roc_auc_score(y_te, proba_fit[n]) - roc_auc_score(y_te, p))
                drops[n]["accuracy"].append(100 * (accuracy_score(y_te, label(proba_fit[n]))
                                                   - accuracy_score(y_te, label(p))))
        perm[g] = {n: {m: {"mean": round(float(np.mean(v)), 4), "sd": round(float(np.std(v, ddof=1)), 4)}
                       for m, v in dd.items()} for n, dd in drops.items()}
    res["permutation_importance"] = perm
    return res


# ---------------------------------------------------------------------------
# Sensitivity of the learners: transformed inputs and nested tuning
# ---------------------------------------------------------------------------
def log_transform(S: Study, X: np.ndarray) -> np.ndarray:
    Xl = X.copy()
    for f in ("Prev_Rate", "Prev_Width", "Baseline_Rate"):
        j = S.features.index(f)
        Xl[:, j] = np.log1p(Xl[:, j])
    j = S.features.index("Trend_3yr")
    Xl[:, j] = signed_log1p(Xl[:, j])
    return Xl


def run_learner_sensitivity(S: Study) -> dict:
    tr, te = S.idx_train, S.idx_test
    out = {}
    Xl = log_transform(S, S.X)
    proba, _ = fit_predict(Xl[tr], S.y[tr], Xl[te])
    out["log_inputs_holdout"] = {
        n: {**{k: round(v, 4) for k, v in discrimination(S.y[te], label(p), p).items()},
            "brier": round(brier(S.y[te], p), 4), "log_loss": round(logloss(S.y[te], p), 4),
            "pct_extreme": round(100 * float(np.mean((p < .01) | (p > .99))), 2)}
        for n, p in proba.items()}
    # Nested tuning: inner five-fold selection of the regularisation / smoothing by log loss
    outer = StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
    res = {n: {"accuracy": [], "auc": [], "log_loss": [], "brier": []} for n in ("NB_default", "NB_tuned",
                                                                                "LR_default", "LR_tuned")}
    chosen = {"NB": [], "LR": []}
    for o_tr, o_va in outer.split(S.X, S.y):
        inner = StratifiedKFold(n_splits=5, shuffle=True, random_state=C.SEED)
        scores_lr = {c: [] for c in C.LR_C_GRID}
        scores_nb = {v: [] for v in C.NB_SMOOTHING_GRID}
        for i_tr, i_va in inner.split(S.X[o_tr], S.y[o_tr]):
            a, b = o_tr[i_tr], o_tr[i_va]
            for c in C.LR_C_GRID:
                p, _ = fit_predict(S.X[a], S.y[a], S.X[b], {"LR": make_learners(lr_c=c)["LR"]})
                scores_lr[c].append(logloss(S.y[b], p["LR"]))
            for v in C.NB_SMOOTHING_GRID:
                p, _ = fit_predict(S.X[a], S.y[a], S.X[b], {"NB": make_learners(nb_smoothing=v)["NB"]})
                scores_nb[v].append(logloss(S.y[b], p["NB"]))
        best_c = min(C.LR_C_GRID, key=lambda c: np.mean(scores_lr[c]))
        best_v = min(C.NB_SMOOTHING_GRID, key=lambda v: np.mean(scores_nb[v]))
        chosen["LR"].append(best_c); chosen["NB"].append(best_v)
        learners = {"NB_default": make_learners()["NB"], "LR_default": make_learners()["LR"],
                    "NB_tuned": make_learners(nb_smoothing=best_v)["NB"],
                    "LR_tuned": make_learners(lr_c=best_c)["LR"]}
        p, _ = fit_predict(S.X[o_tr], S.y[o_tr], S.X[o_va], learners)
        for n, pp in p.items():
            res[n]["accuracy"].append(100 * accuracy_score(S.y[o_va], label(pp)))
            res[n]["auc"].append(roc_auc_score(S.y[o_va], pp))
            res[n]["log_loss"].append(logloss(S.y[o_va], pp))
            res[n]["brier"].append(brier(S.y[o_va], pp))
    out["nested_tuning"] = {"summary": summarise_folds(res),
                            "chosen_C": chosen["LR"], "chosen_var_smoothing": chosen["NB"],
                            "grid_C": C.LR_C_GRID, "grid_var_smoothing": C.NB_SMOOTHING_GRID}
    return out


def run_learning_curve(S: Study) -> list[dict]:
    tr, te = S.idx_train, S.idx_test
    gen = np.random.default_rng(C.SEED)
    rows = []
    for frac in C.LEARNING_FRACTIONS:
        acc = {n: [] for n in LEARNERS}; ll = {n: [] for n in LEARNERS}; auc = {n: [] for n in LEARNERS}
        reps = 1 if frac == 1.0 else C.LEARNING_REPEATS
        for _ in range(reps):
            if frac == 1.0:
                sub = tr
            else:
                sub, _ = train_test_split(tr, train_size=frac, stratify=S.y[tr],
                                          random_state=int(gen.integers(0, 2**31 - 1)))
            p, _ = fit_predict(S.X[sub], S.y[sub], S.X[te])
            for n in LEARNERS:
                acc[n].append(100 * accuracy_score(S.y[te], label(p[n])))
                ll[n].append(logloss(S.y[te], p[n])); auc[n].append(roc_auc_score(S.y[te], p[n]))
        row = {"fraction": frac, "train_n": int(round(frac * len(tr))) if frac < 1 else int(len(tr)),
               "repeats": reps}
        for n in LEARNERS:
            row[f"accuracy_{n}"] = round(float(np.mean(acc[n])), 4)
            row[f"accuracy_sd_{n}"] = round(float(np.std(acc[n], ddof=1)), 4) if reps > 1 else 0.0
            row[f"log_loss_{n}"] = round(float(np.mean(ll[n])), 4)
            row[f"log_loss_sd_{n}"] = round(float(np.std(ll[n], ddof=1)), 4) if reps > 1 else 0.0
            row[f"auc_{n}"] = round(float(np.mean(auc[n])), 4)
        rows.append(row)
    return rows


# ---------------------------------------------------------------------------
# Localisation of error
# ---------------------------------------------------------------------------
def run_error_localisation(S: Study, preds: dict) -> dict:
    te = S.idx_test
    y_te = S.y[te]
    names = ("NB", "LR", "PERSIST")
    out = {"region": [], "distance_bands": []}
    reg = S.regions[te]
    for r in sorted(set(reg)):
        m = reg == r
        row = {"region": r, "n": int(m.sum()), "high_burden": int(y_te[m].sum())}
        for n in names:
            row[f"accuracy_{n}"] = round(100 * float(accuracy_score(y_te[m], preds[n][m])), 4)
            row[f"errors_{n}"] = int((preds[n][m] != y_te[m]).sum())
        out["region"].append(row)
    gap = np.abs(S.rate_t[te] - S.threshold)
    for (lo, hi), lab in zip(C.DISTANCE_BANDS, C.DISTANCE_LABELS):
        m = (gap <= hi) if lo == 0 else (gap > lo) & (gap <= hi)
        row = {"band": lab, "n": int(m.sum())}
        for n in names:
            row[f"accuracy_{n}"] = round(100 * float(accuracy_score(y_te[m], preds[n][m])), 4)
            row[f"errors_{n}"] = int((preds[n][m] != y_te[m]).sum())
        out["distance_bands"].append(row)
    near = gap <= C.NEAR_THRESHOLD_BAND
    nt = {"band": f"+/- {C.NEAR_THRESHOLD_BAND} deaths per 100,000", "n": int(near.sum()),
          "share_of_test_pct": round(100 * float(near.mean()), 2)}
    for n in names:
        total = int((preds[n] != y_te).sum())
        band = int((preds[n][near] != y_te[near]).sum())
        nt[f"accuracy_{n}"] = round(100 * float(accuracy_score(y_te[near], preds[n][near])), 4)
        nt[f"errors_{n}"] = band
        nt[f"total_errors_{n}"] = total
        nt[f"share_of_{n}_errors_pct"] = round(100 * band / max(1, total), 2)
    out["near_threshold"] = nt
    fail = preds["PERSIST"] != y_te
    out["persistence_failures"] = {
        "n": int(fail.sum()),
        "all_are_transitions": bool(np.all(S.transition[te][fail] == 1)),
        "LR_correct_on_those": int((preds["LR"][fail] == y_te[fail]).sum()),
        "NB_correct_on_those": int((preds["NB"][fail] == y_te[fail]).sum()),
        "mean_abs_gap_to_threshold": round(float(np.mean(gap[fail])), 4),
    }
    return out


# ---------------------------------------------------------------------------
# Computational cost
# ---------------------------------------------------------------------------
def run_timing(S: Study) -> dict:
    tr, te = S.idx_train, S.idx_test
    out = {}
    for n in LEARNERS:
        fit_t, pred_t = [], []
        for _ in range(C.N_TIMING_REPEATS):
            sc = StandardScaler().fit(S.X[tr])
            Ztr, Zte = sc.transform(S.X[tr]), sc.transform(S.X[te])
            m = make_learners()[n]
            t0 = time.perf_counter(); m.fit(Ztr, S.y[tr]); t1 = time.perf_counter()
            m.predict_proba(Zte); t2 = time.perf_counter()
            fit_t.append(1000 * (t1 - t0)); pred_t.append(1000 * (t2 - t1))
        out[n] = {"fit_ms_median": round(float(np.median(fit_t)), 3),
                  "predict_ms_median": round(float(np.median(pred_t)), 3),
                  "parameters": int(2 * 2 * len(S.features) + 2) if n == "NB" else int(len(S.features) + 1)}
    t_pers = []
    for _ in range(C.N_TIMING_REPEATS):
        t0 = time.perf_counter(); persistence_rule(S.prev_rate[te], S.threshold); t_pers.append(1000 * (time.perf_counter() - t0))
    out["PERSIST"] = {"fit_ms_median": 0.0, "predict_ms_median": round(float(np.median(t_pers)), 3),
                      "parameters": 0}
    return out
