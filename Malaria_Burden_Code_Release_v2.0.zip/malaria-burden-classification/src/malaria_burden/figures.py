"""Every figure, drawn from the computed result objects rather than transcribed numbers."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from sklearn.metrics import confusion_matrix

from . import config as C
from .models import label, persistence_rule

# One palette, used identically in every figure
COL = {"NB": "#C0392B", "LR": "#1F4E79", "LAG": "#D68910", "PERSIST": "#2E8B57",
       "GREY": "#7F7F7F", "LIGHT": "#D9D9D9"}
NAME = {"NB": "Naïve Bayes", "LR": "Logistic regression", "LAG": "Lagged-rate logistic model",
        "PERSIST": "Persistence rule"}
REGION_COL = {"Africa": "#8E2C1F", "Eastern Mediterranean": "#D68910", "Western Pacific": "#1F78B4",
              "South-East Asia": "#6A3D9A", "Americas": "#2E8B57"}
MARK = {"NB": "o", "LR": "s", "LAG": "D", "PERSIST": "^"}

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "axes.labelsize": 9, "axes.titlesize": 9.5,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 8, "figure.dpi": 110,
    "savefig.dpi": 300, "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.8, "figure.facecolor": "white", "savefig.facecolor": "white",
    "axes.titleweight": "bold", "axes.titlelocation": "left",
})


def _save(fig, name: str) -> Path:
    path = C.FIGURE_DIR / name
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


# ---------------------------------------------------------------------------
# Figure 1: study framework
# ---------------------------------------------------------------------------
def fig_framework(audit: dict, results: dict) -> Path:
    fig, ax = plt.subplots(figsize=(7.4, 3.9))
    ax.set_xlim(-0.8, 101.2); ax.set_ylim(0, 50); ax.axis("off")

    def box(x, y, w, h, title, body, face, edge):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=1.2",
                                    fc=face, ec=edge, lw=1.1))
        ax.text(x + w / 2, y + h - 1.4, title, ha="center", va="top", fontsize=7.0, weight="bold",
                color=edge)
        ax.text(x + w / 2, y + h - 4.6, body, ha="center", va="top", fontsize=5.5, linespacing=1.3)

    def arrow(x0, y0, x1, y1, color="#404040"):
        ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=9,
                                     lw=1.0, color=color))

    cs = audit["cleaning_steps"]
    W, G = 23.4, 2.2
    xs = [0.6 + k * (W + G) for k in range(4)]
    top_y, top_h = 33, 16
    box(xs[0], top_y, W, top_h, "1  Data source",
        f"WHO Global Health\nObservatory, indicator\n{audit['indicator_code']}\n{audit['raw_rows']:,} country-years\n"
        f"{audit['countries_raw']} countries, {audit['year_range_raw'][0]}\u2013{audit['year_range_raw'][1]}\n"
        "estimate, lower and upper bound", "#EAF1F8", "#1F4E79")
    box(xs[1], top_y, W, top_h, "2  Cleaning",
        f"duplicate keys: {-cs[0]['removed'] if cs[0]['removed'] else 0}\nmissing estimate or bound: \u2212{cs[1]['removed']}\n"
        f"{audit['malaria_free_countries']['count']} malaria-free countries: \u2212{cs[2]['removed']}\n"
        f"first {C.MIN_HISTORY_YEARS} years per country: \u2212{cs[3]['removed']}\n"
        f"N = {audit['final_rows']:,}; {audit['final_countries']} countries", "#EAF1F8", "#1F4E79")
    box(xs[2], top_y, W, top_h, "3  Features and label",
        "WHO region (one-hot), year\nrate at t\u22121, width at t\u22121\nthree-year trend,\nbaseline rate\n"
        f"label: rate(t) \u2265 \u03c4 = {audit['median_threshold']:.2f}", "#FDF2E9", "#A04000")
    box(xs[3], top_y, W, top_h, "4  Rules compared",
        "Gaussian Na\u00efve Bayes\nlogistic regression\nreference: persistence,\nlagged-rate logistic,\nmajority class, random", "#FDEDEC", "#922B21")
    for k in range(3):
        arrow(xs[k] + W + 0.35, top_y + top_h / 2, xs[k + 1] - 0.35, top_y + top_h / 2)
    ax.text(50, 28.6, "Leakage gate: rate, lower bound, upper bound and interval width of year t construct the label "
            "and never enter the design matrix;\nstandardisation is re-estimated inside every training partition",
            ha="center", va="center", fontsize=6.2, style="italic", color="#922B21",
            bbox=dict(boxstyle="round,pad=0.35", fc="#FBEEE6", ec="#922B21", lw=0.8))
    W2, G2 = 31.6, 2.6
    xb = [0.6 + k * (W2 + G2) for k in range(3)]
    bot_y, bot_h = 2.5, 17
    box(xb[0], bot_y, W2, bot_h, "5  Evaluation regimes",
        f"stratified 70/30 hold-out ({results['holdout']['train_n']:,} / {results['holdout']['test_n']})\n"
        f"stratified 10-fold CV\nrepeated {C.N_FOLDS}\u00d7{C.N_REPEATS} CV; country-grouped CV\n"
        "country-disjoint 70/30 split\nprospective split (\u22642018 | \u22652019)\n"
        f"rolling origin {C.ROLLING_FIRST_TEST_YEAR}\u20132024", "#E9F7EF", "#1E8449")
    box(xb[1], bot_y, W2, bot_h, "6  Evidence families",
        "discrimination: Acc, Pre, Rec, F1, AUC\nprobability: Brier, log loss, ECE,\n"
        "calibration slope and intercept\npaired: McNemar, DeLong, bootstrap\nfold-level t, Holm correction\n"
        "transitions and risk\u2013coverage", "#E9F7EF", "#1E8449")
    box(xb[2], bot_y, W2, bot_h, "7  Sensitivity and audit",
        "threshold percentiles 25th\u201375th\nablation, leave-one-out,\npermutation importance\n"
        "log inputs, nested tuning\nlearning curves, runtime\nconsistency checks", "#F4ECF7", "#6C3483")
    arrow(xs[3] + W / 2, top_y - 0.4, xs[3] + W / 2, 31.4)
    ax.plot([xs[3] + W / 2, xs[3] + W / 2], [25.8, 24.3], color="#404040", lw=1.0)
    ax.plot([xs[3] + W / 2, xb[0] + W2 / 2], [24.3, 24.3], color="#404040", lw=1.0)
    arrow(xb[0] + W2 / 2, 24.3, xb[0] + W2 / 2, bot_y + bot_h + 0.4)
    arrow(xb[0] + W2 + 0.35, bot_y + bot_h / 2, xb[1] - 0.35, bot_y + bot_h / 2)
    arrow(xb[1] + W2 + 0.35, bot_y + bot_h / 2, xb[2] - 0.35, bot_y + bot_h / 2)
    return _save(fig, "fig01_framework.png")


# ---------------------------------------------------------------------------
# Figure 2: sample structure and temporal inertia
# ---------------------------------------------------------------------------
def fig_sample_structure(audit: dict, S) -> Path:
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.9), gridspec_kw={"width_ratios": [1.0, 1.1, 1.0]})
    ax = axes[0]
    table = sorted(audit["region_table"], key=lambda r: r["high_prevalence_pct"])
    ax.barh([r["region"].replace("Eastern Mediterranean", "E. Mediterranean") for r in table],
            [r["high_prevalence_pct"] for r in table], color=[REGION_COL[r["region"]] for r in table])
    for i, r in enumerate(table):
        ax.text(r["high_prevalence_pct"] + 2, i, f"{r['high_prevalence_pct']:.1f}%  (n = {r['records']})",
                va="center", fontsize=6.6)
    ax.set_xlim(0, 135); ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_xlabel("High-burden prevalence (%)"); ax.set_title("(a) By WHO region")

    ax = axes[1]
    for r, series in audit["prevalence_by_region_year"].items():
        yrs = sorted(int(y) for y in series)
        ax.plot(yrs, [series[str(y)] if str(y) in series else series[y] for y in yrs],
                color=REGION_COL[r], lw=1.5, label=r.replace("Eastern Mediterranean", "E. Mediterranean"))
    ax.set_ylim(-3, 103); ax.set_xlabel("Year"); ax.set_ylabel("High-burden prevalence (%)")
    ax.set_title("(b) Over time, by region")
    ax.legend(fontsize=5.6, frameon=False, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.24),
              columnspacing=0.8, handlelength=1.4)

    ax = axes[2]
    x, y = np.log1p(S.prev_rate), np.log1p(S.rate_t)
    stable = S.transition == 0
    ax.scatter(x[stable], y[stable], s=5, color=COL["LR"], alpha=0.35, lw=0, label="Stable class")
    ax.scatter(x[~stable], y[~stable], s=14, color=COL["NB"], marker="x", lw=0.9,
               label=f"Transition (n = {int((~stable).sum())})")
    t = np.log1p(S.threshold)
    ax.axvline(t, color=COL["GREY"], ls="--", lw=0.8); ax.axhline(t, color=COL["GREY"], ls="--", lw=0.8)
    ax.set_xlabel("log(1 + rate at t−1)"); ax.set_ylabel("log(1 + rate at t)")
    ax.set_title("(c) Year-to-year inertia")
    ax.legend(fontsize=6, frameon=False, loc="upper left", handletextpad=0.2)
    ax.text(0.97, 0.05, f"r = {S.audit['lag1_correlation_rate']:.3f}", transform=ax.transAxes,
            ha="right", fontsize=7)
    fig.tight_layout(w_pad=1.0)
    return _save(fig, "fig02_sample_structure.png")


# ---------------------------------------------------------------------------
# Figure 3: ROC and precision-recall curves on the hold-out partition
# ---------------------------------------------------------------------------
def fig_roc_pr(results: dict) -> Path:
    h = results["holdout"]
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.1))
    auc = {"NB": h["NB"]["auc"], "LR": h["LR"]["auc"], "LAG": h["baselines"]["lag_model"]["auc"]}
    ap = {n: h["calibration"][n]["average_precision"] for n in ("NB", "LR", "LAG")}
    pers = h["baselines"]["persistence"]
    for n in ("NB", "LR", "LAG"):
        c = h["curves"][n]
        axes[0].plot(c["fpr"], c["tpr"], color=COL[n], lw=1.6, label=f"{NAME[n]} (AUC = {auc[n]:.3f})")
        axes[1].plot(c["recall"], c["precision"], color=COL[n], lw=1.6, label=f"{NAME[n]} (AP = {ap[n]:.3f})")
    fpr_p = 100 - pers["specificity"]
    axes[0].scatter([fpr_p / 100], [pers["recall"] / 100], marker="^", s=40, color=COL["PERSIST"], zorder=5,
                    label="Persistence rule (single point)")
    axes[1].scatter([pers["recall"] / 100], [pers["precision"] / 100], marker="^", s=40, color=COL["PERSIST"],
                    zorder=5, label="Persistence rule (single point)")
    axes[0].plot([0, 1], [0, 1], ls=":", color=COL["GREY"], lw=1)
    axes[0].set_xlabel("False positive rate"); axes[0].set_ylabel("True positive rate")
    axes[0].set_title("(a) ROC curves")
    axes[1].set_xlabel("Recall"); axes[1].set_ylabel("Precision"); axes[1].set_title("(b) Precision–recall curves")
    axes[1].set_ylim(0.45, 1.02)
    # Inset magnifying the operating region of the ROC curve
    ins = axes[0].inset_axes([0.42, 0.33, 0.53, 0.4])
    for n in ("NB", "LR", "LAG"):
        c = h["curves"][n]; ins.plot(c["fpr"], c["tpr"], color=COL[n], lw=1.2)
    ins.scatter([fpr_p / 100], [pers["recall"] / 100], marker="^", s=24, color=COL["PERSIST"], zorder=5)
    ins.set_xlim(0, 0.12); ins.set_ylim(0.85, 1.0); ins.tick_params(labelsize=6)
    for ax in axes:
        ax.legend(loc="lower left" if ax is axes[1] else "lower right", fontsize=6.2, frameon=False)
    axes[0].legend(loc="lower right", fontsize=6.0, frameon=False, bbox_to_anchor=(1.0, 0.0))
    fig.tight_layout(w_pad=1.6)
    return _save(fig, "fig03_roc_pr.png")


# ---------------------------------------------------------------------------
# Figure 4: reliability diagrams and probability distributions
# ---------------------------------------------------------------------------
def fig_calibration(results: dict, proba: dict, S) -> Path:
    cal = results["holdout"]["calibration"]
    y_te = S.y[S.idx_test]
    fig, axes = plt.subplots(2, 3, figsize=(7.3, 4.4), gridspec_kw={"height_ratios": [2.1, 1]}, sharex="col")
    for j, n in enumerate(("NB", "LR", "LAG")):
        ax = axes[0, j]
        pts = [b for b in cal[n]["bins"] if b["n"]]
        ax.plot([0, 1], [0, 1], ls="--", color=COL["GREY"], lw=0.9)
        ax.plot([b["confidence"] for b in pts], [b["observed"] for b in pts], "-o", color=COL[n], lw=1.4, ms=4)
        for b in pts:
            ax.annotate(str(b["n"]), (b["confidence"], b["observed"]), textcoords="offset points",
                        xytext=(4, -9), fontsize=5.8, color="#333333")
        ax.set_xlim(-0.03, 1.03); ax.set_ylim(-0.05, 1.05)
        ax.set_title(f"({'abc'[j]}) {NAME[n]}", color=COL[n])
        ax.text(0.03, 0.97, f"Brier {cal[n]['brier']:.4f}\nlog loss {cal[n]['log_loss']:.4f}\n"
                f"ECE {cal[n]['ece']:.4f}\nslope {cal[n]['slope']:.2f}",
                transform=ax.transAxes, va="top", fontsize=6.3,
                bbox=dict(fc="white", ec=COL["LIGHT"], lw=0.6, boxstyle="round,pad=0.3"))
        if j == 0:
            ax.set_ylabel("Observed high-burden frequency")
        bx = axes[1, j]
        p = proba[n]
        bins = np.linspace(0, 1, 21)
        bx.hist(p[y_te == 0], bins=bins, color=COL["GREY"], alpha=0.75, label="Low (observed)")
        bx.hist(p[y_te == 1], bins=bins, color=COL[n], alpha=0.75, label="High (observed)")
        bx.set_yscale("log"); bx.set_xlabel("Predicted probability (high burden)")
        if j == 0:
            bx.set_ylabel("Count (log)")
        bx.legend(fontsize=5.6, frameon=False, loc="upper center")
    fig.tight_layout(h_pad=0.6, w_pad=0.8)
    return _save(fig, "fig04_calibration.png")


# ---------------------------------------------------------------------------
# Figure 5: accuracy and log loss across evaluation regimes
# ---------------------------------------------------------------------------
def regime_table(results: dict) -> list[dict]:
    """Accuracy and log loss of each rule under every evaluation regime (one row per regime)."""
    h, cv, rcv = results["holdout"], results["cv"]["summary"], results["repeated_cv"]["summary"]
    g, cd, tp, ro = (results["grouped_cv"]["summary"], results["robustness"]["country_disjoint"],
                     results["robustness"]["temporal"], results["rolling_origin"]["pooled"])
    rows = [
        {"regime": "Stratified hold-out (n = 592)", "NB": h["NB"]["accuracy"], "LR": h["LR"]["accuracy"],
         "LAG": h["baselines"]["lag_model"]["accuracy"], "PERSIST": h["baselines"]["persistence"]["accuracy"],
         "ll_NB": h["calibration"]["NB"]["log_loss"], "ll_LR": h["calibration"]["LR"]["log_loss"],
         "ll_LAG": h["calibration"]["LAG"]["log_loss"], "sd": None},
        {"regime": "Stratified 10-fold CV", **{n: cv[n]["accuracy"]["mean"] for n in ("NB", "LR", "LAG", "PERSIST")},
         **{f"ll_{n}": cv[n]["log_loss"]["mean"] for n in ("NB", "LR", "LAG")},
         "sd": {n: cv[n]["accuracy"]["sd"] for n in ("NB", "LR", "LAG", "PERSIST")}},
        {"regime": "Repeated 10×10 CV", **{n: rcv[n]["accuracy"]["mean"] for n in ("NB", "LR", "LAG", "PERSIST")},
         **{f"ll_{n}": rcv[n]["log_loss"]["mean"] for n in ("NB", "LR", "LAG")},
         "sd": {n: rcv[n]["accuracy"]["sd"] for n in ("NB", "LR", "LAG", "PERSIST")}},
        {"regime": "Country-grouped 10-fold CV", **{n: g[n]["accuracy"]["mean"] for n in ("NB", "LR", "LAG", "PERSIST")},
         **{f"ll_{n}": g[n]["log_loss"]["mean"] for n in ("NB", "LR", "LAG")},
         "sd": {n: g[n]["accuracy"]["sd"] for n in ("NB", "LR", "LAG", "PERSIST")}},
        {"regime": f"Country-disjoint 70/30 (n = {cd['test_n']})",
         **{n: cd[n]["accuracy"] for n in ("NB", "LR", "LAG", "PERSIST")},
         **{f"ll_{n}": cd[n]["log_loss"] for n in ("NB", "LR", "LAG")}, "sd": None},
        {"regime": f"Prospective 2019–2024 (n = {tp['test_n']})",
         **{n: tp[n]["accuracy"] for n in ("NB", "LR", "LAG", "PERSIST")},
         **{f"ll_{n}": tp[n]["log_loss"] for n in ("NB", "LR", "LAG")}, "sd": None},
        {"regime": f"Rolling origin 2010–2024 (n = {ro['test_n']:,})",
         **{n: ro[n]["accuracy"] for n in ("NB", "LR", "LAG", "PERSIST")},
         **{f"ll_{n}": ro[n]["log_loss"] for n in ("NB", "LR", "LAG")}, "sd": None},
    ]
    return rows


def fig_regimes(results: dict) -> Path:
    rows = regime_table(results)
    fig, axes = plt.subplots(1, 2, figsize=(7.3, 3.4), gridspec_kw={"width_ratios": [1.5, 1]})
    ypos = np.arange(len(rows))[::-1]
    off = {"NB": 0.24, "LR": 0.08, "LAG": -0.08, "PERSIST": -0.24}
    for n in ("NB", "LR", "LAG", "PERSIST"):
        xs = [r[n] for r in rows]
        err = [r["sd"][n] if r["sd"] else 0 for r in rows]
        axes[0].errorbar(xs, ypos + off[n], xerr=err, fmt=MARK[n], color=COL[n], ms=4.2, lw=0.9,
                         capsize=1.8, label=NAME[n])
    axes[0].set_yticks(ypos); axes[0].set_yticklabels([r["regime"] for r in rows], fontsize=7.2)
    axes[0].set_xlabel("Accuracy (%)"); axes[0].set_xlim(91.5, 100.5)
    axes[0].set_title("(a) Accuracy")
    handles, labels = axes[0].get_legend_handles_labels()
    for n in ("NB", "LR", "LAG"):
        axes[1].scatter([r[f"ll_{n}"] for r in rows], ypos + off[n], marker=MARK[n], color=COL[n], s=18)
    axes[1].set_xscale("log"); axes[1].set_xlabel("Logarithmic loss (log scale)")
    axes[1].set_xticks([0.03, 0.1, 0.3, 1.0]); axes[1].set_xticklabels(["0.03", "0.1", "0.3", "1.0"])
    axes[1].minorticks_off(); axes[1].set_xlim(0.025, 1.2)
    axes[1].set_title("(b) Logarithmic loss")
    axes[1].set_yticks(ypos); axes[1].set_yticklabels([]); axes[1].tick_params(axis="y", length=0)
    for ax in axes:
        ax.set_ylim(-0.6, len(rows) - 0.4)
        for yy in ypos[:-1] - 0.5:
            ax.axhline(yy, color=COL["LIGHT"], lw=0.5)
    fig.legend(handles, labels, ncol=4, fontsize=6.6, frameon=False, loc="lower center",
               bbox_to_anchor=(0.5, -0.02))
    fig.tight_layout(w_pad=0.8, rect=(0, 0.06, 1, 1))
    return _save(fig, "fig05_regimes.png")


# ---------------------------------------------------------------------------
# Figure 6: transitions and risk-coverage
# ---------------------------------------------------------------------------
def fig_transitions(results: dict) -> Path:
    tr = results["transitions_cv"]
    sel = results["selective_cv"]["rows"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw={"width_ratios": [1, 1.25]})
    ax = axes[0]
    names = ("NB", "LR", "LAG", "PERSIST")
    x = np.arange(2); w = 0.2
    for i, n in enumerate(names):
        vals = [tr["stable"][f"accuracy_{n}"], tr["transition"][f"accuracy_{n}"]]
        bars = ax.bar(x + (i - 1.5) * w, vals, w, color=COL[n], label=NAME[n])
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 1.5, f"{v:.1f}", ha="center", va="bottom",
                    fontsize=5.2, rotation=90)
    ax.set_xticks(x)
    ax.set_xticklabels([f"Stable class\n(n = {tr['stable']['n']:,})", f"Class transition\n(n = {tr['transition']['n']})"])
    ax.set_ylabel("Out-of-fold accuracy (%)"); ax.set_ylim(0, 150); ax.set_yticks([0, 20, 40, 60, 80, 100])
    ax.set_title("(a) Accuracy by transition status")
    ax.legend(fontsize=5.8, frameon=False, ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.0))
    ax = axes[1]
    total = sel[0]["transitions_total"]
    for n in ("NB", "LR", "LAG"):
        rows = [r for r in sel if r["model"] == n]
        defer = [100 * (1 - r["coverage"]) for r in rows]
        caught = [100 * r["transitions_deferred"] / total for r in rows]
        ax.plot(defer, caught, "-" + MARK[n], color=COL[n], ms=3.6, lw=1.4,
                label=f"{NAME[n]} (AUC = {tr[f'auc_uncertainty_flags_transition_{n}']:.2f})")
    ax.plot([0, 10], [0, 10], ls=":", color=COL["GREY"], lw=1, label="Random deferral")
    ax.set_xlabel("Least-certain country-years deferred (%)")
    ax.set_ylabel(f"Transitions captured (% of {total})")
    ax.set_title("(b) Uncertainty-guided review")
    ax.legend(fontsize=6, frameon=False, loc="upper left")
    ax.set_ylim(0, 80)
    fig.tight_layout(w_pad=1.4)
    return _save(fig, "fig06_transitions.png")


# ---------------------------------------------------------------------------
# Figure 7: threshold sensitivity
# ---------------------------------------------------------------------------
def fig_threshold(results: dict) -> Path:
    rows = results["threshold_sensitivity"]
    q = [100 * r["quantile"] for r in rows]
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.9))
    for n, key in (("NB", "cv_accuracy_NB"), ("LR", "cv_accuracy_LR"), ("PERSIST", "cv_accuracy_PERSIST")):
        axes[0].plot(q, [r[key] for r in rows], "-" + MARK[n], color=COL[n], ms=4, lw=1.5, label=NAME[n])
    axes[0].set_xticks(q)
    axes[0].set_xticklabels([f"{int(a)}th\nτ={r['threshold']:g}" for a, r in zip(q, rows)], fontsize=6.6)
    axes[0].set_xlabel("Threshold percentile of the year-t rate")
    axes[0].set_ylabel("10-fold CV accuracy (%)"); axes[0].set_title("(a) Accuracy")
    axes[0].legend(fontsize=6.4, frameon=False, loc="lower left")
    for n in ("NB", "LR"):
        axes[1].plot(q, [r[f"log_loss_{n}"] for r in rows], "-" + MARK[n], color=COL[n], ms=4, lw=1.5, label=NAME[n])
    axes[1].set_yscale("log"); axes[1].set_xticks(q)
    axes[1].set_yticks([0.05, 0.1, 0.3, 1, 3]); axes[1].set_yticklabels(["0.05", "0.1", "0.3", "1", "3"])
    axes[1].minorticks_off()
    axes[1].set_xticklabels([f"{int(a)}th" for a in q])
    axes[1].set_xlabel("Threshold percentile of the year-t rate")
    axes[1].set_ylabel("Hold-out log loss (log scale)"); axes[1].set_title("(b) Logarithmic loss")
    axes[1].legend(fontsize=6.4, frameon=False)
    fig.tight_layout(w_pad=1.4)
    return _save(fig, "fig07_threshold_sensitivity.png")


# ---------------------------------------------------------------------------
# Figure 8: predictor contribution
# ---------------------------------------------------------------------------
LABEL = {"Prev_Rate": "Previous rate", "Prev_Width": "Previous interval width", "Trend_3yr": "Three-year trend",
         "Baseline_Rate": "Baseline rate", "Year": "Year", "WHO_Region": "WHO region (5 indicators)",
         "Region_Africa": "Region: Africa", "Region_Americas": "Region: Americas",
         "Region_Eastern Mediterranean": "Region: E. Mediterranean", "Region_South-East Asia": "Region: South-East Asia",
         "Region_Western Pacific": "Region: Western Pacific"}


def fig_contribution(results: dict) -> Path:
    cb = results["contribution"]["lr_coefficient_bootstrap"]
    perm = results["contribution"]["permutation_importance"]
    fig, axes = plt.subplots(1, 2, figsize=(7.3, 3.2), gridspec_kw={"width_ratios": [1.15, 1]})
    ax = axes[0]
    feats = sorted(cb, key=lambda f: abs(cb[f]["estimate"]))
    yy = np.arange(len(feats))
    est = [cb[f]["estimate"] for f in feats]
    lo = [cb[f]["estimate"] - cb[f]["ci95"][0] for f in feats]
    hi = [cb[f]["ci95"][1] - cb[f]["estimate"] for f in feats]
    ax.errorbar(est, yy, xerr=[lo, hi], fmt="s", color=COL["LR"], ms=3.6, lw=1, capsize=2)
    ax.axvline(0, color=COL["GREY"], lw=0.8)
    ax.set_yticks(yy); ax.set_yticklabels([LABEL[f] for f in feats], fontsize=7)
    ax.set_xlabel("Standardised coefficient (95% bootstrap CI)")
    ax.set_title("(a) Logistic regression coefficients")
    ax = axes[1]
    groups = sorted(perm, key=lambda g: perm[g]["LR"]["auc"]["mean"] + perm[g]["NB"]["auc"]["mean"])
    yy = np.arange(len(groups))
    for k, n in enumerate(("NB", "LR")):
        vals = [perm[g][n]["auc"]["mean"] for g in groups]
        sds = [perm[g][n]["auc"]["sd"] for g in groups]
        ax.barh(yy + (0.2 if n == "NB" else -0.2), vals, 0.38, xerr=sds, color=COL[n], label=NAME[n],
                error_kw={"lw": 0.7, "capsize": 1.5})
    ax.set_yticks(yy); ax.set_yticklabels([LABEL[g] for g in groups], fontsize=7)
    ax.axvline(0, color=COL["GREY"], lw=0.8)
    ax.set_xlabel("Decrease in hold-out AUC when permuted")
    ax.set_title("(b) Permutation importance")
    ax.legend(fontsize=6.4, frameon=False, loc="lower right")
    fig.tight_layout(w_pad=1.2)
    return _save(fig, "fig08_contribution.png")


# ---------------------------------------------------------------------------
# Appendix figures
# ---------------------------------------------------------------------------
def fig_predictor_distributions(S) -> Path:
    d = S.clean
    cols = [("Prev_Rate", True), ("Prev_Width", True), ("Baseline_Rate", True), ("Trend_3yr", False), ("Year", False)]
    fig, axes = plt.subplots(1, 5, figsize=(7.4, 2.5))
    for ax, (c, logged) in zip(axes, cols):
        vals = [d.loc[d.HighBurden == k, c].to_numpy() for k in (0, 1)]
        if logged:
            vals = [np.log1p(v) for v in vals]
        bp = ax.boxplot(vals, widths=0.55, patch_artist=True, showfliers=True,
                        flierprops={"markersize": 1.5, "alpha": 0.4})
        for patch, col in zip(bp["boxes"], (COL["LR"], COL["NB"])):
            patch.set_facecolor(col); patch.set_alpha(0.75)
        for med in bp["medians"]:
            med.set_color("black")
        ax.set_xticks([1, 2]); ax.set_xticklabels(["Low", "High"])
        ax.set_title(LABEL[c] + ("\n(log 1 + x)" if logged else ""), fontsize=7.2)
        ax.tick_params(labelsize=6.6)
    fig.tight_layout(w_pad=0.6)
    return _save(fig, "figB1_predictor_distributions.png")


def fig_correlation(audit: dict) -> Path:
    order = C.NUMERIC_PREDICTORS
    m = np.array([[audit["predictor_correlation"][a][b] for b in order] for a in order])
    rpb = [audit["point_biserial"][c] for c in order]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw={"width_ratios": [1.1, 1]})
    im = axes[0].imshow(m, cmap="RdBu_r", vmin=-1, vmax=1)
    for i in range(len(order)):
        for j in range(len(order)):
            axes[0].text(j, i, f"{m[i, j]:.2f}", ha="center", va="center", fontsize=6.4,
                         color="white" if abs(m[i, j]) > 0.6 else "black")
    axes[0].set_xticks(range(len(order))); axes[0].set_yticks(range(len(order)))
    short = ["Year", "Prev. rate", "Prev. width", "Trend", "Baseline"]
    axes[0].set_xticklabels(short, rotation=35, ha="right", fontsize=6.8); axes[0].set_yticklabels(short, fontsize=6.8)
    axes[0].set_title("(a) Pearson correlation among predictors")
    fig.colorbar(im, ax=axes[0], fraction=0.046, pad=0.03).ax.tick_params(labelsize=6)
    idx = np.argsort(rpb)
    axes[1].barh([short[i] for i in idx], [rpb[i] for i in idx],
                 color=[COL["NB"] if rpb[i] > 0 else COL["LR"] for i in idx])
    for k, i in enumerate(idx):
        axes[1].text(rpb[i] + (0.02 if rpb[i] > 0 else -0.02), k, f"{rpb[i]:+.3f}", va="center",
                     ha="left" if rpb[i] > 0 else "right", fontsize=6.6)
    axes[1].axvline(0, color=COL["GREY"], lw=0.8); axes[1].set_xlim(-0.45, 0.85)
    axes[1].set_xlabel("Point-biserial correlation with high burden")
    axes[1].set_title("(b) Marginal association with the label")
    fig.tight_layout(w_pad=1.2)
    return _save(fig, "figB2_correlation.png")


def fig_confusion(results: dict, preds: dict, S) -> Path:
    y_te = S.y[S.idx_test]
    fig, axes = plt.subplots(1, 4, figsize=(7.4, 2.15))
    for ax, n in zip(axes, ("NB", "LR", "LAG", "PERSIST")):
        cm = confusion_matrix(y_te, preds[n], labels=[0, 1])
        from matplotlib.colors import LinearSegmentedColormap
        cmap = LinearSegmentedColormap.from_list(n, ["#FFFFFF", COL[n]])
        ax.imshow(cm, cmap=cmap, vmin=0, vmax=cm.max())
        for (i, j), v in np.ndenumerate(cm):
            ax.text(j, i, str(v), ha="center", va="center", fontsize=9, weight="bold",
                    color="white" if v > cm.max() / 2 else "black")
        ax.set_xticks([0, 1]); ax.set_xticklabels(["Low", "High"], fontsize=7)
        ax.set_yticks([0, 1]); ax.set_yticklabels(["Low", "High"], fontsize=7)
        ax.set_xlabel("Predicted", fontsize=7.5)
        if n == "NB":
            ax.set_ylabel("Observed", fontsize=7.5)
        ax.set_title(NAME[n].replace("Lagged-rate logistic model", "Lagged-rate logistic"), fontsize=7.6,
                     color=COL[n])
        for s in ax.spines.values():
            s.set_visible(False)
    fig.tight_layout(w_pad=0.6)
    return _save(fig, "figC1_confusion_matrices.png")


def fig_repeated_cv(results: dict) -> Path:
    f = results["repeated_cv"]["folds"]
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))
    names = ("NB", "LR", "LAG", "PERSIST")
    bp = axes[0].boxplot([f[n]["accuracy"] for n in names], widths=0.55, patch_artist=True,
                         flierprops={"markersize": 2})
    for patch, n in zip(bp["boxes"], names):
        patch.set_facecolor(COL[n]); patch.set_alpha(0.75)
    for med in bp["medians"]:
        med.set_color("black")
    axes[0].set_xticks(range(1, 5)); axes[0].set_xticklabels(["NB", "LR", "Lagged\nlogistic", "Persistence"], fontsize=7)
    axes[0].set_ylabel("Accuracy (%)"); axes[0].set_title(f"(a) Accuracy, {results['repeated_cv']['resamples']} resamples")
    names3 = ("NB", "LR", "LAG")
    bp = axes[1].boxplot([f[n]["log_loss"] for n in names3], widths=0.55, patch_artist=True,
                         flierprops={"markersize": 2})
    for patch, n in zip(bp["boxes"], names3):
        patch.set_facecolor(COL[n]); patch.set_alpha(0.75)
    for med in bp["medians"]:
        med.set_color("black")
    axes[1].set_yscale("log"); axes[1].set_xticks(range(1, 4))
    axes[1].set_xticklabels(["NB", "LR", "Lagged\nlogistic"], fontsize=7)
    axes[1].set_ylabel("Log loss (log scale)"); axes[1].set_title("(b) Logarithmic loss")
    fig.tight_layout(w_pad=1.4)
    return _save(fig, "figC2_repeated_cv.png")


def fig_rolling(results: dict) -> Path:
    rows = results["rolling_origin"]["by_year"]
    yrs = [r["year"] for r in rows]
    fig, axes = plt.subplots(2, 1, figsize=(7.0, 3.9), sharex=True, gridspec_kw={"height_ratios": [2.2, 1]})
    for n in ("NB", "LR", "LAG", "PERSIST"):
        axes[0].plot(yrs, [r[f"accuracy_{n}"] for r in rows], "-" + MARK[n], color=COL[n], ms=3.6, lw=1.3,
                     label=NAME[n])
    axes[0].set_ylabel("Accuracy in the test year (%)"); axes[0].set_ylim(90.5, 100.8)
    axes[0].legend(ncol=4, fontsize=6.3, frameon=False, loc="lower center")
    axes[0].set_title("(a) Expanding-window accuracy")
    axes[1].bar(yrs, [r["transitions"] for r in rows], color=COL["GREY"])
    axes[1].set_ylabel("Transitions"); axes[1].set_xlabel("Test year")
    axes[1].set_title("(b) Class transitions in the test year")
    axes[1].set_xticks(yrs); axes[1].tick_params(axis="x", labelsize=6.8)
    fig.tight_layout(h_pad=0.6)
    return _save(fig, "figD1_rolling_origin.png")


def fig_learning_curve(results: dict) -> Path:
    rows = results["learning_curve"]
    n = [r["train_n"] for r in rows]
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))
    for m in ("NB", "LR"):
        a = np.array([r[f"accuracy_{m}"] for r in rows]); s = np.array([r[f"accuracy_sd_{m}"] for r in rows])
        axes[0].plot(n, a, "-" + MARK[m], color=COL[m], ms=3.6, lw=1.4, label=NAME[m])
        axes[0].fill_between(n, a - s, a + s, color=COL[m], alpha=0.15, lw=0)
        l = np.array([r[f"log_loss_{m}"] for r in rows]); ls = np.array([r[f"log_loss_sd_{m}"] for r in rows])
        axes[1].plot(n, l, "-" + MARK[m], color=COL[m], ms=3.6, lw=1.4, label=NAME[m])
        axes[1].fill_between(n, np.maximum(l - ls, 1e-3), l + ls, color=COL[m], alpha=0.15, lw=0)
    for ax in axes:
        ax.set_xscale("log"); ax.set_xlabel("Training records (log scale)")
        ax.legend(fontsize=6.4, frameon=False)
    axes[0].set_ylabel("Hold-out accuracy (%)"); axes[0].set_title("(a) Accuracy (mean ± SD)")
    axes[1].set_yscale("log"); axes[1].set_ylabel("Hold-out log loss (log scale)")
    axes[1].set_title("(b) Logarithmic loss (mean ± SD)")
    fig.tight_layout(w_pad=1.4)
    return _save(fig, "figE1_learning_curve.png")


def fig_distance(results: dict) -> Path:
    bands = results["error_localisation"]["distance_bands"]
    x = np.arange(len(bands)); w = 0.26
    fig, ax = plt.subplots(figsize=(6.8, 2.8))
    for off, n in zip((-w, 0, w), ("NB", "LR", "PERSIST")):
        bars = ax.bar(x + off, [b[f"accuracy_{n}"] for b in bands], w, color=COL[n], label=NAME[n])
        ax.bar_label(bars, fmt="%.1f", fontsize=5.8, padding=1.5)
    ax.set_xticks(x); ax.set_xticklabels([f"{b['band']}\n(n = {b['n']})" for b in bands], fontsize=7)
    ax.set_xlabel("Absolute distance of the year-t rate from τ (deaths per 100,000)")
    ax.set_ylabel("Hold-out accuracy (%)"); ax.set_ylim(0, 118)
    ax.legend(ncol=3, fontsize=6.6, frameon=False, loc="upper left")
    fig.tight_layout()
    return _save(fig, "figF1_error_by_distance.png")


# ---------------------------------------------------------------------------
# Figures added at revision
# ---------------------------------------------------------------------------
COL.update({"GBM": "#6A3D9A", "RF": "#17A2B8", "NB_platt": "#E59866"})
NAME.update({"GBM": "Gradient boosting", "RF": "Random forest", "NB_platt": "Naïve Bayes, Platt-recalibrated"})
MARK.update({"GBM": "P", "RF": "X", "NB_platt": "v"})


def _capture_curve(p, transition, fractions):
    n = len(p)
    order = np.lexsort((np.arange(n), np.abs(p - 0.5)))
    return [100 * transition[order[:int(round(f * n))]].sum() / transition.sum() for f in fractions]


def fig_flexible(results: dict, state: dict) -> Path:
    """Figure 9: flexible learners against persistence across regimes, and their review-targeting curves."""
    fx = results["revision"]["flexible"]
    cv, g = results["cv"]["summary"], results["grouped_cv"]["pooled"]
    tp, ro, cd = results["robustness"]["temporal"], results["rolling_origin"]["pooled"], results["robustness"]["country_disjoint"]
    h = results["holdout"]
    regimes = [
        ("Stratified hold-out", {"NB": h["NB"]["accuracy"], "LR": h["LR"]["accuracy"],
                                 "GBM": fx["holdout"]["GBM"]["accuracy"], "RF": fx["holdout"]["RF"]["accuracy"],
                                 "PERSIST": h["baselines"]["persistence"]["accuracy"]}),
        ("Stratified 10-fold CV", {**{n: cv[n]["accuracy"]["mean"] for n in ("NB", "LR", "PERSIST")},
                                   **{n: fx["cv"][n]["accuracy"]["mean"] for n in ("GBM", "RF")}}),
        ("Repeated 10×10 CV", {**{n: results["repeated_cv"]["summary"][n]["accuracy"]["mean"] for n in ("NB", "LR", "PERSIST")},
                               **{n: fx["repeated_cv"][n]["accuracy"]["mean"] for n in ("GBM", "RF")}}),
        ("Country-grouped CV", {**{n: g[n]["accuracy"] for n in ("NB", "LR", "PERSIST")},
                                **{n: fx["grouped_cv"][n]["pooled"]["accuracy"] for n in ("GBM", "RF")}}),
        ("Country-disjoint 70/30", {**{n: cd[n]["accuracy"] for n in ("NB", "LR", "PERSIST")},
                                    **{n: fx["country_disjoint"][n]["accuracy"] for n in ("GBM", "RF")}}),
        ("Prospective 2019–2024", {**{n: tp[n]["accuracy"] for n in ("NB", "LR", "PERSIST")},
                                   **{n: fx["temporal"][n]["accuracy"] for n in ("GBM", "RF")}}),
        ("Rolling origin 2010–2024", {**{n: ro[n]["accuracy"] for n in ("NB", "LR", "PERSIST")},
                                      **{n: fx["rolling_origin"][n]["accuracy"] for n in ("GBM", "RF")}}),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.4), gridspec_kw={"width_ratios": [1.35, 1]})
    ax = axes[0]
    ypos = np.arange(len(regimes))[::-1]
    off = {"NB": 0.28, "LR": 0.14, "GBM": 0.0, "RF": -0.14, "PERSIST": -0.28}
    for n in ("NB", "LR", "GBM", "RF", "PERSIST"):
        ax.scatter([r[1][n] for r in regimes], ypos + off[n], marker=MARK[n], color=COL[n], s=20, label=NAME[n], zorder=3)
    ax.set_yticks(ypos); ax.set_yticklabels([r[0] for r in regimes], fontsize=7.2)
    ax.set_xlabel("Accuracy (%)"); ax.set_xlim(93.5, 100); ax.set_title("(a) Accuracy across regimes")
    ax.set_ylim(-0.6, len(regimes) - 0.4)
    for yy in ypos[:-1] - 0.5:
        ax.axhline(yy, color=COL["LIGHT"], lw=0.5)
    ax.legend(fontsize=6, frameon=False, loc="lower left", ncol=1)
    ax = axes[1]
    S = state["study"]; tr = S.transition
    fr = [0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.075, 0.10]
    curves = {"LR": state["cv_state"]["oof"]["LR"], "LAG": state["cv_state"]["oof"]["LAG"],
              "GBM": state["flex_oof"]["GBM"], "RF": state["flex_oof"]["RF"], "NB_platt": state["recal_oof"]["NB_platt"]}
    for n, p in curves.items():
        auc = results["revision"]["flexible"]["transitions_cv"][n]["auc_uncertainty"] if n in ("GBM", "RF") else (
            results["revision"]["recalibration"]["cv"]["NB_platt"]["auc_uncertainty"] if n == "NB_platt" else
            results["transitions_cv"][f"auc_uncertainty_flags_transition_{n}"])
        ax.plot([100 * f for f in fr], _capture_curve(p, tr, fr), "-" + MARK[n], color=COL[n], ms=3.2, lw=1.2,
                label=f"{NAME[n]} ({auc:.2f})")
    ax.plot([0, 10], [0, 10], ls=":", color=COL["GREY"], lw=1, label="Random deferral")
    ax.set_xlabel("Least-certain country-years deferred (%)"); ax.set_ylabel("Transitions captured (% of 44)")
    ax.set_title("(b) Uncertainty-guided review"); ax.set_ylim(0, 80)
    ax.legend(fontsize=5.6, frameon=False, loc="lower right", title="Rule (AUC of uncertainty)", title_fontsize=5.8)
    fig.tight_layout(w_pad=1.2)
    return _save(fig, "fig09_flexible_learners.png")


def fig_review_scenario(results: dict) -> Path:
    """Figure 10: prospective review scenario, transitions per year and those captured with k = 5 reviews."""
    sc = results["revision"]["review_scenario"]; k = sc["k_primary"]
    rows = sc["by_year"]; yrs = [r["year"] for r in rows]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.0), gridspec_kw={"width_ratios": [1.5, 1]})
    ax = axes[0]
    ax.bar(yrs, [r["transitions"] for r in rows], color=COL["LIGHT"], label="Transitions that occurred", width=0.75)
    w = 0.22
    for i, n in enumerate(("LAG", "GBM", "LR")):
        ax.bar(np.array(yrs) + (i - 1) * w, [r[f"captured_{n}_k{k}"] for r in rows], w, color=COL[n],
               label=f"Captured: {NAME[n]}")
    ax.set_xlabel("Test year"); ax.set_ylabel("Country-years"); ax.set_xticks(yrs[::2])
    ax.set_title(f"(a) Transitions captured with {k} reviews per year")
    ax.set_ylim(0, max(r["transitions"] for r in rows) + 2.8)
    ax.legend(fontsize=6, frameon=False, loc="upper center", ncol=2)
    ax = axes[1]
    s = sc["summary"]
    for n in ("LAG", "GBM", "LR"):
        ax.plot(C.REVIEW_K, [100 * s[f"{n}_k{kk}"]["captured"] / sc["transitions"] for kk in C.REVIEW_K],
                "-" + MARK[n], color=COL[n], ms=4, lw=1.4, label=NAME[n])
    ax.plot(C.REVIEW_K, [100 * s[f"LR_k{kk}"]["random_expected"] / sc["transitions"] for kk in C.REVIEW_K],
            ls=":", color=COL["GREY"], lw=1.2, label="Random review")
    ax.set_xticks(C.REVIEW_K); ax.set_xlabel("Country-years reviewed per year (k)")
    ax.set_ylabel(f"Transitions captured (% of {sc['transitions']})"); ax.set_ylim(0, 100)
    ax.set_title("(b) Yield by review budget"); ax.legend(fontsize=6, frameon=False, loc="upper left")
    fig.tight_layout(w_pad=1.2)
    return _save(fig, "fig10_review_scenario.png")


def fig_power(results: dict) -> Path:
    """Figure J1: simulated power of the exact McNemar test on pooled out-of-fold predictions."""
    pw = results["revision"]["power"]
    fig, ax = plt.subplots(figsize=(5.2, 3.2))
    cols = ["#2E8B57", "#1F4E79", "#D68910", "#C0392B"]
    for c, e in zip(cols, C.POWER_STABLE_ERROR_RATES):
        rows = [r for r in pw["simulated_power"] if r["stable_error_rate"] == e]
        ax.plot([100 * r["fraction_corrected"] for r in rows], [100 * r["power"] for r in rows], "-o", ms=3, lw=1.3,
                color=c, label=f"stable error rate {100 * e:.2f}%")
    for n, yy in (("LR", 46), ("GBM", 30), ("RF", 14)):
        v = pw["observed_oof"][n]
        x = 100 * v["transitions_corrected"] / pw["all_transitions"]
        ax.axvline(x, color=COL[n], lw=0.8, ls="--")
        ax.text(x + 0.8, yy, f"{n}: {v['transitions_corrected']} corrected,\n{v['stable_errors']} stable errors",
                fontsize=5.8, color=COL[n])
    ax.axhline(80, color=COL["GREY"], lw=0.7, ls=":")
    ax.set_xlabel(f"Transitions corrected by a hypothetical learner (% of {pw['all_transitions']})")
    ax.set_ylabel("Power to beat persistence (%)"); ax.set_ylim(0, 102)
    ax.legend(fontsize=6.2, frameon=False, loc="lower right")
    fig.tight_layout()
    return _save(fig, "figJ1_power.png")


def make_all(audit: dict, results: dict, state: dict) -> list[Path]:
    S = state["study"]
    return [
        fig_framework(audit, results), fig_sample_structure(audit, S), fig_roc_pr(results),
        fig_calibration(results, state["proba"], S), fig_regimes(results), fig_transitions(results),
        fig_threshold(results), fig_contribution(results), fig_predictor_distributions(S),
        fig_correlation(audit), fig_confusion(results, state["preds"], S), fig_repeated_cv(results),
        fig_rolling(results), fig_learning_curve(results), fig_distance(results),
        fig_flexible(results, state), fig_review_scenario(results), fig_power(results),
    ]
