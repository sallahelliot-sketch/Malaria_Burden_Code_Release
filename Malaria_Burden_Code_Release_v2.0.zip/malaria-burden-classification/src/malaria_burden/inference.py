"""Paired statistical inference: McNemar, DeLong, bootstrap, fold-level tests, Holm."""
from __future__ import annotations

import numpy as np
from scipy import stats
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from . import config as C
from .metrics import brier, logloss


def mcnemar(pred_a, pred_b, y_true) -> dict:
    """Equation (15). n01: a wrong, b right; n10: a right, b wrong. Exact binomial p-value.

    The odds ratio n10/n01 is the effect size; it exceeds 1 when rule a is the more accurate.
    The continuity-corrected chi-square is reported for reference only.
    """
    ca, cb = (pred_a == y_true), (pred_b == y_true)
    n01 = int(np.sum(~ca & cb))
    n10 = int(np.sum(ca & ~cb))
    n = n01 + n10
    if n == 0:
        return {"n01": n01, "n10": n10, "statistic": 0.0, "p": 1.0, "odds_ratio": None}
    chi2 = (abs(n10 - n01) - 1) ** 2 / n
    p = float(stats.binomtest(n10, n, 0.5).pvalue)
    odds = (n10 / n01) if n01 else float("inf")
    return {"n01": n01, "n10": n10, "statistic": round(chi2, 4), "p": p,
            "odds_ratio": round(odds, 4) if np.isfinite(odds) else None}


def _midrank(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x)
    sx = x[order]
    n = len(x)
    ranks = np.zeros(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j < n and sx[j] == sx[i]:
            j += 1
        ranks[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    out = np.empty(n, dtype=float)
    out[order] = ranks
    return out


def delong_test(y_true, proba_a, proba_b) -> dict:
    """DeLong's test for two correlated areas under the curve."""
    order = np.argsort(-y_true, kind="mergesort")
    labels = y_true[order]
    m = int(labels.sum())
    n = len(labels) - m
    preds = np.vstack([proba_a[order], proba_b[order]])
    tx, ty, tz = np.empty([2, m]), np.empty([2, n]), np.empty([2, m + n])
    for r in range(2):
        tx[r] = _midrank(preds[r, :m])
        ty[r] = _midrank(preds[r, m:])
        tz[r] = _midrank(preds[r])
    aucs = tz[:, :m].sum(axis=1) / m / n - (m + 1) / (2 * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1 - (tz[:, m:] - ty) / m
    cov = np.cov(v01) / m + np.cov(v10) / n
    contrast = np.array([[1, -1]])
    var = float(np.asarray(contrast @ cov @ contrast.T).reshape(-1)[0])
    diff = float(aucs[0] - aucs[1])
    se = float(np.sqrt(var)) if var > 0 else 0.0
    z = diff / se if se > 0 else 0.0
    return {"auc_a": round(float(aucs[0]), 4), "auc_b": round(float(aucs[1]), 4),
            "difference": round(diff, 4), "se": round(se, 4), "z": round(z, 4),
            "p": float(2 * stats.norm.sf(abs(z))),
            "ci95": [round(diff - 1.96 * se, 4), round(diff + 1.96 * se, 4)]}


def paired_bootstrap(y_true, predictions: dict, probabilities: dict,
                     n_replicates: int = C.N_BOOTSTRAP, seed: int = C.SEED) -> dict:
    """Percentile intervals for each rule's accuracy and F1 and for the paired differences.

    Accuracy and F1 entries are in percentage points; AUC, Brier and log-loss
    differences are on their natural scale.
    """
    gen = np.random.default_rng(seed)
    idx = np.arange(len(y_true))
    keys = ("acc_LR", "acc_NB", "acc_PERSIST", "f1_LR", "f1_NB", "f1_PERSIST",
            "d_acc_LR_NB", "d_f1_LR_NB", "d_acc_PERSIST_LR", "d_acc_PERSIST_NB",
            "d_f1_PERSIST_LR", "d_f1_PERSIST_NB", "d_auc_LR_NB", "d_brier_LR_NB", "d_logloss_LR_NB")
    draws = {k: [] for k in keys}
    for _ in range(n_replicates):
        s = gen.choice(idx, size=len(idx), replace=True)
        if len(np.unique(y_true[s])) < 2:
            continue
        acc = {k: accuracy_score(y_true[s], v[s]) for k, v in predictions.items()}
        f1s = {k: f1_score(y_true[s], v[s], zero_division=0) for k, v in predictions.items()}
        auc = {k: roc_auc_score(y_true[s], v[s]) for k, v in probabilities.items()}
        for k in ("LR", "NB", "PERSIST"):
            draws[f"acc_{k}"].append(100 * acc[k]); draws[f"f1_{k}"].append(100 * f1s[k])
        draws["d_acc_LR_NB"].append(100 * (acc["LR"] - acc["NB"]))
        draws["d_f1_LR_NB"].append(100 * (f1s["LR"] - f1s["NB"]))
        draws["d_acc_PERSIST_LR"].append(100 * (acc["PERSIST"] - acc["LR"]))
        draws["d_acc_PERSIST_NB"].append(100 * (acc["PERSIST"] - acc["NB"]))
        draws["d_f1_PERSIST_LR"].append(100 * (f1s["PERSIST"] - f1s["LR"]))
        draws["d_f1_PERSIST_NB"].append(100 * (f1s["PERSIST"] - f1s["NB"]))
        draws["d_auc_LR_NB"].append(auc["LR"] - auc["NB"])
        draws["d_brier_LR_NB"].append(brier(y_true[s], probabilities["LR"][s])
                                      - brier(y_true[s], probabilities["NB"][s]))
        draws["d_logloss_LR_NB"].append(logloss(y_true[s], probabilities["LR"][s])
                                        - logloss(y_true[s], probabilities["NB"][s]))
    return {k: {"mean": round(float(np.mean(v)), 4),
                "ci95": [round(float(np.percentile(v, 2.5)), 4),
                         round(float(np.percentile(v, 97.5)), 4)],
                "replicates": len(v)}
            for k, v in draws.items()}


def holm(pvalues: list[float]) -> list[float]:
    """Equation (16): Holm step-down adjustment, preserving input order."""
    m = len(pvalues)
    order = np.argsort(pvalues)
    adj = np.empty(m, dtype=float)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * pvalues[i])
        adj[i] = min(1.0, running)
    return [float(v) for v in adj]


def paired_fold_tests(a: np.ndarray, b: np.ndarray) -> dict:
    """Paired t over matched folds with d_z and a Wilcoxon check."""
    a, b = np.asarray(a), np.asarray(b)
    delta = a - b
    t_stat, p_t = stats.ttest_rel(a, b)
    try:
        w_stat, p_w = stats.wilcoxon(a, b)
    except ValueError:
        w_stat, p_w = float("nan"), 1.0
    sd = float(np.std(delta, ddof=1))
    se = sd / np.sqrt(len(delta))
    crit = stats.t.ppf(0.975, len(delta) - 1)
    mean = float(np.mean(delta))
    return {"mean_difference": round(mean, 4), "sd_difference": round(sd, 4),
            "ci95": [round(mean - crit * se, 4), round(mean + crit * se, 4)],
            "t": round(float(t_stat), 4), "df": len(delta) - 1, "p_t": float(p_t),
            "wilcoxon_W": float(w_stat), "p_wilcoxon": float(p_w),
            "cohens_dz": round(mean / sd, 4) if sd > 0 else float("nan")}


def corrected_resampled_t(a: np.ndarray, b: np.ndarray, n_train: int, n_test: int) -> dict:
    """Equation (17): Nadeau-Bengio corrected resampled t-test for repeated k-fold cross-validation.

    The variance of the mean difference is inflated by (1/J + n_test/n_train) to account
    for the overlap of training sets across the J = k x r resamples.
    """
    d = np.asarray(a) - np.asarray(b)
    J = len(d)
    mean = float(np.mean(d))
    var = float(np.var(d, ddof=1))
    se = np.sqrt((1 / J + n_test / n_train) * var)
    t = mean / se if se > 0 else 0.0
    p = float(2 * stats.t.sf(abs(t), J - 1))
    crit = stats.t.ppf(0.975, J - 1)
    return {"mean_difference": round(mean, 4), "se_corrected": round(float(se), 4),
            "ci95": [round(mean - crit * se, 4), round(mean + crit * se, 4)],
            "t": round(float(t), 4), "df": J - 1, "p": p}
