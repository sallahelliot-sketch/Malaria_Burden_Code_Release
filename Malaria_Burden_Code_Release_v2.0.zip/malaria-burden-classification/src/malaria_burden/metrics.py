"""Discrimination, probabilistic-quality and calibration measures."""
from __future__ import annotations

import numpy as np
from scipy import optimize
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, brier_score_loss,
                             confusion_matrix, f1_score, log_loss, matthews_corrcoef,
                             precision_score, recall_score, roc_auc_score,
                             average_precision_score)

from . import config as C

EPS = 1e-12


def discrimination(y_true, y_hat, proba) -> dict:
    """Equation (14) and the label metrics: accuracy, precision, recall and F1 in per cent; AUC as a proportion."""
    return {
        "accuracy": 100 * accuracy_score(y_true, y_hat),
        "precision": 100 * precision_score(y_true, y_hat, zero_division=0),
        "recall": 100 * recall_score(y_true, y_hat, zero_division=0),
        "f1": 100 * f1_score(y_true, y_hat, zero_division=0),
        "auc": roc_auc_score(y_true, proba),
    }


def label_scores(y_true, y_hat) -> dict:
    """Label-only scores for rules that emit no probability."""
    return {
        "accuracy": round(100 * accuracy_score(y_true, y_hat), 4),
        "precision": round(100 * precision_score(y_true, y_hat, zero_division=0), 4),
        "recall": round(100 * recall_score(y_true, y_hat, zero_division=0), 4),
        "f1": round(100 * f1_score(y_true, y_hat, zero_division=0), 4),
        "specificity": round(100 * specificity(y_true, y_hat), 4),
        "mcc": round(float(matthews_corrcoef(y_true, y_hat)), 4),
        "balanced_accuracy": round(100 * float(balanced_accuracy_score(y_true, y_hat)), 4),
        "confusion": confusion(y_true, y_hat),
    }


def confusion(y_true, y_hat) -> dict:
    tn, fp, fn, tp = confusion_matrix(y_true, y_hat, labels=[0, 1]).ravel()
    return {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


def specificity(y_true, y_hat) -> float:
    c = confusion(y_true, y_hat)
    return c["tn"] / (c["tn"] + c["fp"]) if (c["tn"] + c["fp"]) else 0.0


def brier(y_true, proba) -> float:
    """Equation (18), first part."""
    return float(brier_score_loss(y_true, proba))


def logloss(y_true, proba) -> float:
    """Equation (18), second part, with probabilities clipped at 1e-12 to keep the loss finite."""
    return float(log_loss(y_true, np.clip(proba, EPS, 1 - EPS), labels=[0, 1]))


def expected_calibration_error(y_true, proba, bins: int = C.N_CALIBRATION_BINS):
    """Equation (19): equal-width bins; returns the weighted gap and per-bin detail."""
    edges = np.linspace(0, 1, bins + 1)
    error, rows = 0.0, []
    for i in range(bins):
        lo, hi = edges[i], edges[i + 1]
        mask = (proba >= lo) & (proba <= hi) if i == 0 else (proba > lo) & (proba <= hi)
        if mask.sum() == 0:
            rows.append({"bin": f"{lo:.1f}-{hi:.1f}", "n": 0, "confidence": None, "observed": None})
            continue
        conf, obs = float(proba[mask].mean()), float(y_true[mask].mean())
        error += mask.sum() / len(proba) * abs(obs - conf)
        rows.append({"bin": f"{lo:.1f}-{hi:.1f}", "n": int(mask.sum()),
                     "confidence": round(conf, 4), "observed": round(obs, 4)})
    return round(error, 4), rows


def calibration_intercept_slope(y_true, proba) -> dict:
    """Equation (20), logistic recalibration: logit P(Y=1) = a + b * logit(p).

    The slope b is estimated jointly with a; the calibration-in-the-large intercept is
    estimated with b fixed at 1 (offset model). Ideal values are slope 1 and intercept 0.
    Probabilities are clipped to [1e-6, 1 - 1e-6] so that saturated predictions remain finite.
    """
    p = np.clip(proba, 1e-6, 1 - 1e-6)
    lp = np.log(p / (1 - p))
    y = np.asarray(y_true, dtype=float)

    def nll(params, offset_only=False):
        a, b = (params[0], 1.0) if offset_only else params
        eta = a + b * lp
        return float(np.sum(np.logaddexp(0, eta) - y * eta))

    slope_fit = optimize.minimize(lambda q: nll(q), x0=np.array([0.0, 1.0]), method="BFGS")
    int_fit = optimize.minimize(lambda q: nll(q, offset_only=True), x0=np.array([0.0]), method="BFGS")
    return {"slope": round(float(slope_fit.x[1]), 4),
            "intercept_large": round(float(int_fit.x[0]), 4)}


def probabilistic_profile(y_true, proba, y_hat) -> dict:
    """Every probabilistic and threshold-free summary reported for one classifier."""
    ece, bins = expected_calibration_error(y_true, proba)
    extreme = (proba < C.EXTREME_PROBABILITY) | (proba > 1 - C.EXTREME_PROBABILITY)
    mid = (proba >= 0.1) & (proba <= 0.9)
    return {
        "brier": round(brier(y_true, proba), 4),
        "log_loss": round(logloss(y_true, proba), 4),
        "ece": ece, "bins": bins,
        **calibration_intercept_slope(y_true, proba),
        "average_precision": round(float(average_precision_score(y_true, proba)), 4),
        "mcc": round(float(matthews_corrcoef(y_true, y_hat)), 4),
        "balanced_accuracy": round(100 * float(balanced_accuracy_score(y_true, y_hat)), 4),
        "specificity": round(100 * specificity(y_true, y_hat), 4),
        "pct_probabilities_extreme": round(100 * float(np.mean(extreme)), 2),
        "n_probabilities_between_0.1_0.9": int(mid.sum()),
    }
