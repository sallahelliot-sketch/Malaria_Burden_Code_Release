"""Learners, the fit-and-score routine and the reference rules."""
from __future__ import annotations

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import StandardScaler

from . import config as C
from .metrics import discrimination, confusion


def make_learners(lr_c: float = 1.0, nb_smoothing: float = 1e-9) -> dict:
    """Fresh, unfitted instances of the two classifiers.

    The defaults are the standard parameterisations used for every headline result;
    the arguments exist only for the nested-tuning sensitivity analysis.
    """
    return {
        "NB": GaussianNB(var_smoothing=nb_smoothing),
        "LR": LogisticRegression(C=lr_c, max_iter=C.LR_MAX_ITER, random_state=C.SEED),
    }


def fit_predict(X_tr: np.ndarray, y_tr: np.ndarray, X_te: np.ndarray,
                learners: dict | None = None) -> tuple[dict, dict]:
    """Standardise inside the training partition, fit each learner, return probabilities.

    The scaler is estimated on X_tr only and applied unchanged to X_te (Equation 7).
    Returns (probabilities, fitted models).
    """
    scaler = StandardScaler().fit(X_tr)
    Z_tr, Z_te = scaler.transform(X_tr), scaler.transform(X_te)
    learners = learners or make_learners()
    proba, fitted = {}, {}
    for name, model in learners.items():
        model.fit(Z_tr, y_tr)
        proba[name] = model.predict_proba(Z_te)[:, 1]
        fitted[name] = model
    return proba, fitted


def label(p: np.ndarray) -> np.ndarray:
    """Apply the operating point of Equation (11)."""
    return (p >= C.DECISION_THRESHOLD).astype(int)


def fit_and_score(X_tr, y_tr, X_te, y_te, features: list[str] | None = None) -> tuple[dict, dict, dict]:
    """Fit both learners and return metrics, probabilities and labels on the held-out rows."""
    proba, fitted = fit_predict(X_tr, y_tr, X_te)
    metrics, preds = {}, {}
    for name, p in proba.items():
        y_hat = label(p)
        metrics[name] = {k: round(v, 4) for k, v in discrimination(y_te, y_hat, p).items()}
        metrics[name]["confusion"] = confusion(y_te, y_hat)
        preds[name] = y_hat
    if features is not None:
        lr = fitted["LR"]
        metrics["_lr_coefficients"] = {f: round(float(c), 4) for f, c in zip(features, lr.coef_[0])}
        metrics["_lr_intercept"] = round(float(lr.intercept_[0]), 4)
        nb = fitted["NB"]
        metrics["_nb_theta"] = {f: [round(float(nb.theta_[k, j]), 4) for k in (0, 1)]
                                for j, f in enumerate(features)}
        metrics["_nb_var"] = {f: [round(float(nb.var_[k, j]), 6) for k in (0, 1)]
                              for j, f in enumerate(features)}
        metrics["_nb_prior"] = [round(float(v), 4) for v in nb.class_prior_]
    return metrics, proba, preds


def persistence_rule(prev_rate: np.ndarray, threshold: float) -> np.ndarray:
    """Equation (12): carry the previous year's class forward."""
    return (prev_rate >= threshold).astype(int)
