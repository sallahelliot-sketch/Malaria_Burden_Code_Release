"""End-to-end orchestration: runs every experiment and writes the audit files."""
from __future__ import annotations

import json
import platform
import time
from pathlib import Path

import numpy as np

from . import config as C
from . import experiments as E
from .data import build_dataset, describe_sample, load_raw, raw_provenance, write_clean_workbook
from .revision import run_revision


def _jsonable(obj):
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items() if not str(k).startswith("_")}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [_jsonable(v) for v in obj.tolist()]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def environment() -> dict:
    import matplotlib, pandas, scipy, sklearn, openpyxl
    return {"python": platform.python_version(), "numpy": np.__version__, "pandas": pandas.__version__,
            "scipy": scipy.__version__, "scikit-learn": sklearn.__version__,
            "matplotlib": matplotlib.__version__, "openpyxl": openpyxl.__version__,
            "platform": platform.platform(), "processor": platform.machine()}


def run_all(verbose: bool = True) -> tuple[dict, dict, dict]:
    """Run the complete study. Returns (audit, results, state) and writes results/*.json."""
    t0 = time.time()
    log = (lambda m: print(f"[{time.time() - t0:6.1f}s] {m}", flush=True)) if verbose else (lambda m: None)
    for d in (C.DATA_DIR, C.RESULTS_DIR, C.FIGURE_DIR, C.TABLE_DIR):
        d.mkdir(parents=True, exist_ok=True)

    raw = load_raw()
    clean, audit = build_dataset(raw)
    audit.update(raw_provenance() if C.RAW_PATH.exists() else {})
    audit = describe_sample(clean, audit)
    write_clean_workbook(clean, audit)
    log(f"dataset: {audit['final_rows']} records, threshold {audit['median_threshold']}")

    S = E.Study(clean, audit)
    results: dict = {"n": int(len(S.y)), "features": S.features, "seed": C.SEED,
                     "positive_class": "High", "threshold": S.threshold, "environment": environment()}

    holdout, preds, proba = E.run_holdout(S); results["holdout"] = holdout; log("hold-out")
    cv, cv_state = E.run_cv(S); results["cv"] = cv; log("ten-fold cross-validation")
    results["repeated_cv"] = E.run_repeated_cv(S); log("repeated cross-validation")
    rob = E.run_robustness(S); results["robustness"] = rob; log("country-disjoint and temporal partitions")
    gcv = E.run_grouped_cv(S); results["grouped_cv"] = gcv; log("country-grouped cross-validation")
    results["rolling_origin"] = E.run_rolling_origin(S); log("rolling-origin evaluation")
    results["transitions_cv"] = E.run_transitions(S, cv_state["oof"])
    results["transitions_grouped_cv"] = E.run_transitions(S, gcv["_oof"]); log("transition analysis")
    results["selective_cv"] = E.run_selective(S, cv_state["oof"])
    results["selective_grouped_cv"] = E.run_selective(S, gcv["_oof"]); log("risk-coverage analysis")
    results["threshold_sensitivity"] = E.run_threshold_sensitivity(raw); log("threshold sensitivity")
    results["contribution"] = E.run_contribution(S, holdout, proba); log("predictor contribution")
    results["learner_sensitivity"] = E.run_learner_sensitivity(S); log("learner sensitivity")
    results["learning_curve"] = E.run_learning_curve(S); log("learning curve")
    results["error_localisation"] = E.run_error_localisation(S, preds); log("error localisation")
    results["timing"] = E.run_timing(S); log("timing")

    # Analyses added in response to peer review (Sections 4.7-4.9, Appendices G-L)
    results["revision"], rev_state = run_revision(S, results, cv_state, log)

    state = {"study": S, "preds": preds, "proba": proba, "cv_state": cv_state,
             "grouped_oof": gcv["_oof"], "raw": raw, **rev_state}
    (C.RESULTS_DIR / "data_audit.json").write_text(json.dumps(_jsonable(audit), indent=1, ensure_ascii=False),
                                                   encoding="utf-8")
    (C.RESULTS_DIR / "results.json").write_text(json.dumps(_jsonable(results), indent=1, ensure_ascii=False),
                                                encoding="utf-8")
    log("audit files written")
    return audit, results, state
