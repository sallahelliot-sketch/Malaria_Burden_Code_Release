"""Analyses added in response to peer review (manuscript Sections 4.7-4.9; Appendices G-L).

Every analysis reuses the primary design matrix, partitions, seed and leakage gate:

* run_flexible            gradient boosting and random forest under all seven regimes (reviewer C4)
* run_recalibration       Platt and isotonic recalibration of Naive Bayes, nested in training folds (C3)
* run_anchored_threshold  thresholds fixed from training years only (C2)
* run_multiplicity        every persistence-versus-learner test across regimes, Holm and Bonferroni (M6)
* run_power               minimal detectable differences and simulated power (M7)
* run_external            alignment with the High Burden to High Impact list, absolute death counts,
                          interval-robustness of transitions and routine case reports (C1a, M8)
* run_review_scenario     prospective review-targeting scenario on rolling-origin predictions (C1b)
* run_continuous          probabilistic forecasts of the log rate scored by CRPS (M9)
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import (GroupShuffleSplit, RepeatedStratifiedKFold, StratifiedGroupKFold,
                                     StratifiedKFold, train_test_split)
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import StandardScaler

from . import config as C
from .data import build_design_matrix
from .inference import corrected_resampled_t, holm, mcnemar, paired_bootstrap, paired_fold_tests
from .metrics import (brier, calibration_intercept_slope, discrimination, expected_calibration_error,
                      label_scores, logloss)
from .models import fit_predict, label, make_learners, persistence_rule

FLEX = ("GBM", "RF")


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------
def make_flexible(gbm_params: dict | None = None, rf_params: dict | None = None) -> dict:
    """Default gradient boosting (100 depth-3 trees, learning rate 0.1) and a 500-tree random forest."""
    return {"GBM": GradientBoostingClassifier(random_state=C.SEED, **(gbm_params or {})),
            "RF": RandomForestClassifier(n_estimators=C.RF_TREES, random_state=C.SEED, n_jobs=C.N_JOBS,
                                         **(rf_params or {}))}


def fit_flexible(X_tr, y_tr, X_te, learners: dict | None = None) -> dict:
    """Same routine as models.fit_predict (scaler fitted on the training rows only)."""
    proba, _ = fit_predict(X_tr, y_tr, X_te, learners or make_flexible())
    return proba


def prob_summary(y, p) -> dict:
    d = discrimination(y, label(p), p)
    ece, _ = expected_calibration_error(np.asarray(y), np.asarray(p))
    return {**{k: round(float(v), 4) for k, v in d.items()},
            "brier": round(brier(y, p), 4), "log_loss": round(logloss(y, p), 4), "ece": ece,
            **calibration_intercept_slope(y, p)}


def uncertainty_profile(y, p, transition, fractions=(0.05, 0.10)) -> dict:
    """Transition accuracy, AUC of the uncertainty -|p - .5| and capture when the least certain are deferred."""
    y, p, transition = np.asarray(y), np.asarray(p), np.asarray(transition)
    n = len(y)
    margin = np.abs(p - 0.5)
    order = np.lexsort((np.arange(n), margin))
    pred = label(p)
    out = {"stable_accuracy": round(100 * float(np.mean(pred[transition == 0] == y[transition == 0])), 4),
           "stable_errors": int((pred[transition == 0] != y[transition == 0]).sum()),
           "transitions_correct": int((pred[transition == 1] == y[transition == 1]).sum()),
           "transitions_n": int(transition.sum()),
           "auc_uncertainty": round(float(roc_auc_score(transition, -margin)), 4),
           "distinct_margins": int(len(np.unique(np.round(margin, 12))))}
    for f in fractions:
        k = int(round(f * n))
        d = np.zeros(n, dtype=bool); d[order[:k]] = True
        out[f"captured_{int(round(100 * f))}"] = int(transition[d].sum())
        out[f"retained_accuracy_{int(round(100 * f))}"] = round(100 * float(np.mean(pred[~d] == y[~d])), 4)
    return out


def relabel(clean: pd.DataFrame, tau: float) -> pd.DataFrame:
    """Re-derive label, persistence label and transition indicator at an externally fixed threshold."""
    d = clean.copy()
    d["HighBurden"] = (d["MortalityRate"] >= tau).astype(int)
    d["Burden_Label"] = np.where(d["HighBurden"] == 1, "High", "Low")
    d["Prev_HighBurden"] = (d["Prev_Rate"] >= tau).astype(int)
    d["Transition"] = (d["HighBurden"] != d["Prev_HighBurden"]).astype(int)
    return d


def iso3_map(raw_path: Path = C.RAW_PATH) -> dict:
    raw = pd.read_excel(raw_path, skiprows=C.EXPORT_PREAMBLE_ROWS)
    return dict(zip(raw["Location"], raw["SpatialDimValueCode"]))


# ---------------------------------------------------------------------------
# C4: flexible learners under the identical protocol
# ---------------------------------------------------------------------------
def run_flexible(S, results: dict) -> dict:
    out: dict = {"settings": {"GBM": "GradientBoostingClassifier: 100 trees, depth 3, learning rate 0.1",
                              "RF": f"RandomForestClassifier: {C.RF_TREES} trees, unrestricted depth, sqrt features"}}
    y = S.y
    pers_all = persistence_rule(S.prev_rate, S.threshold)

    # (1) stratified hold-out
    tr, te = S.idx_train, S.idx_test
    p = fit_flexible(S.X[tr], y[tr], S.X[te])
    pers = persistence_rule(S.prev_rate[te], S.threshold)
    lr_pred = label(fit_predict(S.X[tr], y[tr], S.X[te])[0]["LR"])
    hold = {}
    for n in FLEX:
        hold[n] = {**prob_summary(y[te], p[n]), **{k: v for k, v in label_scores(y[te], label(p[n])).items()
                                                   if k in ("specificity", "mcc", "confusion")},
                   "mcnemar_PERSIST_vs": mcnemar(pers, label(p[n]), y[te]),
                   "mcnemar_vs_LR": mcnemar(label(p[n]), lr_pred, y[te])}
    boot = paired_bootstrap(y[te], {"LR": label(p["GBM"]), "NB": label(p["RF"]), "PERSIST": pers},
                            {"LR": p["GBM"], "NB": p["RF"]})
    hold["bootstrap_PERSIST_minus_GBM"] = boot["d_acc_PERSIST_LR"]
    hold["bootstrap_PERSIST_minus_RF"] = boot["d_acc_PERSIST_NB"]
    hold["_proba"] = p
    out["holdout"] = hold

    # (2) stratified ten-fold CV (same folds as the primary analysis)
    cv = StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
    folds = {n: {"accuracy": [], "auc": [], "log_loss": [], "brier": []} for n in FLEX}
    pers_f = []
    oof = {n: np.zeros(len(y)) for n in FLEX}
    for ftr, fva in cv.split(S.X, y):
        pp = fit_flexible(S.X[ftr], y[ftr], S.X[fva])
        for n in FLEX:
            oof[n][fva] = pp[n]
            folds[n]["accuracy"].append(100 * accuracy_score(y[fva], label(pp[n])))
            folds[n]["auc"].append(roc_auc_score(y[fva], pp[n]))
            folds[n]["log_loss"].append(logloss(y[fva], pp[n]))
            folds[n]["brier"].append(brier(y[fva], pp[n]))
        pers_f.append(100 * accuracy_score(y[fva], persistence_rule(S.prev_rate[fva], S.threshold)))
    out["cv"] = {n: {m: {"mean": round(float(np.mean(v)), 4), "sd": round(float(np.std(v, ddof=1)), 4)}
                     for m, v in folds[n].items()} for n in FLEX}
    out["cv"]["persistence_folds"] = [round(x, 4) for x in pers_f]
    out["cv"]["folds"] = {n: [round(float(x), 4) for x in folds[n]["accuracy"]] for n in FLEX}
    out["cv"]["paired_PERSIST_vs"] = {n: paired_fold_tests(pers_f, folds[n]["accuracy"]) for n in FLEX}
    out["cv"]["paired_vs_LR"] = {n: paired_fold_tests(folds[n]["accuracy"], results["cv"]["folds"]["LR"]["accuracy"])
                                 for n in FLEX}
    out["cv"]["oof_summary"] = {n: prob_summary(y, oof[n]) for n in FLEX}
    out["transitions_cv"] = {n: uncertainty_profile(y, oof[n], S.transition) for n in FLEX}
    out["_oof"] = oof

    # (3) repeated 10 x 10 CV with the corrected resampled t
    rcv = RepeatedStratifiedKFold(n_splits=C.N_FOLDS, n_repeats=C.N_REPEATS, random_state=C.SEED)
    racc = {n: [] for n in FLEX}; rll = {n: [] for n in FLEX}; rpers = []
    n_tr = n_te = None
    for ftr, fva in rcv.split(S.X, y):
        n_tr, n_te = len(ftr), len(fva)
        pp = fit_flexible(S.X[ftr], y[ftr], S.X[fva])
        for n in FLEX:
            racc[n].append(100 * accuracy_score(y[fva], label(pp[n])))
            rll[n].append(logloss(y[fva], pp[n]))
        rpers.append(100 * accuracy_score(y[fva], persistence_rule(S.prev_rate[fva], S.threshold)))
    out["repeated_cv"] = {n: {"accuracy": {"mean": round(float(np.mean(racc[n])), 4),
                                           "sd": round(float(np.std(racc[n], ddof=1)), 4)},
                              "log_loss": {"mean": round(float(np.mean(rll[n])), 4),
                                           "sd": round(float(np.std(rll[n], ddof=1)), 4)},
                              "corrected_t_PERSIST_vs": corrected_resampled_t(rpers, racc[n], n_tr, n_te),
                              "corrected_t_vs_LR": corrected_resampled_t(
                                  racc[n], results["repeated_cv"]["folds"]["LR"]["accuracy"], n_tr, n_te)}
                          for n in FLEX}
    out["repeated_cv"]["persistence_check"] = round(float(np.mean(rpers)), 4)

    # (4) country-grouped ten-fold CV
    gcv = StratifiedGroupKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
    gacc = {n: [] for n in FLEX}; gpers = []
    goof = {n: np.zeros(len(y)) for n in FLEX}
    for ftr, fva in gcv.split(S.X, y, groups=S.groups):
        pp = fit_flexible(S.X[ftr], y[ftr], S.X[fva])
        for n in FLEX:
            goof[n][fva] = pp[n]
            gacc[n].append(100 * accuracy_score(y[fva], label(pp[n])))
        gpers.append(100 * accuracy_score(y[fva], persistence_rule(S.prev_rate[fva], S.threshold)))
    out["grouped_cv"] = {n: {"pooled": prob_summary(y, goof[n]),
                             "paired_PERSIST_vs": paired_fold_tests(gpers, gacc[n])} for n in FLEX}
    out["transitions_grouped_cv"] = {n: uncertainty_profile(y, goof[n], S.transition) for n in FLEX}

    # (5) country-disjoint and (6) prospective partitions
    splitter = GroupShuffleSplit(n_splits=1, test_size=C.TEST_FRACTION, random_state=C.SEED)
    g_tr, g_te = next(splitter.split(S.X, y, groups=S.groups))
    t_tr = np.where(S.years <= C.TEMPORAL_CUTOFF)[0]; t_te = np.where(S.years > C.TEMPORAL_CUTOFF)[0]
    for key, (a, b) in {"country_disjoint": (g_tr, g_te), "temporal": (t_tr, t_te)}.items():
        pp = fit_flexible(S.X[a], y[a], S.X[b])
        pr = persistence_rule(S.prev_rate[b], S.threshold)
        out[key] = {n: {**prob_summary(y[b], pp[n]), "mcnemar_PERSIST_vs": mcnemar(pr, label(pp[n]), y[b])}
                    for n in FLEX}
        out[key]["test_n"] = int(len(b))

    # (7) rolling origin
    pooled = {n: [] for n in FLEX}; idx = []; years_ge = {n: 0 for n in FLEX}; by_year = []
    for year in range(C.ROLLING_FIRST_TEST_YEAR, int(S.years.max()) + 1):
        a = np.where(S.years < year)[0]; b = np.where(S.years == year)[0]
        pp = fit_flexible(S.X[a], y[a], S.X[b])
        pr_acc = 100 * accuracy_score(y[b], persistence_rule(S.prev_rate[b], S.threshold))
        row = {"year": year}
        for n in FLEX:
            pooled[n].append(pp[n])
            acc = 100 * accuracy_score(y[b], label(pp[n]))
            row[f"accuracy_{n}"] = round(acc, 4)
            years_ge[n] += int(pr_acc >= acc)
        row["accuracy_PERSIST"] = round(pr_acc, 4)
        by_year.append(row); idx.append(b)
    idx = np.concatenate(idx)
    pr = persistence_rule(S.prev_rate[idx], S.threshold)
    out["rolling_origin"] = {n: {**prob_summary(y[idx], np.concatenate(pooled[n])),
                                 "mcnemar_PERSIST_vs": mcnemar(pr, label(np.concatenate(pooled[n])), y[idx]),
                                 "years_persistence_ge": years_ge[n]} for n in FLEX}
    out["rolling_origin"]["by_year"] = by_year
    out["rolling_origin"]["test_n"] = int(len(idx))

    # Nested tuning (inner five-fold, log loss) to show that defaults do not handicap the flexible learners
    outer = StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
    tuned = {n: {"accuracy": [], "log_loss": []} for n in FLEX}
    chosen = {n: [] for n in FLEX}
    for o_tr, o_va in outer.split(S.X, y):
        inner = StratifiedKFold(n_splits=5, shuffle=True, random_state=C.SEED)
        scores = {"GBM": {i: [] for i in range(len(C.GBM_GRID))}, "RF": {i: [] for i in range(len(C.RF_GRID))}}
        for i_tr, i_va in inner.split(S.X[o_tr], y[o_tr]):
            a, b = o_tr[i_tr], o_tr[i_va]
            for i, g in enumerate(C.GBM_GRID):
                pp = fit_flexible(S.X[a], y[a], S.X[b], {"GBM": make_flexible(gbm_params=g)["GBM"]})
                scores["GBM"][i].append(logloss(y[b], pp["GBM"]))
            for i, g in enumerate(C.RF_GRID):
                pp = fit_flexible(S.X[a], y[a], S.X[b], {"RF": make_flexible(rf_params=g)["RF"]})
                scores["RF"][i].append(logloss(y[b], pp["RF"]))
        best = {n: min(scores[n], key=lambda i: np.mean(scores[n][i])) for n in FLEX}
        chosen["GBM"].append(C.GBM_GRID[best["GBM"]]); chosen["RF"].append(C.RF_GRID[best["RF"]])
        pp = fit_flexible(S.X[o_tr], y[o_tr], S.X[o_va],
                          {"GBM": make_flexible(gbm_params=C.GBM_GRID[best["GBM"]])["GBM"],
                           "RF": make_flexible(rf_params=C.RF_GRID[best["RF"]])["RF"]})
        for n in FLEX:
            tuned[n]["accuracy"].append(100 * accuracy_score(y[o_va], label(pp[n])))
            tuned[n]["log_loss"].append(logloss(y[o_va], pp[n]))
    out["nested_tuning"] = {n: {"accuracy": round(float(np.mean(tuned[n]["accuracy"])), 4),
                                "log_loss": round(float(np.mean(tuned[n]["log_loss"])), 4),
                                "paired_PERSIST_vs": paired_fold_tests(pers_f, tuned[n]["accuracy"]),
                                "chosen": chosen[n]} for n in FLEX}
    return out


# ---------------------------------------------------------------------------
# C3: recalibrated Naive Bayes
# ---------------------------------------------------------------------------
def nb_logodds(model: GaussianNB, Z: np.ndarray) -> np.ndarray:
    """Unsaturated NB score: difference of the joint log-likelihoods (log posterior odds)."""
    jll = model.predict_joint_log_proba(Z)
    return jll[:, 1] - jll[:, 0]


def lr_logit(model: LogisticRegression, Z: np.ndarray) -> np.ndarray:
    return model.decision_function(Z)


def _score(name, X_tr, y_tr, X_te):
    sc = StandardScaler().fit(X_tr)
    m = make_learners()[name].fit(sc.transform(X_tr), y_tr)
    f = nb_logodds if name == "NB" else lr_logit
    return f(m, sc.transform(X_tr)), f(m, sc.transform(X_te)), m.predict_proba(sc.transform(X_te))[:, 1]


def recalibrated_proba(name: str, X_tr, y_tr, X_te) -> dict:
    """Fit the learner on the training rows; learn the calibration map on inner out-of-fold scores.

    The calibration map never sees the evaluated rows. Platt scaling is a two-parameter logistic map of the
    unsaturated score; isotonic regression is a monotone step map of the same score.
    """
    inner = StratifiedKFold(n_splits=5, shuffle=True, random_state=C.SEED)
    s_oof = np.zeros(len(y_tr))
    for a, b in inner.split(X_tr, y_tr):
        s_oof[b] = _score(name, X_tr[a], y_tr[a], X_tr[b])[1]
    _, s_te, raw = _score(name, X_tr, y_tr, X_te)
    s_oof_c = np.clip(s_oof, -C.SCORE_CLIP, C.SCORE_CLIP); s_te_c = np.clip(s_te, -C.SCORE_CLIP, C.SCORE_CLIP)
    platt = LogisticRegression(C=1e6, max_iter=C.LR_MAX_ITER).fit(s_oof_c.reshape(-1, 1), y_tr)
    iso = IsotonicRegression(out_of_bounds="clip", y_min=0, y_max=1).fit(s_oof_c, y_tr)
    return {"raw": raw, "platt": platt.predict_proba(s_te_c.reshape(-1, 1))[:, 1],
            "isotonic": iso.predict(s_te_c), "score": s_te}


def run_recalibration(S) -> dict:
    y = S.y
    out = {}
    for scheme, splitter, kw in (("cv", StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED), {}),
                                 ("grouped_cv", StratifiedGroupKFold(n_splits=C.N_FOLDS, shuffle=True,
                                                                     random_state=C.SEED), {"groups": S.groups})):
        oof = {f"{n}_{v}": np.zeros(len(y)) for n in ("NB", "LR") for v in ("raw", "platt", "isotonic", "score")}
        for tr, va in splitter.split(S.X, y, **kw):
            for n in ("NB", "LR"):
                r = recalibrated_proba(n, S.X[tr], y[tr], S.X[va])
                for v in ("raw", "platt", "isotonic", "score"):
                    oof[f"{n}_{v}"][va] = r[v]
        block = {}
        for key in ("NB_raw", "NB_platt", "NB_isotonic", "LR_raw", "LR_platt", "LR_isotonic"):
            block[key] = {**prob_summary(y, oof[key]), **uncertainty_profile(y, oof[key], S.transition)}
        # ranking by the unsaturated score itself (no calibration map): |log odds|
        block["NB_score_rank_auc"] = round(float(roc_auc_score(S.transition, -np.abs(oof["NB_score"]))), 4)
        out[scheme] = block
        if scheme == "cv":
            out["_oof"] = oof
    tr, te = S.idx_train, S.idx_test
    r = recalibrated_proba("NB", S.X[tr], y[tr], S.X[te])
    out["holdout_NB"] = {v: prob_summary(y[te], r[v]) for v in ("raw", "platt", "isotonic")}
    raw = r["raw"]
    out["holdout_NB"]["raw"]["pct_saturated"] = round(100 * float(np.mean((raw < 1e-12) | (raw > 1 - 1e-12))), 2)
    return out


# ---------------------------------------------------------------------------
# C2: training-anchored thresholds
# ---------------------------------------------------------------------------
def _core_eval(clean_relabelled: pd.DataFrame, tau: float, audit: dict) -> dict:
    """Hold-out, ten-fold CV, prospective split and transition analysis at a fixed tau."""
    from .experiments import Study, fit_lag_model  # local import avoids a cycle
    a = dict(audit); a["median_threshold"] = tau
    Sq = Study(clean_relabelled, a)
    y = Sq.y
    tr, te = Sq.idx_train, Sq.idx_test
    p, _ = fit_predict(Sq.X[tr], y[tr], Sq.X[te])
    pers = persistence_rule(Sq.prev_rate[te], tau)
    out = {"tau": round(float(tau), 4), "high": int(y.sum()), "low": int((1 - y).sum()),
           "transitions": int(Sq.transition.sum()),
           "low_to_high": int(((Sq.transition == 1) & (y == 1)).sum()),
           "high_to_low": int(((Sq.transition == 1) & (y == 0)).sum()),
           "holdout": {"NB": round(100 * accuracy_score(y[te], label(p["NB"])), 4),
                       "LR": round(100 * accuracy_score(y[te], label(p["LR"])), 4),
                       "PERSIST": round(100 * accuracy_score(y[te], pers), 4),
                       "mcnemar_PERSIST_vs_LR_p": mcnemar(pers, label(p["LR"]), y[te])["p"],
                       "log_loss_NB": round(logloss(y[te], p["NB"]), 4),
                       "log_loss_LR": round(logloss(y[te], p["LR"]), 4)}}
    cv = StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
    acc = {n: [] for n in ("NB", "LR", "LAG", "PERSIST")}
    oof = {n: np.zeros(len(y)) for n in ("NB", "LR", "LAG")}
    for ftr, fva in cv.split(Sq.X, y):
        pp, _ = fit_predict(Sq.X[ftr], y[ftr], Sq.X[fva])
        pp["LAG"] = fit_lag_model(Sq.prev_rate[ftr], y[ftr], Sq.prev_rate[fva])
        for n, v in pp.items():
            oof[n][fva] = v
            acc[n].append(100 * accuracy_score(y[fva], label(v)))
        acc["PERSIST"].append(100 * accuracy_score(y[fva], persistence_rule(Sq.prev_rate[fva], tau)))
    out["cv"] = {n: round(float(np.mean(v)), 4) for n, v in acc.items()}
    out["cv_paired_PERSIST_vs_LR"] = paired_fold_tests(acc["PERSIST"], acc["LR"])
    out["transitions_cv"] = {n: uncertainty_profile(y, oof[n], Sq.transition) for n in ("NB", "LR", "LAG")}
    t_tr = np.where(Sq.years <= C.TEMPORAL_CUTOFF)[0]; t_te = np.where(Sq.years > C.TEMPORAL_CUTOFF)[0]
    pp, _ = fit_predict(Sq.X[t_tr], y[t_tr], Sq.X[t_te])
    pr = persistence_rule(Sq.prev_rate[t_te], tau)
    out["prospective"] = {"NB": round(100 * accuracy_score(y[t_te], label(pp["NB"])), 4),
                          "LR": round(100 * accuracy_score(y[t_te], label(pp["LR"])), 4),
                          "PERSIST": round(100 * accuracy_score(y[t_te], pr), 4),
                          "mcnemar_PERSIST_vs_LR_p": mcnemar(pr, label(pp["LR"]), y[t_te])["p"],
                          "transitions": int(Sq.transition[t_te].sum())}
    return out


def run_anchored_threshold(S) -> dict:
    clean = S.clean
    rates = clean["MortalityRate"].to_numpy()
    out = {"primary": {"tau": S.threshold}}
    # (a) tau fixed from the pre-2019 (training) years of the prospective split
    tau_pre = float(np.median(rates[clean["Year"].to_numpy() <= C.TEMPORAL_CUTOFF]))
    out["pre2019_anchor"] = _core_eval(relabel(clean, tau_pre), tau_pre, S.audit)
    # (b) tau fixed from the first decade only (2003-2009), the training years of the first rolling origin
    tau_early = float(np.median(rates[clean["Year"].to_numpy() < C.ROLLING_FIRST_TEST_YEAR]))
    out["pre2010_anchor"] = _core_eval(relabel(clean, tau_early), tau_early, S.audit)
    # (c) fold-specific tau: each ten-fold training partition sets its own median
    cv = StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED)
    acc = {n: [] for n in ("NB", "LR", "PERSIST")}; taus = []; trans = 0
    for ftr, fva in cv.split(S.X, S.y):
        tau_k = float(np.median(rates[ftr])); taus.append(round(tau_k, 4))
        y_k = (rates >= tau_k).astype(int)
        pp, _ = fit_predict(S.X[ftr], y_k[ftr], S.X[fva])
        for n in ("NB", "LR"):
            acc[n].append(100 * accuracy_score(y_k[fva], label(pp[n])))
        acc["PERSIST"].append(100 * accuracy_score(y_k[fva], persistence_rule(S.prev_rate[fva], tau_k)))
        trans += int((y_k[fva] != (S.prev_rate[fva] >= tau_k)).sum())
    out["fold_specific_cv"] = {"taus": taus, "transitions_in_test_folds": trans,
                               **{n: round(float(np.mean(v)), 4) for n, v in acc.items()},
                               "paired_PERSIST_vs_LR": paired_fold_tests(acc["PERSIST"], acc["LR"])}
    # (d) rolling origin in which every test year is labelled at the median of the preceding years only
    pooled = {n: [] for n in ("NB", "LR", "PERSIST")}; ys = []; tr_flags = []; rows = []
    for year in range(C.ROLLING_FIRST_TEST_YEAR, int(S.years.max()) + 1):
        a = np.where(S.years < year)[0]; b = np.where(S.years == year)[0]
        tau_y = float(np.median(rates[a]))
        y_y = (rates >= tau_y).astype(int)
        pp, _ = fit_predict(S.X[a], y_y[a], S.X[b])
        pers = persistence_rule(S.prev_rate[b], tau_y)
        pooled["NB"].append(label(pp["NB"])); pooled["LR"].append(label(pp["LR"])); pooled["PERSIST"].append(pers)
        ys.append(y_y[b]); tr_flags.append(y_y[b] != pers)
        rows.append({"year": year, "tau": round(tau_y, 4), "transitions": int((y_y[b] != pers).sum()),
                     "accuracy_LR": round(100 * accuracy_score(y_y[b], label(pp["LR"])), 4),
                     "accuracy_PERSIST": round(100 * accuracy_score(y_y[b], pers), 4)})
    yy = np.concatenate(ys)
    pl = {n: np.concatenate(v) for n, v in pooled.items()}
    out["rolling_expanding_tau"] = {
        "by_year": rows, "test_n": int(len(yy)), "transitions": int(np.concatenate(tr_flags).sum()),
        **{n: round(100 * accuracy_score(yy, v), 4) for n, v in pl.items()},
        "mcnemar_PERSIST_vs_LR": mcnemar(pl["PERSIST"], pl["LR"], yy),
        "mcnemar_PERSIST_vs_NB": mcnemar(pl["PERSIST"], pl["NB"], yy),
        "years_persistence_ge_LR": int(sum(r["accuracy_PERSIST"] >= r["accuracy_LR"] for r in rows)),
        "tau_range": [round(min(r["tau"] for r in rows), 4), round(max(r["tau"] for r in rows), 4)]}
    return out


# ---------------------------------------------------------------------------
# M6: multiplicity across regimes
# ---------------------------------------------------------------------------
def run_multiplicity(results: dict, flex: dict) -> dict:
    """All persistence-versus-learner accuracy tests in one family (7 regimes x 4 learners)."""
    rows = []
    h = results["holdout"]; cv = results["cv"]; rcv = results["repeated_cv"]
    gcv = results["grouped_cv"]; rob = results["robustness"]; ro = results["rolling_origin"]["pooled"]

    def add(regime, learner, test, diff, p):
        rows.append({"regime": regime, "learner": learner, "test": test,
                     "difference_pp": None if diff is None else round(float(diff), 4), "p": float(p)})

    def mc_diff(m, n):
        return 100 * (m["n10"] - m["n01"]) / n

    n_te = h["test_n"]
    add("Hold-out 70/30", "NB", "Exact McNemar", mc_diff(h["mcnemar"]["PERSIST_vs_NB"], n_te), h["mcnemar"]["PERSIST_vs_NB"]["p"])
    add("Hold-out 70/30", "LR", "Exact McNemar", mc_diff(h["mcnemar"]["PERSIST_vs_LR"], n_te), h["mcnemar"]["PERSIST_vs_LR"]["p"])
    for n in FLEX:
        m = flex["holdout"][n]["mcnemar_PERSIST_vs"]; add("Hold-out 70/30", n, "Exact McNemar", mc_diff(m, n_te), m["p"])
    for n in ("NB", "LR"):
        t = paired_fold_tests(cv["folds"]["PERSIST"]["accuracy"], cv["folds"][n]["accuracy"])
        add("Stratified 10-fold CV", n, "Paired fold t", t["mean_difference"], t["p_t"])
    for n in FLEX:
        t = flex["cv"]["paired_PERSIST_vs"][n]; add("Stratified 10-fold CV", n, "Paired fold t", t["mean_difference"], t["p_t"])
    for n in ("NB", "LR"):
        t = rcv["corrected_t"][f"PERSIST_vs_{n}_accuracy"]
        add("Repeated 10×10 CV", n, "Corrected resampled t", t["mean_difference"], t["p"])
    for n in FLEX:
        t = flex["repeated_cv"][n]["corrected_t_PERSIST_vs"]
        add("Repeated 10×10 CV", n, "Corrected resampled t", t["mean_difference"], t["p"])
    for n in ("NB", "LR"):
        t = paired_fold_tests(gcv["folds"]["PERSIST"]["accuracy"], gcv["folds"][n]["accuracy"])
        add("Country-grouped 10-fold CV", n, "Paired fold t", t["mean_difference"], t["p_t"])
    for n in FLEX:
        t = flex["grouped_cv"][n]["paired_PERSIST_vs"]
        add("Country-grouped 10-fold CV", n, "Paired fold t", t["mean_difference"], t["p_t"])
    for key, lab in (("country_disjoint", "Country-disjoint 70/30"), ("temporal", "Prospective 2019–2024")):
        blk = rob[key]
        for n in ("NB", "LR"):
            m = blk[f"mcnemar_PERSIST_vs_{n}"]; add(lab, n, "Exact McNemar", mc_diff(m, blk["test_n"]), m["p"])
        for n in FLEX:
            m = flex[key][n]["mcnemar_PERSIST_vs"]; add(lab, n, "Exact McNemar", mc_diff(m, flex[key]["test_n"]), m["p"])
    for n in ("NB", "LR"):
        m = ro[f"mcnemar_PERSIST_vs_{n}"]; add("Rolling origin 2010–2024", n, "Exact McNemar", mc_diff(m, ro["test_n"]), m["p"])
    for n in FLEX:
        m = flex["rolling_origin"][n]["mcnemar_PERSIST_vs"]
        add("Rolling origin 2010–2024", n, "Exact McNemar", mc_diff(m, flex["rolling_origin"]["test_n"]), m["p"])
    ps = [r["p"] for r in rows]
    for r, ph in zip(rows, holm(ps)):
        r["p_holm"] = ph
        r["p_bonferroni"] = min(1.0, r["p"] * len(rows))
    learner_better = [r for r in rows if r["difference_pp"] is not None and r["difference_pp"] < 0]
    return {"rows": rows, "family_size": len(rows),
            "n_learner_numerically_better": len(learner_better),
            "n_learner_significantly_better_raw": sum(r["p"] < .05 for r in learner_better),
            "n_learner_significantly_better_holm": sum(r["p_holm"] < .05 for r in learner_better),
            "n_persistence_significantly_better_holm": sum(r["p_holm"] < .05 for r in rows
                                                           if r["difference_pp"] is not None and r["difference_pp"] > 0),
            "min_p_learner_better": min([r["p"] for r in learner_better], default=None)}


# ---------------------------------------------------------------------------
# M7: power and minimal detectable differences
# ---------------------------------------------------------------------------
def min_k_mcnemar(n01: int, alpha: float = 0.05) -> int:
    """Smallest n10 (records the model corrects) giving an exact two-sided McNemar p < alpha, given n01.

    Only n10 > n01 counts: the learner must be the more accurate rule.
    """
    k = n01 + 1
    while stats.binomtest(k, k + n01, 0.5).pvalue >= alpha:
        k += 1
    return k


def run_power(S, results: dict, flex: dict) -> dict:
    out = {}
    h = results["holdout"]
    t_hold = int(S.transition[S.idx_test].sum())
    t_all = int(S.transition.sum())
    out["holdout_transitions"] = t_hold
    out["all_transitions"] = t_all
    out["ceiling_gain_holdout_pp"] = round(100 * t_hold / h["test_n"], 4)
    out["ceiling_gain_pooled_pp"] = round(100 * t_all / len(S.y), 4)
    out["min_corrections_given_new_errors"] = [{"new_stable_errors": e, "min_transitions_corrected": min_k_mcnemar(e)}
                                               for e in (0, 1, 2, 3, 5, 10, 22, 30)]
    # observed new stable errors made by each learner on pooled out-of-fold predictions
    tr = results["transitions_cv"]
    out["observed_oof"] = {n: {"stable_errors": int(tr["stable"]["n"] - tr["stable"][f"correct_{n}"]),
                               "transitions_corrected": int(tr["transition"][f"correct_{n}"])}
                           for n in ("NB", "LR", "LAG")}
    for n in FLEX:
        u = flex["transitions_cv"][n]
        out["observed_oof"][n] = {"stable_errors": u["stable_errors"],
                                  "transitions_corrected": u["transitions_correct"]}
    for n, v in out["observed_oof"].items():
        v["required_corrections"] = min_k_mcnemar(v["stable_errors"])
        v["attainable"] = v["required_corrections"] <= t_all
    # Minimal detectable difference of the corrected resampled t (repeated CV), 80% power, two-sided .05
    rc = results["repeated_cv"]["corrected_t"]["PERSIST_vs_LR_accuracy"]
    z = stats.norm.ppf(0.975) + stats.norm.ppf(0.80)
    out["repeated_cv_mdd_pp"] = round(float(z * rc["se_corrected"]), 4)
    out["repeated_cv_se_pp"] = rc["se_corrected"]
    # Simulated power of the exact McNemar on pooled out-of-fold predictions (n = 1,973, 44 transitions):
    # a hypothetical model corrects a fraction f of transitions and errs on stable records at rate e.
    gen = np.random.default_rng(C.SEED)
    n_stable = int(len(S.y) - t_all)
    grid = []
    for e in C.POWER_STABLE_ERROR_RATES:
        for f in C.POWER_CORRECTION_FRACTIONS:
            sig = 0
            for _ in range(C.POWER_SIMULATIONS):
                n10 = gen.binomial(t_all, f); n01 = gen.binomial(n_stable, e)
                if n10 > n01 and n10 + n01 > 0 and stats.binomtest(n10, n10 + n01, 0.5).pvalue < 0.05:
                    sig += 1
            grid.append({"stable_error_rate": e, "fraction_corrected": f,
                         "net_gain_pp": round(100 * (f * t_all - e * n_stable) / len(S.y), 4),
                         "power": round(sig / C.POWER_SIMULATIONS, 4)})
    out["simulated_power"] = grid
    return out


# ---------------------------------------------------------------------------
# C1a / M8: external grounding
# ---------------------------------------------------------------------------
def load_gho_series(code: str) -> pd.DataFrame:
    """Archived GHO OData extract (data/external/<code>.json); falls back to the live API."""
    path = C.EXTERNAL_DIR / f"{code}.json"
    if path.exists():
        values = json.loads(path.read_text(encoding="utf-8"))["value"]
    else:
        values = pd.read_json(f"https://ghoapi.azureedge.net/api/{code}")["value"].tolist()
    df = pd.DataFrame(values)
    df = df[df["SpatialDimType"] == "COUNTRY"]
    return pd.DataFrame({"ISO3": df["SpatialDim"], "Year": df["TimeDim"].astype(int),
                         "value": pd.to_numeric(df["NumericValue"], errors="coerce")}).dropna()


def run_external(S) -> dict:
    iso = iso3_map()
    d = S.clean[["Country", "WHO_Region", "Year", "MortalityRate", "Rate_Low", "Rate_High", "Prev_Rate",
                 "HighBurden", "Prev_HighBurden", "Transition"]].copy()
    d["ISO3"] = d["Country"].map(iso)
    deaths = load_gho_series("MALARIA_EST_DEATHS").rename(columns={"value": "EstDeaths"})
    cases = load_gho_series("MALARIA_TOTAL_CASES").rename(columns={"value": "ReportedCases"})
    d = d.merge(deaths, on=["ISO3", "Year"], how="left").merge(cases, on=["ISO3", "Year"], how="left")
    out = {"iso3_unmatched": int(d["ISO3"].isna().sum()), "deaths_matched": int(d["EstDeaths"].notna().sum())}

    # (i) High Burden to High Impact (HBHI) countries
    hb = d[d["ISO3"].isin(C.HBHI_ISO3)]
    out["hbhi"] = {"countries_in_sample": int(hb["ISO3"].nunique()),
                   "country_years": int(len(hb)), "labelled_high": int(hb["HighBurden"].sum()),
                   "transitions": int(hb["Transition"].sum()),
                   "by_country_launch_year": [
                       {"iso3": r.ISO3, "country": r.Country, "rate": round(float(r.MortalityRate), 2),
                        "label": "High" if r.HighBurden else "Low"}
                       for r in hb[hb["Year"] == C.HBHI_LAUNCH_YEAR].sort_values("MortalityRate").itertuples()]}
    nonhb = d[~d["ISO3"].isin(C.HBHI_ISO3) & (d["Year"] == C.HBHI_LAUNCH_YEAR)]
    out["hbhi"]["non_hbhi_high_launch_year"] = int(nonhb["HighBurden"].sum())
    out["hbhi"]["non_hbhi_launch_year"] = int(len(nonhb))

    # (ii) absolute-burden stratification: countries jointly carrying 95% of estimated deaths each year
    rows = []
    d["Top95"] = 0
    for yr, g in d.dropna(subset=["EstDeaths"]).groupby("Year"):
        g = g.sort_values("EstDeaths", ascending=False)
        share = g["EstDeaths"].cumsum() / g["EstDeaths"].sum()
        top = g.index[(share.shift(fill_value=0) < C.DEATH_SHARE)]
        d.loc[top, "Top95"] = 1
    m = d.dropna(subset=["EstDeaths"])
    tab = pd.crosstab(m["HighBurden"], m["Top95"])
    po = float((m["HighBurden"] == m["Top95"]).mean())
    pe = float(m["HighBurden"].mean() * m["Top95"].mean() + (1 - m["HighBurden"].mean()) * (1 - m["Top95"].mean()))
    out["death_share"] = {"n": int(len(m)), "high_and_top": int(tab.loc[1, 1]), "high_not_top": int(tab.loc[1, 0]),
                          "low_and_top": int(tab.loc[0, 1]), "low_not_top": int(tab.loc[0, 0]),
                          "agreement_pct": round(100 * po, 2), "kappa": round((po - pe) / (1 - pe), 4),
                          "top_countries_per_year_median": float(m[m["Top95"] == 1].groupby("Year").size().median()),
                          "transitions_in_top": int(m.loc[m["Transition"] == 1, "Top95"].sum())}
    # share of estimated deaths carried by transition country-years
    tot_by_year = m.groupby("Year")["EstDeaths"].sum()
    trn = m[m["Transition"] == 1]
    out["transition_deaths"] = {"n": int(len(trn)), "deaths_total": round(float(trn["EstDeaths"].sum()), 1),
                                "deaths_median": round(float(trn["EstDeaths"].median()), 1),
                                "share_of_sample_deaths_pct": round(100 * float(trn["EstDeaths"].sum()
                                                                                / tot_by_year.loc[trn["Year"].unique()].sum()), 4),
                                "mean_abs_gap_to_tau": round(float(np.abs(trn["MortalityRate"] - S.threshold).mean()), 4)}

    # (iii) are transitions distinguishable from estimation noise? uncertainty intervals relative to tau
    tau = S.threshold
    straddle = (d["Rate_Low"] <= tau) & (d["Rate_High"] >= tau)
    t = d["Transition"] == 1
    robust = t & ~straddle  # year-t interval lies wholly on the new side of tau
    out["interval_check"] = {"transitions": int(t.sum()), "transitions_interval_contains_tau": int((t & straddle).sum()),
                             "transitions_interval_robust": int(robust.sum()),
                             "stable_interval_contains_tau": int((~t & straddle).sum()),
                             "stable_n": int((~t).sum())}
    d["Interval_Contains_Tau"] = straddle.astype(int)

    # (iv) routine surveillance: direction of reported cases (2015-2024) around class changes
    d = d.sort_values(["Country", "Year"])
    d["PrevReported"] = d.groupby("Country")["ReportedCases"].shift(1)
    d["PrevYear"] = d.groupby("Country")["Year"].shift(1)
    ok = d["ReportedCases"].notna() & d["PrevReported"].notna() & (d["Year"] - d["PrevYear"] == 1) \
        & (d["ReportedCases"] + d["PrevReported"] > 0)
    dd = d[ok].copy()
    dd["Up"] = (dd["ReportedCases"] > dd["PrevReported"]).astype(int)
    rep = {}
    for lab, mask in (("low_to_high", (dd.Transition == 1) & (dd.HighBurden == 1)),
                      ("high_to_low", (dd.Transition == 1) & (dd.HighBurden == 0)),
                      ("stable_low", (dd.Transition == 0) & (dd.HighBurden == 0)),
                      ("stable_high", (dd.Transition == 0) & (dd.HighBurden == 1))):
        rep[lab] = {"n": int(mask.sum()), "reported_cases_rose": int(dd.loc[mask, "Up"].sum())}
    # concordance: reported cases move in the direction of the modelled class change
    conc = rep["low_to_high"]["reported_cases_rose"] + (rep["high_to_low"]["n"] - rep["high_to_low"]["reported_cases_rose"])
    ntr = rep["low_to_high"]["n"] + rep["high_to_low"]["n"]
    rep["transition_concordant"] = int(conc); rep["transition_n"] = int(ntr)
    rep["binomial_p_vs_half"] = float(stats.binomtest(conc, ntr, 0.5).pvalue) if ntr else None
    # comparison with stable records: up-share among low-to-high vs stable, down-share among high-to-low vs stable
    rep["fisher_low_to_high_vs_stable_p"] = float(stats.fisher_exact(
        [[rep["low_to_high"]["reported_cases_rose"], rep["low_to_high"]["n"] - rep["low_to_high"]["reported_cases_rose"]],
         [rep["stable_low"]["reported_cases_rose"] + rep["stable_high"]["reported_cases_rose"],
          rep["stable_low"]["n"] + rep["stable_high"]["n"] - rep["stable_low"]["reported_cases_rose"]
          - rep["stable_high"]["reported_cases_rose"]]])[1]) if rep["low_to_high"]["n"] else None
    rep["years"] = [int(dd["Year"].min()), int(dd["Year"].max())] if len(dd) else None
    out["reported_cases"] = rep
    out["_frame"] = d
    return out


# ---------------------------------------------------------------------------
# C1b: a prospective review-targeting scenario
# ---------------------------------------------------------------------------
def run_review_scenario(S, external: dict) -> dict:
    """Each year a programme reviews the k least certain country-years flagged by a model trained on earlier years."""
    from .experiments import fit_lag_model
    frame = external["_frame"].set_index(["Country", "Year"])
    rows, flagged = [], []
    totals = {f"{n}_k{k}": {"captured": 0, "flags": 0} for n in ("LR", "LAG", "GBM") for k in C.REVIEW_K}
    for year in range(C.ROLLING_FIRST_TEST_YEAR, int(S.years.max()) + 1):
        a = np.where(S.years < year)[0]; b = np.where(S.years == year)[0]
        p, _ = fit_predict(S.X[a], S.y[a], S.X[b])
        probs = {"LR": p["LR"], "LAG": fit_lag_model(S.prev_rate[a], S.y[a], S.prev_rate[b]),
                 "GBM": fit_flexible(S.X[a], S.y[a], S.X[b], {"GBM": make_flexible()["GBM"]})["GBM"]}
        trans = S.transition[b]
        row = {"year": year, "n": int(len(b)), "transitions": int(trans.sum())}
        for n, pp in probs.items():
            order = np.lexsort((np.arange(len(b)), np.abs(pp - 0.5)))
            for k in C.REVIEW_K:
                sel = order[:k]
                cap = int(trans[sel].sum())
                row[f"captured_{n}_k{k}"] = cap
                totals[f"{n}_k{k}"]["captured"] += cap; totals[f"{n}_k{k}"]["flags"] += k
        lr_sel = set(np.lexsort((np.arange(len(b)), np.abs(probs["LR"] - 0.5)))[:C.REVIEW_K_PRIMARY])
        for j, i in enumerate(b):
            if S.transition[i] == 1:
                c = S.clean.iloc[i]
                ext = frame.loc[(c["Country"], int(c["Year"]))]
                flagged.append({"year": year, "country": c["Country"], "region": c["WHO_Region"],
                                "direction": "low→high" if c["HighBurden"] == 1 else "high→low",
                                "prev_rate": round(float(c["Prev_Rate"]), 2), "rate": round(float(c["MortalityRate"]), 2),
                                "p_LR": round(float(probs["LR"][j]), 3), "flagged_LR": bool(j in lr_sel),
                                "interval_contains_tau": bool(ext["Interval_Contains_Tau"]),
                                "est_deaths": None if pd.isna(ext["EstDeaths"]) else round(float(ext["EstDeaths"]), 0)})
        rows.append(row)
    tot_trans = sum(r["transitions"] for r in rows)
    n_years = len(rows)
    summary = {k: {**v, "transitions": tot_trans,
                   "random_expected": round(sum(r["transitions"] * min(1, int(k.split("_k")[1]) / r["n"])
                                                for r in rows), 2)} for k, v in totals.items()}
    missed = [f for f in flagged if not f["flagged_LR"]]
    caught = [f for f in flagged if f["flagged_LR"]]
    return {"by_year": rows, "summary": summary, "years": n_years, "transitions": tot_trans,
            "k_primary": C.REVIEW_K_PRIMARY, "transition_list": flagged,
            "missed_LR": {"n": len(missed), "low_to_high": sum(f["direction"] == "low→high" for f in missed),
                          "deaths": round(float(sum(f["est_deaths"] or 0 for f in missed)), 0),
                          "median_abs_change": round(float(np.median([abs(f["rate"] - f["prev_rate"]) for f in missed])), 3)
                          if missed else None,
                          "interval_contains_tau": sum(f["interval_contains_tau"] for f in missed)},
            "caught_LR": {"n": len(caught), "low_to_high": sum(f["direction"] == "low→high" for f in caught),
                          "deaths": round(float(sum(f["est_deaths"] or 0 for f in caught)), 0),
                          "interval_contains_tau": sum(f["interval_contains_tau"] for f in caught)}}


# ---------------------------------------------------------------------------
# M9: continuous-rate companion
# ---------------------------------------------------------------------------
def crps_gaussian(y, mu, sigma) -> np.ndarray:
    z = (y - mu) / sigma
    return sigma * (z * (2 * stats.norm.cdf(z) - 1) + 2 * stats.norm.pdf(z) - 1 / np.sqrt(np.pi))


def _log_design(S, X):
    from .experiments import log_transform
    return log_transform(S, X)


def _continuous_fit(S, tr, te) -> dict:
    """Random walk on log(1 + rate) and a Gaussian linear model on the log-transformed design matrix."""
    y_log = np.log1p(S.rate_t); prev_log = np.log1p(S.prev_rate)
    out = {}
    rw_resid = y_log[tr] - prev_log[tr]
    out["RW"] = (prev_log[te], float(np.std(rw_resid, ddof=1)))
    # random walk with a training-estimated drift
    out["RWD"] = (prev_log[te] + float(np.mean(rw_resid)), float(np.std(rw_resid, ddof=1)))
    Xl = _log_design(S, S.X)
    sc = StandardScaler().fit(Xl[tr])
    reg = LinearRegression().fit(sc.transform(Xl[tr]), y_log[tr])
    res = y_log[tr] - reg.predict(sc.transform(Xl[tr]))
    out["LIN"] = (reg.predict(sc.transform(Xl[te])), float(np.std(res, ddof=Xl.shape[1] + 1)))
    return out


def run_continuous(S, lr_oof: np.ndarray) -> dict:
    y_log = np.log1p(S.rate_t); log_tau = np.log1p(S.threshold)
    names = ("RW", "RWD", "LIN")
    res = {}
    for scheme in ("cv", "rolling"):
        mu = {n: np.full(len(S.y), np.nan) for n in names}; sd = {n: np.full(len(S.y), np.nan) for n in names}
        if scheme == "cv":
            splits = StratifiedKFold(n_splits=C.N_FOLDS, shuffle=True, random_state=C.SEED).split(S.X, S.y)
        else:
            splits = [(np.where(S.years < yr)[0], np.where(S.years == yr)[0])
                      for yr in range(C.ROLLING_FIRST_TEST_YEAR, int(S.years.max()) + 1)]
        for tr, te in splits:
            fit = _continuous_fit(S, tr, te)
            for n in names:
                mu[n][te], sd[n][te] = fit[n][0], fit[n][1]
        mask = ~np.isnan(mu["RW"])
        block = {"n": int(mask.sum())}
        for n in names:
            crps = crps_gaussian(y_log[mask], mu[n][mask], sd[n][mask])
            p_high = 1 - stats.norm.cdf((log_tau - mu[n][mask]) / sd[n][mask])
            block[n] = {"crps": round(float(np.mean(crps)), 5),
                        "mae_log": round(float(np.mean(np.abs(y_log[mask] - mu[n][mask]))), 5),
                        "mae_rate": round(float(np.mean(np.abs(np.expm1(mu[n][mask]) - S.rate_t[mask]))), 4),
                        "pi90_coverage_pct": round(100 * float(np.mean(np.abs(y_log[mask] - mu[n][mask])
                                                                       <= 1.645 * sd[n][mask])), 2),
                        "class_accuracy": round(100 * accuracy_score(S.y[mask], label(p_high)), 4),
                        "class_log_loss": round(logloss(S.y[mask], p_high), 4),
                        "auc_uncertainty": round(float(roc_auc_score(S.transition[mask], -np.abs(p_high - 0.5))), 4)}
        block["crps_skill_LIN_vs_RW_pct"] = round(100 * (1 - block["LIN"]["crps"] / block["RW"]["crps"]), 2)
        res[scheme] = block
    res["LR_cv_class_log_loss"] = round(logloss(S.y, lr_oof), 4)
    return res


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------
def run_revision(S, results: dict, cv_state: dict, log=lambda m: None) -> tuple[dict, dict]:
    rev: dict = {}
    flex = run_flexible(S, results); rev["flexible"] = flex; log("revision: flexible learners")
    rev["recalibration"] = run_recalibration(S); log("revision: Naive Bayes recalibration")
    rev["anchored_threshold"] = run_anchored_threshold(S); log("revision: training-anchored thresholds")
    rev["multiplicity"] = run_multiplicity(results, flex); log("revision: multiplicity across regimes")
    rev["power"] = run_power(S, results, flex); log("revision: power")
    ext = run_external(S); rev["external"] = ext; log("revision: external grounding")
    rev["review_scenario"] = run_review_scenario(S, ext); log("revision: review scenario")
    rev["continuous"] = run_continuous(S, cv_state["oof"]["LR"]); log("revision: continuous-rate companion")
    state = {"flex_oof": flex["_oof"], "flex_holdout_proba": flex["holdout"]["_proba"],
             "recal_oof": rev["recalibration"]["_oof"], "external_frame": ext["_frame"]}
    return rev, state
