"""Every reported table, assembled from the result objects with one formatting convention.

Conventions: percentages to two decimals; AUC, Brier score, expected calibration error,
Matthews correlation and correlation coefficients to four (three for r) decimals without
a leading zero (APA style for quantities bounded by 1); logarithmic loss with a leading zero
because it is unbounded; p values to three decimals, with values below .001 written "< .001".
Each table is returned as a dictionary {title, columns, rows, note} and is also written to
results/tables/<id>.csv.
"""
from __future__ import annotations

import csv
from decimal import ROUND_HALF_UP, Decimal

from . import config as C

NAME = {"NB": "Naïve Bayes", "LR": "Logistic regression", "LAG": "Lagged-rate logistic model",
        "PERSIST": "Persistence rule", "MAJ": "Majority class", "RND": "Stratified random"}
PRED = {"Year": "Year", "Prev_Rate": "Previous rate", "Prev_Width": "Previous interval width",
        "Trend_3yr": "Three-year trend", "Baseline_Rate": "Baseline rate", "WHO_Region": "WHO region (five indicators)",
        "MortalityRate": "Rate in year t (label source)"}


# ---------------------------------------------------------------------------
# Number formatting
# ---------------------------------------------------------------------------
def _q(x, d):
    """Round half away from zero on the decimal representation (avoids double-rounding drift)."""
    v = Decimal(repr(float(x))).quantize(Decimal(1).scaleb(-d), rounding=ROUND_HALF_UP)
    if v == 0:
        v = abs(v)
    return v


def pct(x, d=2):
    return "n/r" if x is None else f"{_q(x, d):.{d}f}"


def num(x, d=4):
    if x is None:
        return "n/r"
    return f"{_q(x, d):.{d}f}".replace("-", "\u2212")


def nolead(x, d=4):
    """APA: no leading zero for quantities that cannot exceed 1 in magnitude."""
    if x is None:
        return "n/r"
    s = f"{_q(x, d):.{d}f}"
    if s.startswith("0."):
        s = s[1:]
    elif s.startswith("-0."):
        s = "-" + s[2:]
    return s.replace("-", "\u2212")


def signed(x, d=2):
    if x is None:
        return "n/r"
    v = _q(x, d)
    s = f"{v:.{d}f}"
    if v > 0:
        s = "+" + s
    return s.replace("-", "\u2212")


def signed_nolead(x, d=4):
    s = signed(x, d)
    return s.replace("+0.", "+.").replace("\u22120.", "\u2212.")


def pval(p):
    if p is None:
        return "n/r"
    if p < 0.001:
        return "< .001"
    s = f"{p:.3f}"
    return s[1:] if s.startswith("0") else s


def peq(p):
    """'p = .021' or 'p < .001'."""
    v = pval(p)
    return f"p {v}" if v.startswith("<") else f"p = {v}"


def ci(lo, hi, d=2, lead=True):
    f = (lambda v: num(v, d)) if lead else (lambda v: nolead(v, d))
    return f"[{f(lo)}, {f(hi)}]"


def intc(x):
    return f"{x:,}"


# ---------------------------------------------------------------------------
# Main-text tables
# ---------------------------------------------------------------------------
def table_1(audit, results):
    rows = [["Source", f"Global Health Observatory export, {audit['indicator_code']}", "—",
             intc(audit["raw_rows"]), "—"]]
    for s in audit["cleaning_steps"]:
        rows.append([f"Step {len(rows)}", s["step"], intc(s["before"]), intc(s["after"]), intc(s["removed"])])
    rows.append(["Final", f"Analytical dataset: {audit['final_countries']} countries, {audit['regions']} WHO regions, "
                 f"{audit['final_year_range'][0]}–{audit['final_year_range'][1]}", "—",
                 intc(audit["final_rows"]), "—"])
    return {"title": "Dataset Construction and Record Accounting",
            "columns": ["Stage", "Action", "Before", "After", "Removed"], "rows": rows,
            "note": (f"Every record in the export has location type Country, so no aggregate rows were present. "
                     f"The removed incomplete record lacks both uncertainty bounds. The final reduction removes the "
                     f"{C.MIN_HISTORY_YEARS} earliest observations of each of the {audit['final_countries']} retained "
                     f"countries, for which the three-year trend is undefined. No value was imputed.")}


def table_2(audit, results):
    rows = []
    for c in C.NUMERIC_PREDICTORS:
        d, m = audit["descriptives"][c], audit["class_means"][c]
        qd = 0 if c == "Year" else 2
        rows.append([PRED[c], num(d["mean"], 2), num(d["sd"], 2), num(d["p50"], qd),
                     f"{num(d['p25'], qd)} to {num(d['p75'], qd)}",
                     f"{num(m['High'], 2)} ({num(m['High_sd'], 2)})", f"{num(m['Low'], 2)} ({num(m['Low_sd'], 2)})",
                     nolead(audit["point_biserial"][c], 3)])
    return {"title": "Descriptive Statistics of the Numeric Predictors, Overall and by Burden Class",
            "columns": ["Predictor", "M", "SD", "Mdn", "IQR", "High M (SD)", "Low M (SD)", "r_pb"],
            "rows": rows,
            "note": (f"N = {audit['final_rows']:,} country-years (high = {audit['class_counts']['High']}, low = "
                     f"{audit['class_counts']['Low']}). Rates and widths are deaths per 100,000 population. "
                     "IQR = interquartile range (25th to 75th percentile); r_pb = point-biserial correlation with "
                     "the high-burden class, computed on the full sample as a descriptive quantity.")}


def table_3(audit, results):
    h = results["holdout"]; cal = h["calibration"]; b = h["baselines"]
    def row(label, fits, blk, auc, prob):
        return [label, fits, pct(blk["accuracy"]), pct(blk["precision"]), pct(blk["recall"]), pct(blk["f1"]),
                pct(blk["specificity"]), nolead(blk["mcc"]), nolead(auc) if auc is not None else "n/r",
                nolead(prob["brier"]) if prob else "n/r", num(prob["log_loss"]) if prob else "n/r",
                nolead(prob["ece"]) if prob else "n/r"]
    nb = {**h["NB"], **{k: cal["NB"][k] for k in ("mcc", "specificity")}}
    lr = {**h["LR"], **{k: cal["LR"][k] for k in ("mcc", "specificity")}}
    rows = [row(NAME["NB"], "Yes", nb, h["NB"]["auc"], cal["NB"]),
            row(NAME["LR"], "Yes", lr, h["LR"]["auc"], cal["LR"]),
            row(NAME["LAG"], "Yes", b["lag_model"], b["lag_model"]["auc"], cal["LAG"]),
            row(NAME["PERSIST"], "No", b["persistence"], None, None),
            row(NAME["MAJ"], "No", b["majority"], None, None),
            row(NAME["RND"], "No", b["random"], b["random"]["auc"], None)]
    return {"title": "Hold-Out Performance of the Two Classifiers and the Reference Rules",
            "columns": ["Rule", "Fitted", "Acc (%)", "Pre (%)", "Rec (%)", "F1 (%)", "Spec (%)", "MCC", "AUC",
                        "Brier", "Log loss", "ECE"], "rows": rows,
            "note": (f"Test partition n = {h['test_n']} (296 high, 296 low); training n = {h['train_n']}. "
                     "Acc = accuracy; Pre = precision; Rec = recall; Spec = specificity; MCC = Matthews correlation "
                     "coefficient; AUC = area under the receiver operating characteristic curve; ECE = expected "
                     "calibration error (10 equal-width bins). The lagged-rate logistic model uses log(1 + previous "
                     "rate) as its only input. n/r = not reportable because the rule emits no probability.")}


def table_4(audit, results):
    h = results["holdout"]; m = h["mcnemar"]; bs = h["bootstrap"]; dl = h["delong"]
    rows = [
        ["LR vs. NB", "McNemar (exact)", str(m["LR_vs_NB"]["n01"]), str(m["LR_vs_NB"]["n10"]),
         f"OR = {m['LR_vs_NB']['odds_ratio']:.2f}", "—", pval(m["LR_vs_NB"]["p"])],
        ["LR vs. NB, accuracy", "Paired bootstrap", "—", "—", f"{signed(bs['d_acc_LR_NB']['mean'])} pp",
         ci(*bs["d_acc_LR_NB"]["ci95"]), "—"],
        ["LR vs. NB, AUC", "DeLong", "—", "—", signed_nolead(dl["LR_vs_NB"]["difference"]),
         ci(*dl["LR_vs_NB"]["ci95"], d=4, lead=False), pval(dl["LR_vs_NB"]["p"])],
        ["LR vs. NB, Brier", "Paired bootstrap", "—", "—", signed_nolead(bs["d_brier_LR_NB"]["mean"]),
         ci(*bs["d_brier_LR_NB"]["ci95"], d=4, lead=False), "—"],
        ["LR vs. NB, log loss", "Paired bootstrap", "—", "—", signed(bs["d_logloss_LR_NB"]["mean"], 4),
         ci(*bs["d_logloss_LR_NB"]["ci95"], d=4), "—"],
        ["Persistence vs. LR", "McNemar (exact)", str(m["PERSIST_vs_LR"]["n01"]), str(m["PERSIST_vs_LR"]["n10"]),
         f"OR = {m['PERSIST_vs_LR']['odds_ratio']:.2f}", "—", pval(m["PERSIST_vs_LR"]["p"])],
        ["Persistence vs. LR, accuracy", "Paired bootstrap", "—", "—",
         f"{signed(bs['d_acc_PERSIST_LR']['mean'])} pp", ci(*bs["d_acc_PERSIST_LR"]["ci95"]), "—"],
        ["Persistence vs. NB", "McNemar (exact)", str(m["PERSIST_vs_NB"]["n01"]), str(m["PERSIST_vs_NB"]["n10"]),
         f"OR = {m['PERSIST_vs_NB']['odds_ratio']:.2f}", "—", pval(m["PERSIST_vs_NB"]["p"])],
        ["Persistence vs. NB, accuracy", "Paired bootstrap", "—", "—",
         f"{signed(bs['d_acc_PERSIST_NB']['mean'])} pp", ci(*bs["d_acc_PERSIST_NB"]["ci95"]), "—"],
        ["LR vs. lagged-rate model", "McNemar (exact)", str(m["LR_vs_LAG"]["n01"]), str(m["LR_vs_LAG"]["n10"]),
         f"OR = {m['LR_vs_LAG']['odds_ratio']:.2f}", "—", pval(m["LR_vs_LAG"]["p"])],
        ["LR vs. lagged-rate model, AUC", "DeLong", "—", "—", signed_nolead(dl["LR_vs_LAG"]["difference"]),
         ci(*dl["LR_vs_LAG"]["ci95"], d=4, lead=False), pval(dl["LR_vs_LAG"]["p"])],
    ]
    return {"title": "Paired Comparisons on the Hold-Out Partition",
            "columns": ["Comparison (A vs. B)", "Procedure", "n01", "n10", "Effect (A − B)", "95% CI", "p"],
            "rows": rows,
            "note": (f"n01 = records A misclassifies and B classifies correctly; n10 = the reverse; OR = n10/n01, "
                     f"exceeding 1 when A is the more accurate. Bootstrap intervals are percentile intervals from "
                     f"{C.N_BOOTSTRAP:,} paired resamples of the {results['holdout']['test_n']} test records "
                     "(seed 1992); pp = percentage points. Negative Brier and log-loss differences favour A.")}


def table_5(audit, results):
    cv = results["cv"]; s = cv["summary"]
    def ms(n, m, d=2, lead=True):
        v = s[n][m]
        if m in ("auc", "brier"):
            return f"{nolead(v['mean'])} ± {nolead(v['sd'])}"
        if m == "log_loss":
            return f"{num(v['mean'])} ± {num(v['sd'])}"
        return f"{pct(v['mean'])} ± {pct(v['sd'])}"
    rows = []
    labels = {"accuracy": "Accuracy (%)", "precision": "Precision (%)", "recall": "Recall (%)", "f1": "F1 (%)",
              "auc": "AUC", "brier": "Brier score", "log_loss": "Log loss"}
    for m in ("accuracy", "precision", "recall", "f1", "auc", "brier", "log_loss"):
        if m in cv["paired_LR_vs_NB"]:
            t = cv["paired_LR_vs_NB"][m]; padj = pval(t["p_holm"])
        else:
            t = cv["paired_probabilistic_LR_vs_NB"][m]; padj = pval(t["p_t"]) + "ᵃ"
        bounded = m in ("auc", "brier")
        diff = signed_nolead(t["mean_difference"]) if bounded else signed(t["mean_difference"], 4 if m == "log_loss" else 2)
        cint = ci(*t["ci95"], d=4, lead=not bounded) if m in ("auc", "brier", "log_loss") else ci(*t["ci95"])
        pers = ms("PERSIST", m) if m in s["PERSIST"] else "n/r"
        rows.append([labels[m], ms("NB", m), ms("LR", m), ms("LAG", m), pers, diff, cint, num(t["t"], 2),
                     num(t["cohens_dz"], 2), padj])
    pl, pn = cv["paired_PERSIST_vs_LR"]["accuracy"], cv["paired_PERSIST_vs_NB"]["accuracy"]
    return {"title": "Stratified Ten-Fold Cross-Validated Performance and Paired Fold-Level Differences (LR − NB)",
            "columns": ["Metric", "NB M ± SD", "LR M ± SD", "Lagged M ± SD", "Persistence M ± SD",
                        "LR − NB", "95% CI", "t(9)", "d_z", "p_Holm"], "rows": rows,
            "note": ("Ten matched folds over N = 1,973 (seed 1992); scaling and learners refitted inside every training "
                     "fold. Differences, intervals, paired t and d_z refer to LR − NB. p_Holm is Holm-adjusted "
                     "within the five-metric family (accuracy, precision, recall, F1, AUC); ᵃ unadjusted p for the "
                     "two probabilistic scores, which were not part of that family. Persistence minus LR accuracy: "
                     f"{signed(pl['mean_difference'])} pp, 95% CI {ci(*pl['ci95'])}, t(9) = {num(pl['t'], 2)}, "
                     f"{peq(pl['p_t'])}; persistence minus NB: {signed(pn['mean_difference'])} pp, 95% CI "
                     f"{ci(*pn['ci95'])}, t(9) = {num(pn['t'], 2)}, {peq(pn['p_t'])}.")}


def table_6(audit, results):
    rcv, g = results["repeated_cv"], results["grouped_cv"]
    cd, tp, ro = results["robustness"]["country_disjoint"], results["robustness"]["temporal"], results["rolling_origin"]["pooled"]
    def r_split(label, blk, pers_test, mc_lr, mc_nb):
        out = []
        for n in ("NB", "LR", "LAG"):
            out.append([label if n == "NB" else "", NAME[n], pct(blk[n]["accuracy"]), pct(blk[n]["f1"]),
                        nolead(blk[n]["auc"]), nolead(blk[n]["brier"]), num(blk[n]["log_loss"]), ""])
        out.append(["", NAME["PERSIST"], pct(blk["PERSIST"]["accuracy"]), pct(blk["PERSIST"]["f1"]), "n/r", "n/r", "n/r",
                    f"vs. LR {pval(mc_lr['p'])}; vs. NB {pval(mc_nb['p'])}"])
        return out
    rows = []
    s = rcv["summary"]; ct = rcv["corrected_t"]
    for n in ("NB", "LR", "LAG"):
        rows.append(["Repeated 10×10 CV (100 resamples)" if n == "NB" else "", NAME[n],
                     f"{pct(s[n]['accuracy']['mean'])} ± {pct(s[n]['accuracy']['sd'])}",
                     f"{pct(s[n]['f1']['mean'])} ± {pct(s[n]['f1']['sd'])}", nolead(s[n]["auc"]["mean"]),
                     nolead(s[n]["brier"]["mean"]), num(s[n]["log_loss"]["mean"]), ""])
    rows.append(["", NAME["PERSIST"], f"{pct(s['PERSIST']['accuracy']['mean'])} ± {pct(s['PERSIST']['accuracy']['sd'])}",
                 f"{pct(s['PERSIST']['f1']['mean'])} ± {pct(s['PERSIST']['f1']['sd'])}", "n/r", "n/r", "n/r",
                 f"vs. LR {pval(ct['PERSIST_vs_LR_accuracy']['p'])}; vs. NB {pval(ct['PERSIST_vs_NB_accuracy']['p'])}"])
    gs = g["summary"]; gp = g["pooled"]
    for n in ("NB", "LR", "LAG"):
        rows.append(["Country-grouped 10-fold CV (pooled)" if n == "NB" else "", NAME[n],
                     f"{pct(gp[n]['accuracy'])}", pct(gp[n]["f1"]), nolead(gp[n]["auc"]), nolead(gp[n]["brier"]),
                     num(gp[n]["log_loss"]), ""])
    rows.append(["", NAME["PERSIST"], pct(gp["PERSIST"]["accuracy"]), pct(gp["PERSIST"]["f1"]), "n/r", "n/r", "n/r",
                 f"vs. LR {pval(g['paired_PERSIST_vs_LR']['accuracy']['p_t'])}"])
    rows += r_split(f"Country-disjoint 70/30 ({cd['train_countries']}/{cd['test_countries']} countries; n = {cd['test_n']})",
                    cd, None, cd["mcnemar_PERSIST_vs_LR"], cd["mcnemar_PERSIST_vs_NB"])
    rows += r_split(f"Prospective: train 2003–2018, test 2019–2024 (n = {tp['test_n']})", tp, None,
                    tp["mcnemar_PERSIST_vs_LR"], tp["mcnemar_PERSIST_vs_NB"])
    rows += r_split(f"Rolling origin 2010–2024, pooled (n = {ro['test_n']:,})", ro, None,
                    ro["mcnemar_PERSIST_vs_LR"], ro["mcnemar_PERSIST_vs_NB"])
    return {"title": "Performance Under Repeated, Country-Grouped and Temporal Evaluation Regimes",
            "columns": ["Regime", "Rule", "Acc (%)", "F1 (%)", "AUC", "Brier", "Log loss", "Persistence test (p)"],
            "rows": rows,
            "note": ("Repeated CV values are M ± SD over 100 resamples, and its persistence tests use the "
                     "Nadeau–Bengio corrected resampled t. Country-grouped values pool out-of-fold predictions "
                     "over all 1,973 records; its test is the paired fold-level t (persistence vs. LR accuracy). "
                     "Single-split regimes use exact McNemar tests. Rolling origin trains on all years before each "
                     "test year from 2010 to 2024 and pools the 15 test years.")}


def table_7(audit, results):
    tr, tg = results["transitions_cv"], results["transitions_grouped_cv"]
    sel = {(r["model"], r["coverage"]): r for r in results["selective_cv"]["rows"]}
    rows = []
    for n in ("NB", "LR", "LAG", "PERSIST"):
        r5 = sel.get((n, 0.95)); r10 = sel.get((n, 0.90))
        rows.append([NAME[n], pct(tr["stable"][f"accuracy_{n}"]),
                     f"{tr['transition'][f'correct_{n}']}/{tr['transition']['n']} ({pct(tr['transition'][f'accuracy_{n}'], 1)})",
                     f"{tg['transition'][f'correct_{n}']}/{tg['transition']['n']}",
                     nolead(tr.get(f"auc_uncertainty_flags_transition_{n}"), 3) if n != "PERSIST" else "n/r",
                     f"{r5['transitions_deferred']}/{r5['transitions_total']}" if r5 else "n/r",
                     pct(r5["accuracy_model_retained"]) if r5 else "n/r",
                     f"{r10['transitions_deferred']}/{r10['transitions_total']}" if r10 else "n/r"])
    return {"title": "Behaviour on Class Transitions and Uncertainty-Guided Review (Out-of-Fold Predictions)",
            "columns": ["Rule", "Stable acc (%)", "Transitions correct (%)", "Transitions correct, grouped CV",
                        "AUC of uncertainty for transitions", "Captured at 5% deferral", "Retained acc at 5% (%)",
                        "Captured at 10% deferral"],
            "rows": rows,
            "note": (f"A transition is a country-year whose class differs from the class of the preceding observation "
                     f"(n = {tr['transition']['n']}; {tr['low_to_high']['n']} low-to-high, {tr['high_to_low']['n']} "
                     f"high-to-low); stable n = {tr['stable']['n']:,}. Predictions are out-of-fold from the stratified "
                     "ten-fold cross-validation unless marked grouped. Uncertainty is −|p − 0.5|; its AUC is "
                     "the probability that a transition receives a less certain prediction than a stable record. "
                     "Deferral removes the least certain 5% (99) or 10% (197) of country-years for review. "
                     "Naïve Bayes assigns many records an identical saturated probability, so its deferral order within "
                     "ties is arbitrary.")}


def table_8(audit, results):
    c = results["contribution"]; h = results["holdout"]
    loo, perm, cb = c["leave_one_out"], c["permutation_importance"], c["lr_coefficient_bootstrap"]
    rows = []
    order = ["Prev_Rate", "Prev_Width", "Trend_3yr", "Baseline_Rate", "Year", "WHO_Region"]
    for g in order:
        if g == "WHO_Region":
            ests = [cb[f]["estimate"] for f in cb if f.startswith("Region_")]
            coef = f"{num(min(ests), 2)} to {num(max(ests), 2)}"; cint = "see Appendix C"
        else:
            coef = num(cb[g]["estimate"], 2); cint = ci(*cb[g]["ci95"])
        row = [PRED[g], coef, cint]
        for n in ("LR", "NB"):
            row += [signed(loo[g][n]["accuracy"] - h[n]["accuracy"]),
                    signed(loo[g][n]["log_loss"] - h["calibration"][n]["log_loss"], 3),
                    num(perm[g][n]["auc"]["mean"], 4)]
        rows.append(row)
    return {"title": "Predictor Contribution: Standardised Coefficients, Leave-One-Out Refitting and Permutation Importance",
            "columns": ["Predictor", "LR β (std.)", "95% bootstrap CI", "LR ΔAcc (pp)", "LR ΔLog loss",
                        "LR perm. ΔAUC", "NB ΔAcc (pp)", "NB ΔLog loss", "NB perm. ΔAUC"],
            "rows": rows,
            "note": (f"β = standardised logistic coefficient on the hold-out training partition, with percentile "
                     f"intervals from {c['lr_coefficient_bootstrap_replicates']:,} bootstrap refits. ΔAcc and "
                     "ΔLog loss = change in hold-out accuracy and log loss when the predictor is withheld and the "
                     "model refitted (negative ΔAcc and positive ΔLog loss indicate a useful predictor). "
                     f"Perm. ΔAUC = mean decrease in hold-out AUC over {C.N_PERMUTATION} permutations; the five "
                     "region indicators are permuted jointly.")}


# ---------------------------------------------------------------------------
# Appendix tables
# ---------------------------------------------------------------------------
def table_A1(audit, results):
    d = audit["descriptives"]
    rng = lambda c: f"{num(d[c]['min'], 2)} to {num(d[c]['max'], 2)}"
    rows = [
        ["Country", "Identifier", "Country name; grouping variable for country-disjoint splits", f"{audit['final_countries']} countries"],
        ["WHO_Region", "Predictor", "WHO region g(c), one-hot encoded into five indicators", f"{audit['regions']} regions"],
        ["Year", "Predictor", "Reporting year t", f"{audit['final_year_range'][0]}–{audit['final_year_range'][1]}"],
        ["Prev_Rate", "Predictor", "Rate at the preceding observation, r(c, t−1)", rng("Prev_Rate")],
        ["Prev_Width", "Predictor", "Interval width at the preceding observation, w(c, t−1)", rng("Prev_Width")],
        ["Trend_3yr", "Predictor", "r(c, t−1) − r(c, t−3): change across the three most recent observations", rng("Trend_3yr")],
        ["Baseline_Rate", "Predictor", "Rate at the country's first observation in the export", rng("Baseline_Rate")],
        ["MortalityRate", "Excluded", "Rate in year t; constructs the label only", rng("MortalityRate")],
        ["Rate_Low, Rate_High", "Excluded", "Lower and upper uncertainty bounds in year t", "≥ 0"],
        ["Interval_Width", "Excluded", "Rate_High − Rate_Low in year t", "≥ 0"],
        ["HighBurden", "Target", f"1 if MortalityRate ≥ τ = {audit['median_threshold']:.2f}, else 0",
         f"High {audit['class_counts']['High']}, Low {audit['class_counts']['Low']}"],
        ["Transition", "Reporting only", "1 if the class at t differs from the class at the preceding observation",
         f"{audit['transitions']['n']} transitions"],
    ]
    return {"title": f"Variable Dictionary for the Analytical Dataset (N = {audit['final_rows']:,})",
            "columns": ["Field", "Role", "Definition", "Range or values"], "rows": rows,
            "note": (f"Rates and widths are deaths per 100,000 population. For {audit['lag_gap']['records_previous_observation_is_t_minus_1']:,} "
                     f"records the preceding observation is year t−1; for {audit['lag_gap']['records_previous_observation_is_earlier']} "
                     "records (China 2022 and 2024; French Guiana 2024) the export omits the intervening year and the "
                     "preceding observation is t−2; all three have a rate of zero at both observations. Excluded "
                     "fields form the exclusion set of Equation (6) and are rejected by an assertion if they reach the "
                     "design matrix.")}


def table_A2(audit, results):
    env = results["environment"]
    rows = [["Data", f"{audit['indicator_code']} export; {audit['raw_rows']:,} records, {audit['raw_fields']} fields, "
             f"{audit['countries_raw']} countries, {audit['year_range_raw'][0]}–{audit['year_range_raw'][1]}; "
             f"WHO last-modified date {audit['date_modified']}"],
            ["Analytical sample", f"{audit['final_rows']:,} country-years; {audit['final_countries']} countries; "
             f"{audit['regions']} regions; {audit['final_year_range'][0]}–{audit['final_year_range'][1]}; no imputation"],
            ["Label", f"τ = sample median = {audit['median_threshold']:.2f}; high {audit['class_counts']['High']}, "
             f"low {audit['class_counts']['Low']}"],
            ["Hold-out", f"stratified 70/30; {results['holdout']['train_n']:,} training, {results['holdout']['test_n']} test"],
            ["Cross-validation", "stratified 10-fold (shuffle); repeated 10×10; country-grouped stratified 10-fold"],
            ["Other partitions", "country-disjoint 70/30 (GroupShuffleSplit); prospective ≤2018 | ≥2019; "
             "rolling origin 2010–2024"],
            ["Learners", f"GaussianNB (var_smoothing = 1e−9, priors by relative frequency); LogisticRegression "
             f"(L2, C = 1.0, lbfgs, max_iter = {C.LR_MAX_ITER}); decision threshold 0.50; no tuning in primary analyses"],
            ["Reference rules", "persistence 1(r(c,t−1) ≥ τ); lagged-rate logistic model on log(1 + r(c,t−1)); "
             "majority class; stratified random"],
            ["Inference", f"exact McNemar; DeLong; paired bootstrap ({C.N_BOOTSTRAP:,}); paired fold t, Wilcoxon, Holm; "
             "Nadeau–Bengio corrected t for repeated CV"],
            ["Seed", f"{C.SEED} for every stochastic step"],
            ["Software", f"Python {env['python']}; NumPy {env['numpy']}; pandas {env['pandas']}; SciPy {env['scipy']}; "
             f"scikit-learn {env['scikit-learn']}; Matplotlib {env['matplotlib']}; openpyxl {env['openpyxl']}"],
            ["Hardware", "single CPU core, x86-64 Linux; complete pipeline ≈ 3 to 4 minutes"],
            ["Audit", "automated consistency checks run at the end of every execution; all passed"]]
    return {"title": "Reproducibility Manifest", "columns": ["Item", "Setting"], "rows": rows,
            "note": "Every value in the manuscript is written by the released pipeline to results/data_audit.json and results/results.json."}


def table_B1(audit, results):
    rows = []
    for r in audit["region_table"]:
        rows.append([r["region"], intc(r["records"]), pct(100 * r["records"] / audit["final_rows"], 1), str(r["countries"]),
                     intc(r["high_burden"]), pct(r["high_prevalence_pct"], 1), str(r["transitions"])])
    rows.append(["Total", intc(audit["final_rows"]), "100.0", str(audit["final_countries"]),
                 intc(audit["class_counts"]["High"]), pct(audit["class_pct"]["High"], 1), str(audit["transitions"]["n"])])
    return {"title": "Regional Composition of the Analytical Sample",
            "columns": ["WHO region", "Records", "% of sample", "Countries", "High-burden records",
                        "High-burden prevalence (%)", "Transitions"], "rows": rows,
            "note": f"Transitions are country-years whose class differs from the preceding observation. "
                    f"{audit['transitions']['countries_with_any']} countries contribute at least one transition."}


def table_C1(audit, results):
    f = results["cv"]["folds"]
    rows = []
    for k in range(C.N_FOLDS):
        rows.append([str(k + 1)] + [pct(f[n]["accuracy"][k]) for n in ("NB", "LR", "LAG", "PERSIST")]
                    + [nolead(f[n]["auc"][k]) for n in ("NB", "LR")] + [num(f[n]["log_loss"][k]) for n in ("NB", "LR")])
    return {"title": "Fold-Level Results of the Stratified Ten-Fold Cross-Validation",
            "columns": ["Fold", "NB Acc", "LR Acc", "Lagged Acc", "Persist. Acc", "NB AUC", "LR AUC", "NB Log loss",
                        "LR Log loss"], "rows": rows,
            "note": "Accuracy in per cent. Each fold holds 197 or 198 records; seed 1992."}


def table_C2(audit, results):
    cal = results["holdout"]["calibration"]
    rows = []
    for i in range(C.N_CALIBRATION_BINS):
        row = [cal["NB"]["bins"][i]["bin"]]
        for n in ("NB", "LR", "LAG"):
            b = cal[n]["bins"][i]
            row += [str(b["n"]), nolead(b["confidence"], 3) if b["n"] else "—",
                    nolead(b["observed"], 3) if b["n"] else "—"]
        rows.append(row)
    rows.append(["Slope / intercept"] + sum([["", num(cal[n]["slope"], 2), num(cal[n]["intercept_large"], 2)]
                                             for n in ("NB", "LR", "LAG")], []))
    return {"title": "Calibration Bins and Logistic Recalibration Parameters on the Hold-Out Partition",
            "columns": ["Bin", "NB n", "NB conf.", "NB obs.", "LR n", "LR conf.", "LR obs.", "Lag n", "Lag conf.", "Lag obs."],
            "rows": rows,
            "note": ("conf. = mean predicted probability; obs. = observed high-burden frequency. The final row gives the "
                     "calibration slope and calibration-in-the-large intercept from logistic recalibration of the "
                     "logit of the predicted probability (ideal values 1 and 0); probabilities were clipped to "
                     "[10⁻⁶, 1 − 10⁻⁶] before taking logits.")}


def table_C3(audit, results):
    lr = results["holdout"]["lr_coefficients"]; cb = results["contribution"]["lr_coefficient_bootstrap"]
    rows = [[PRED.get(k, k.replace("Region_", "Region: ")), num(cb[k]["estimate"], 4), ci(*cb[k]["ci95"], d=4),
             num(cb[k]["odds_ratio_per_sd"], 3)] for k in lr]
    rows.append(["Intercept", num(results["holdout"]["lr_intercept"], 4), "—", "—"])
    return {"title": "Standardised Logistic Regression Coefficients With Bootstrap Intervals",
            "columns": ["Term", "β", "95% bootstrap CI", "Odds ratio per SD"], "rows": rows,
            "note": f"Fitted on the {results['holdout']['train_n']:,}-record training partition after standardisation; "
                    f"{results['contribution']['lr_coefficient_bootstrap_replicates']:,} bootstrap refits."}


def table_D1(audit, results):
    rows = []
    for r in results["rolling_origin"]["by_year"]:
        rows.append([str(r["year"]), intc(r["train_n"]), str(r["test_n"]), str(r["transitions"]),
                     pct(r["accuracy_NB"]), pct(r["accuracy_LR"]), pct(r["accuracy_LAG"]), pct(r["accuracy_PERSIST"]),
                     num(r["log_loss_NB"], 3), num(r["log_loss_LR"], 3), num(r["log_loss_LAG"], 3)])
    return {"title": "Rolling-Origin Evaluation by Test Year",
            "columns": ["Test year", "Train n", "Test n", "Transitions", "NB Acc", "LR Acc", "Lagged Acc",
                        "Persist. Acc", "NB LL", "LR LL", "Lagged LL"], "rows": rows,
            "note": "Each model is trained on every country-year before the test year and scored on that year. Acc in per cent; LL = log loss."}


def table_E1(audit, results):
    rows = []
    for r in results["threshold_sensitivity"]:
        rows.append([f"{int(100 * r['quantile'])}th", num(r["threshold"], 3), pct(r["high_pct"]), pct(r["transition_pct"]),
                     pct(r["cv_accuracy_NB"]), pct(r["cv_accuracy_LR"]), pct(r["cv_accuracy_PERSIST"]),
                     pct(r["accuracy_LR"]), pct(r["persistence_accuracy"]), pval(r["mcnemar_PERSIST_vs_LR_p"]),
                     num(r["log_loss_NB"], 3), num(r["log_loss_LR"], 3)])
    return {"title": "Sensitivity of the Comparison to the Classification Threshold",
            "columns": ["Percentile", "τ", "High (%)", "Transitions (%)", "CV NB Acc", "CV LR Acc", "CV Persist. Acc",
                        "Hold-out LR Acc", "Hold-out Persist. Acc", "McNemar p (Persist. vs. LR)", "NB LL", "LR LL"],
            "rows": rows,
            "note": ("The full pipeline (label, stratified hold-out, ten-fold CV) is re-run at each threshold, defined as "
                     "the stated percentile of the year-t rate. Accuracies in per cent; LL = hold-out log loss. "
                     "The 50th-percentile row reproduces the primary analysis.")}


def table_E2(audit, results):
    c = results["contribution"]; h = results["holdout"]; ls = results["learner_sensitivity"]
    rows = [["Full model (primary)", "10 inputs"] + [x for n in ("NB", "LR") for x in
            (pct(h[n]["accuracy"]), nolead(h[n]["auc"]), num(h["calibration"][n]["log_loss"]))]]
    lab = {"context_only": "Context only (region, year, previous width)", "history_only": "History only (previous rate, trend, baseline)",
           "prev_rate_only": "Previous rate only (raw scale)", "prev_rate_and_width": "Previous rate and previous width"}
    for k, v in c["ablation"].items():
        rows.append([lab[k], f"{len(v['features'])} input" + ("s" if len(v["features"]) > 1 else "")] + [x for n in ("NB", "LR") for x in
                    (pct(v[n]["accuracy"]), nolead(v[n]["auc"]), num(v[n]["log_loss"]))])
    li = ls["log_inputs_holdout"]
    rows.append(["Log-transformed rate, width, baseline and trend", "10 inputs"] + [x for n in ("NB", "LR") for x in
                (pct(li[n]["accuracy"]), nolead(li[n]["auc"]), num(li[n]["log_loss"]))])
    nt = ls["nested_tuning"]["summary"]
    rows.append(["Nested tuning, 10-fold CV: default", "10 inputs"] + [x for n in ("NB", "LR") for x in
                (pct(nt[f"{n}_default"]["accuracy"]["mean"]), nolead(nt[f"{n}_default"]["auc"]["mean"]),
                 num(nt[f"{n}_default"]["log_loss"]["mean"]))])
    rows.append(["Nested tuning, 10-fold CV: tuned", "10 inputs"] + [x for n in ("NB", "LR") for x in
                (pct(nt[f"{n}_tuned"]["accuracy"]["mean"]), nolead(nt[f"{n}_tuned"]["auc"]["mean"]),
                 num(nt[f"{n}_tuned"]["log_loss"]["mean"]))])
    ch = ls["nested_tuning"]
    return {"title": "Ablation, Input-Transformation and Tuning Sensitivity",
            "columns": ["Specification", "Inputs", "NB Acc (%)", "NB AUC", "NB Log loss", "LR Acc (%)", "LR AUC", "LR Log loss"],
            "rows": rows,
            "note": ("Hold-out partition unless marked CV. Log transformation applies log(1 + x) to the rate, width and "
                     "baseline and sign(x)log(1 + |x|) to the trend. Nested tuning selects, in an inner five-fold loop "
                     f"by log loss, C ∈ {{{', '.join(str(x) for x in ch['grid_C'])}}} for LR (selected: "
                     f"{', '.join(str(x) for x in ch['chosen_C'])}) and var_smoothing ∈ {{1e−12, 1e−9, 1e−6, "
                     "1e−3, 0.1}} for NB; values are outer-fold means.")}


def table_E3(audit, results):
    rows = []
    for r in results["learning_curve"]:
        rows.append([f"{int(round(100 * r['fraction']))}%", intc(r["train_n"]), str(r["repeats"]),
                     f"{pct(r['accuracy_NB'])} ± {pct(r['accuracy_sd_NB'])}",
                     f"{pct(r['accuracy_LR'])} ± {pct(r['accuracy_sd_LR'])}",
                     f"{num(r['log_loss_NB'], 3)} ± {num(r['log_loss_sd_NB'], 3)}",
                     f"{num(r['log_loss_LR'], 3)} ± {num(r['log_loss_sd_LR'], 3)}"])
    return {"title": "Learning Curves on the Fixed Hold-Out Partition",
            "columns": ["Training fraction", "Training n", "Repeats", "NB Acc (%)", "LR Acc (%)", "NB Log loss", "LR Log loss"],
            "rows": rows,
            "note": "Stratified subsamples of the 1,381-record training partition; every model is scored on the same 592 test records. M ± SD over repeats."}


def table_F1(audit, results):
    el = results["error_localisation"]
    rows = []
    for b in el["distance_bands"]:
        rows.append([b["band"], str(b["n"])] + [f"{pct(b[f'accuracy_{n}'])} ({b[f'errors_{n}']})" for n in ("NB", "LR", "PERSIST")])
    for r in el["region"]:
        rows.append([r["region"], f"{r['n']} ({r['high_burden']} high)"] +
                    [f"{pct(r[f'accuracy_{n}'])} ({r[f'errors_{n}']})" for n in ("NB", "LR", "PERSIST")])
    nt = el["near_threshold"]
    return {"title": "Localisation of Hold-Out Error by Distance From the Threshold and by WHO Region",
            "columns": ["Stratum", "n", "NB Acc (errors)", "LR Acc (errors)", "Persist. Acc (errors)"], "rows": rows,
            "note": (f"Distance bands use |r(c,t) − τ| in deaths per 100,000 and serve only to stratify reporting. "
                     f"The {nt['n']} records within 2.0 of τ ({pct(nt['share_of_test_pct'])}% of the test set) "
                     f"carry {pct(nt['share_of_LR_errors_pct'])}% of LR errors, {pct(nt['share_of_NB_errors_pct'])}% of NB "
                     f"errors and {pct(nt['share_of_PERSIST_errors_pct'])}% of persistence errors.")}


def table_F2(audit, results):
    rows = []
    for r in results["selective_cv"]["rows"]:
        rows.append([NAME[r["model"]], f"{100 * r['coverage']:.1f}", str(r["deferred_n"]),
                     pct(r["accuracy_model_retained"]), pct(r["accuracy_persistence_retained"]),
                     f"{r['transitions_deferred']}/{r['transitions_total']}", f"{r['model_errors_deferred']}/{r['model_errors_total']}"])
    return {"title": "Risk–Coverage Analysis on Out-of-Fold Predictions",
            "columns": ["Model", "Coverage (%)", "Deferred n", "Model acc retained (%)", "Persist. acc retained (%)",
                        "Transitions deferred", "Model errors deferred"], "rows": rows,
            "note": "Records are deferred in increasing order of |p − 0.5|. Persistence accuracy is computed on the same retained records."}


def table_F3(audit, results):
    t = results["timing"]
    rows = [[NAME[n], str(t[n]["parameters"]), num(t[n]["fit_ms_median"], 3), num(t[n]["predict_ms_median"], 3)]
            for n in ("NB", "LR", "PERSIST")]
    return {"title": "Computational Cost on the Hold-Out Partition",
            "columns": ["Rule", "Fitted parameters", "Fit time (ms)", "Prediction time, 592 records (ms)"], "rows": rows,
            "note": (f"Medians of {C.N_TIMING_REPEATS} repetitions on one CPU core. Naïve Bayes stores a mean and variance "
                     "per input and class plus two priors; logistic regression stores ten coefficients and an intercept. "
                     "Timings are indicative and vary with hardware.")}


# ---------------------------------------------------------------------------
# Tables added at revision (Tables 9-10; Appendices G-L)
# ---------------------------------------------------------------------------
NAME.update({"GBM": "Gradient boosting", "RF": "Random forest", "NB_platt": "Naïve Bayes, Platt-recalibrated",
             "NB_isotonic": "Naïve Bayes, isotonic-recalibrated", "LR_platt": "Logistic regression, Platt-recalibrated",
             "LR_isotonic": "Logistic regression, isotonic-recalibrated", "NB_raw": "Naïve Bayes",
             "LR_raw": "Logistic regression"})


def table_9(audit, results):
    rv = results["revision"]; fx = rv["flexible"]; rc = rv["recalibration"]["cv"]
    cv = results["cv"]["summary"]; g = results["grouped_cv"]["pooled"]; tp = results["robustness"]["temporal"]
    ro = results["rolling_origin"]["pooled"]; tr = results["transitions_cv"]
    sel = {(r["model"], r["coverage"]): r for r in results["selective_cv"]["rows"]}
    rows = []
    for n in ("NB", "LR", "LAG"):
        rows.append([NAME[n], pct(cv[n]["accuracy"]["mean"]), pct(g[n]["accuracy"]), pct(tp[n]["accuracy"]),
                     pct(ro[n]["accuracy"]), num(cv[n]["log_loss"]["mean"]),
                     f"{tr['transition'][f'correct_{n}']}/44", nolead(tr[f"auc_uncertainty_flags_transition_{n}"], 3),
                     f"{sel[(n, 0.95)]['transitions_deferred']}/44", f"{sel[(n, 0.90)]['transitions_deferred']}/44"])
    for n in ("NB_platt", "NB_isotonic"):
        b = rc[n]; gb = rv["recalibration"]["grouped_cv"][n]
        rows.append([NAME[n], pct(b["accuracy"]), pct(gb["accuracy"]), "—", "—", num(b["log_loss"]),
                     f"{b['transitions_correct']}/44", nolead(b["auc_uncertainty"], 3),
                     f"{b['captured_5']}/44", f"{b['captured_10']}/44"])
    for n in ("GBM", "RF"):
        u = fx["transitions_cv"][n]
        rows.append([NAME[n], pct(fx["cv"][n]["accuracy"]["mean"]), pct(fx["grouped_cv"][n]["pooled"]["accuracy"]),
                     pct(fx["temporal"][n]["accuracy"]), pct(fx["rolling_origin"][n]["accuracy"]),
                     num(fx["cv"][n]["log_loss"]["mean"]), f"{u['transitions_correct']}/44",
                     nolead(u["auc_uncertainty"], 3), f"{u['captured_5']}/44", f"{u['captured_10']}/44"])
    rows.append([NAME["PERSIST"], pct(cv["PERSIST"]["accuracy"]["mean"]), pct(g["PERSIST"]["accuracy"]),
                 pct(tp["PERSIST"]["accuracy"]), pct(ro["PERSIST"]["accuracy"]), "n/r", "0/44", "n/r", "n/r", "n/r"])
    return {"title": "Flexible Learners and Recalibrated Naïve Bayes Against the Persistence Rule",
            "columns": ["Rule", "10-fold CV Acc (%)", "Grouped CV Acc (%)", "Prospective Acc (%)", "Rolling-origin Acc (%)",
                        "CV Log loss", "Transitions correct", "AUC of uncertainty", "Captured at 5%", "Captured at 10%"],
            "rows": rows,
            "note": ("Gradient boosting: 100 depth-3 trees, learning rate 0.1; random forest: 500 trees; both default "
                     "settings fitted on the identical lagged design matrix and partitions. Recalibration maps (Platt: "
                     "logistic on the Naïve Bayes log posterior odds; isotonic: monotone step map) were learned on inner "
                     "five-fold out-of-fold scores within each training partition. CV accuracy and log loss are fold "
                     "means (pooled out-of-fold for recalibrated rows); transition columns use pooled out-of-fold "
                     "predictions from the stratified ten-fold CV. Prospective = train 2003–2018, test 2019–2024. "
                     "— = not computed (recalibration was evaluated by cross-validation only). Per-regime detail and "
                     "tests in Appendices G and H.")}


def table_10(audit, results):
    sc = results["revision"]["review_scenario"]; s = sc["summary"]
    rows = []
    for n, lab in (("LAG", NAME["LAG"]), ("GBM", NAME["GBM"]), ("LR", NAME["LR"])):
        rows.append([lab] + [f"{s[f'{n}_k{k}']['captured']}/{sc['transitions']}" for k in C.REVIEW_K])
    rows.append(["Random review (expected)"] + [num(s[f"LR_k{k}"]["random_expected"], 1) for k in C.REVIEW_K])
    rows.append(["Country-years reviewed over 15 years"] + [str(s[f"LR_k{k}"]["flags"]) for k in C.REVIEW_K])
    return {"title": "Prospective Review-Targeting Scenario on Rolling-Origin Predictions, 2010–2024",
            "columns": ["Rule used to rank country-years", *[f"k = {k} per year" for k in C.REVIEW_K]],
            "rows": rows,
            "note": (f"Each year from 2010 to 2024 every rule is trained only on earlier years and the k least certain "
                     f"country-years (smallest |p − 0.5|) are sent for review; cells give the class transitions captured "
                     f"out of the {sc['transitions']} that occurred in those years. k = 5 is about 5.5% of the ~90 "
                     "country-years classified each year. Transition-level detail in Table K2.")}


def table_G1(audit, results):
    fx = results["revision"]["flexible"]; rows = []
    blocks = [("Hold-out 70/30 (n = 592)", fx["holdout"], "mcnemar_PERSIST_vs", "McNemar"),
              ("Country-disjoint 70/30", fx["country_disjoint"], "mcnemar_PERSIST_vs", "McNemar"),
              ("Prospective 2019–2024", fx["temporal"], "mcnemar_PERSIST_vs", "McNemar"),
              ("Rolling origin 2010–2024", fx["rolling_origin"], "mcnemar_PERSIST_vs", "McNemar")]
    for n in ("GBM", "RF"):
        c = fx["cv"][n]
        rows.append(["Stratified 10-fold CV", NAME[n], f"{pct(c['accuracy']['mean'])} ± {pct(c['accuracy']['sd'])}",
                     nolead(c["auc"]["mean"]), nolead(c["brier"]["mean"]), num(c["log_loss"]["mean"]),
                     signed(fx["cv"]["paired_PERSIST_vs"][n]["mean_difference"]),
                     pval(fx["cv"]["paired_PERSIST_vs"][n]["p_t"])])
    for n in ("GBM", "RF"):
        r = fx["repeated_cv"][n]
        rows.append(["Repeated 10×10 CV", NAME[n], f"{pct(r['accuracy']['mean'])} ± {pct(r['accuracy']['sd'])}",
                     "—", "—", num(r["log_loss"]["mean"]), signed(r["corrected_t_PERSIST_vs"]["mean_difference"]),
                     pval(r["corrected_t_PERSIST_vs"]["p"])])
    for n in ("GBM", "RF"):
        r = fx["grouped_cv"][n]
        rows.append(["Country-grouped 10-fold CV", NAME[n], pct(r["pooled"]["accuracy"]), nolead(r["pooled"]["auc"]),
                     nolead(r["pooled"]["brier"]), num(r["pooled"]["log_loss"]),
                     signed(r["paired_PERSIST_vs"]["mean_difference"]), pval(r["paired_PERSIST_vs"]["p_t"])])
    for lab, blk, key, _ in blocks:
        n_te = blk.get("test_n", 592)
        for n in ("GBM", "RF"):
            m = blk[n][key]
            rows.append([lab, NAME[n], pct(blk[n]["accuracy"]), nolead(blk[n]["auc"]), nolead(blk[n]["brier"]),
                         num(blk[n]["log_loss"]), signed(100 * (m["n10"] - m["n01"]) / n_te), pval(m["p"])])
    return {"title": "Gradient Boosting and Random Forest Under the Seven Evaluation Regimes",
            "columns": ["Regime", "Learner", "Acc (%)", "AUC", "Brier", "Log loss", "Persistence − learner (pp)", "p"],
            "rows": rows,
            "note": ("Identical design matrix, scaling, partitions and seed as the primary learners. Tests: paired fold t "
                     "(ten-fold and grouped CV), Nadeau–Bengio corrected resampled t (repeated CV), exact McNemar "
                     "(single splits and pooled rolling origin). Positive differences favour persistence. "
                     "— = not stored for the 100 repeated resamples.")}


def table_G2(audit, results):
    fx = results["revision"]["flexible"]; rows = []
    for n in ("GBM", "RF"):
        d = fx["cv"][n]; t = fx["nested_tuning"][n]
        rows.append([NAME[n], pct(d["accuracy"]["mean"]), num(d["log_loss"]["mean"]), pct(t["accuracy"]), num(t["log_loss"]),
                     signed(t["paired_PERSIST_vs"]["mean_difference"]), pval(t["paired_PERSIST_vs"]["p_t"])])
    ch = fx["nested_tuning"]
    def fmt(g):
        return ", ".join(f"{k}={v}" for k, v in g.items())
    from collections import Counter
    mode = {n: Counter(fmt(g) for g in ch[n]["chosen"]).most_common(1)[0] for n in ("GBM", "RF")}
    return {"title": "Nested Tuning of the Flexible Learners (Stratified Ten-Fold CV)",
            "columns": ["Learner", "Default Acc (%)", "Default Log loss", "Tuned Acc (%)", "Tuned Log loss",
                        "Persistence − tuned (pp)", "p"],
            "rows": rows,
            "note": (f"Inner five-fold selection by log loss. Gradient boosting grid: depth {{2, 3, 4}} × learning rate "
                     f"{{0.05, 0.1}} × trees {{100, 300}}; most frequent choice {mode['GBM'][0]} ({mode['GBM'][1]}/10 folds). "
                     f"Random forest grid: minimum leaf size {{1, 5, 20}} × features per split {{sqrt, all}}; most frequent "
                     f"choice {mode['RF'][0]} ({mode['RF'][1]}/10 folds). p = paired fold t against persistence.")}


def table_H1(audit, results):
    rc = results["revision"]["recalibration"]; rows = []
    for scheme, lab in (("cv", "Stratified 10-fold"), ("grouped_cv", "Country-grouped 10-fold")):
        for k in ("NB_raw", "NB_platt", "NB_isotonic", "LR_raw", "LR_platt", "LR_isotonic"):
            b = rc[scheme][k]
            rows.append([lab if k == "NB_raw" else "", NAME[k], pct(b["accuracy"]), num(b["log_loss"]),
                         nolead(b["brier"]), nolead(b["ece"]), num(b["slope"], 2), f"{b['transitions_correct']}/44",
                         nolead(b["auc_uncertainty"], 3), f"{b['captured_5']}/44", f"{b['captured_10']}/44"])
    return {"title": "Recalibration of Naïve Bayes and Logistic Regression: Probabilistic Quality and Transition Ranking",
            "columns": ["CV scheme", "Model", "Acc (%)", "Log loss", "Brier", "ECE", "Slope", "Transitions correct",
                        "AUC of uncertainty", "Captured at 5%", "Captured at 10%"],
            "rows": rows,
            "note": ("Pooled out-of-fold predictions over N = 1,973. Calibration maps were learned on inner five-fold "
                     "out-of-fold scores inside each outer training partition and never saw the evaluated rows. "
                     "Platt scaling and isotonic regression act on the unsaturated score (Naïve Bayes: log posterior "
                     "odds from the joint log-likelihoods; logistic regression: linear predictor). Ranking the "
                     f"transitions by the uncalibrated Naïve Bayes |log odds| gives AUC = {nolead(rc['cv']['NB_score_rank_auc'], 3)} "
                     f"(grouped: {nolead(rc['grouped_cv']['NB_score_rank_auc'], 3)}). On the hold-out partition Platt "
                     f"recalibration moved the Naïve Bayes calibration slope from {num(rc['holdout_NB']['raw']['slope'], 2)} to "
                     f"{num(rc['holdout_NB']['platt']['slope'], 2)} and its log loss from "
                     f"{num(rc['holdout_NB']['raw']['log_loss'])} to {num(rc['holdout_NB']['platt']['log_loss'])}.")}


def table_I1(audit, results):
    a = results["revision"]["anchored_threshold"]; cv = results["cv"]["summary"]; h = results["holdout"]
    tp = results["robustness"]["temporal"]; tr = results["transitions_cv"]
    rows = [["Full-sample median (primary)", num(audit["median_threshold"], 3), str(audit["transitions"]["n"]),
             pct(cv["NB"]["accuracy"]["mean"]), pct(cv["LR"]["accuracy"]["mean"]), pct(cv["PERSIST"]["accuracy"]["mean"]),
             pct(h["LR"]["accuracy"]), pct(h["baselines"]["persistence"]["accuracy"]),
             pval(h["mcnemar"]["PERSIST_vs_LR"]["p"]), pct(tp["LR"]["accuracy"]), pct(tp["PERSIST"]["accuracy"]),
             nolead(tr["auc_uncertainty_flags_transition_LR"], 3)]]
    for k, lab in (("pre2019_anchor", "Median of 2003–2018 (prospective training years)"),
                   ("pre2010_anchor", "Median of 2003–2009 (first rolling-origin training years)")):
        b = a[k]
        rows.append([lab, num(b["tau"], 3), str(b["transitions"]), pct(b["cv"]["NB"]), pct(b["cv"]["LR"]),
                     pct(b["cv"]["PERSIST"]), pct(b["holdout"]["LR"]), pct(b["holdout"]["PERSIST"]),
                     pval(b["holdout"]["mcnemar_PERSIST_vs_LR_p"]), pct(b["prospective"]["LR"]),
                     pct(b["prospective"]["PERSIST"]), nolead(b["transitions_cv"]["LR"]["auc_uncertainty"], 3)])
    f = a["fold_specific_cv"]
    rows.append(["Median of each CV training fold", f"{num(min(f['taus']), 3)}–{num(max(f['taus']), 3)}",
                 f"{f['transitions_in_test_folds']}", pct(f["NB"]), pct(f["LR"]), pct(f["PERSIST"]),
                 "—", "—", "—", "—", "—", "—"])
    r = a["rolling_expanding_tau"]
    rows.append(["Median of all years before each rolling-origin test year",
                 f"{num(r['tau_range'][0], 3)}–{num(r['tau_range'][1], 3)}", f"{r['transitions']} (2010–2024)",
                 pct(r["NB"]), pct(r["LR"]), pct(r["PERSIST"]), "—", "—", pval(r["mcnemar_PERSIST_vs_LR"]["p"]),
                 "—", "—", "—"])
    return {"title": "Sensitivity of the Comparison to Training-Anchored Thresholds",
            "columns": ["Threshold definition", "τ", "Transitions", "CV NB Acc", "CV LR Acc", "CV Persist. Acc",
                        "Hold-out LR Acc", "Hold-out Persist. Acc", "McNemar p (Persist. vs. LR)",
                        "Prospective LR Acc", "Prospective Persist. Acc", "LR AUC of uncertainty"],
            "rows": rows,
            "note": ("Accuracies in per cent. For the two anchored medians the whole pipeline (labels, stratified hold-out, "
                     "ten-fold CV, prospective split, transition analysis) is re-run with τ fixed from the stated years, "
                     "so no label depends on a threshold computed from later years in the prospective split. In the "
                     "fold-specific and expanding-window rows τ is recomputed inside every training partition and "
                     "applied to its test rows; for the rolling origin the accuracies pool the 15 test years and the "
                     "McNemar test is on the pooled predictions. — = not applicable.")}


def table_J1(audit, results):
    m = results["revision"]["multiplicity"]; rows = []
    for r in m["rows"]:
        rows.append([r["regime"], NAME[r["learner"]], r["test"], signed(r["difference_pp"]), pval(r["p"]),
                     pval(r["p_holm"]), pval(r["p_bonferroni"])])
    return {"title": "All Persistence-Versus-Learner Accuracy Tests Across Regimes With Family-Wise Adjustment",
            "columns": ["Regime", "Learner", "Test", "Persistence − learner (pp)", "p", "p Holm", "p Bonferroni"],
            "rows": rows,
            "note": (f"One family of {m['family_size']} tests (7 regimes × 4 learners). Positive differences favour "
                     f"persistence. A learner was numerically more accurate than persistence in "
                     f"{m['n_learner_numerically_better']} of {m['family_size']} comparisons, significantly so in "
                     f"{m['n_learner_significantly_better_raw']} before and {m['n_learner_significantly_better_holm']} after "
                     f"adjustment; persistence was significantly more accurate after Holm adjustment in "
                     f"{m['n_persistence_significantly_better_holm']}.")}


def table_J2(audit, results):
    pw = results["revision"]["power"]; rows = []
    for r in pw["min_corrections_given_new_errors"]:
        rows.append(["Minimum transitions corrected for p < .05", f"{r['new_stable_errors']} new stable errors",
                     str(r["min_transitions_corrected"])])
    for n, v in pw["observed_oof"].items():
        rows.append([f"Observed out-of-fold: {NAME[n]}",
                     f"{v['stable_errors']} new stable errors; {v['transitions_corrected']} corrected",
                     f"{v['required_corrections']} corrections required for p < .05 "
                     f"({'within' if v['attainable'] else 'beyond'} the {pw['all_transitions']} transitions available)"])
    rows.append(["Ceiling on any accuracy gain over persistence", "hold-out / pooled",
                 f"{pct(pw['ceiling_gain_holdout_pp'])} / {pct(pw['ceiling_gain_pooled_pp'])} pp"])
    rows.append(["Minimal detectable difference, repeated 10×10 CV", "80% power, two-sided α = .05",
                 f"{pct(pw['repeated_cv_mdd_pp'])} pp (corrected SE {pct(pw['repeated_cv_se_pp'])})"])
    return {"title": "Power and Minimal Detectable Differences for the Paired Label Comparison",
            "columns": ["Quantity", "Condition", "Value"], "rows": rows,
            "note": ("Exact two-sided McNemar test: a learner beats persistence only by correcting transitions (n10) "
                     "faster than it adds errors on stable records (n01). Simulated power curves for the pooled "
                     "out-of-fold comparison are shown in Figure J1.")}


def table_K1(audit, results):
    e = results["revision"]["external"]; rows = []
    hb = e["hbhi"]
    rows.append(["HBHI countries (2018), labelled high", f"{sum(r['label'] == 'High' for r in hb['by_country_launch_year'])}/"
                 f"{len(hb['by_country_launch_year'])}",
                 "Low: " + ", ".join(f"{r['country']} ({num(r['rate'], 2)})" for r in hb["by_country_launch_year"]
                                     if r["label"] == "Low")])
    rows.append(["Non-HBHI countries (2018), labelled high", f"{hb['non_hbhi_high_launch_year']}/{hb['non_hbhi_launch_year']}",
                 "the rate median is broader than the HBHI list"])
    rows.append(["Transitions in HBHI countries, 2003–2024", f"{hb['transitions']}/{audit['transitions']['n']}", "—"])
    ds = e["death_share"]
    rows.append(["Agreement of the label with the 95%-of-deaths stratum", f"{pct(ds['agreement_pct'])}%",
                 f"κ = {nolead(ds['kappa'], 3)}; high/top {ds['high_and_top']}, high/other {ds['high_not_top']}, "
                 f"low/top {ds['low_and_top']}, low/other {ds['low_not_top']}"])
    rows.append(["Transitions in the 95%-of-deaths stratum", f"{ds['transitions_in_top']}/{audit['transitions']['n']}",
                 f"median {num(ds['top_countries_per_year_median'], 0)} countries per year in the stratum"])
    td = e["transition_deaths"]
    rows.append(["Estimated deaths in transition country-years", f"{num(td['deaths_total'], 0)}",
                 f"median {num(td['deaths_median'], 1)} per country-year; {num(td['share_of_sample_deaths_pct'], 3)}% of "
                 "deaths in the sample in those years"])
    ic = e["interval_check"]
    rows.append(["Transitions whose year-t interval contains τ", f"{ic['transitions_interval_contains_tau']}/{ic['transitions']}",
                 f"stable records: {ic['stable_interval_contains_tau']}/{ic['stable_n']}"])
    rc = e["reported_cases"]
    rows.append(["Reported cases rose, low-to-high transitions", f"{rc['low_to_high']['reported_cases_rose']}/{rc['low_to_high']['n']}",
                 f"stable records: {rc['stable_low']['reported_cases_rose'] + rc['stable_high']['reported_cases_rose']}/"
                 f"{rc['stable_low']['n'] + rc['stable_high']['n']}; Fisher {peq(rc['fisher_low_to_high_vs_stable_p'])}"])
    rows.append(["Reported cases fell, high-to-low transitions",
                 f"{rc['high_to_low']['n'] - rc['high_to_low']['reported_cases_rose']}/{rc['high_to_low']['n']}", "—"])
    rows.append(["Direction concordant with reported cases, all transitions",
                 f"{rc['transition_concordant']}/{rc['transition_n']}",
                 f"binomial test against .5: {peq(rc['binomial_p_vs_half'])}; years {rc['years'][0]}–{rc['years'][1]}"])
    return {"title": "External Grounding of the Burden Label and of the Class Transitions",
            "columns": ["Comparison", "Result", "Detail"], "rows": rows,
            "note": ("HBHI = WHO/RBM High Burden to High Impact countries (Burkina Faso, Cameroon, Democratic Republic of "
                     "the Congo, Ghana, India, Mali, Mozambique, Niger, Nigeria, Uganda, United Republic of Tanzania). "
                     "The 95%-of-deaths stratum contains, each year, the countries that jointly carry 95% of estimated "
                     "deaths in the sample (GHO MALARIA_EST_DEATHS). Reported cases are routine national surveillance "
                     "totals (GHO MALARIA_TOTAL_CASES, presumed plus confirmed; available 2015–2024), compared between "
                     "consecutive years.")}


def table_K2(audit, results):
    sc = results["revision"]["review_scenario"]; rows = []
    for t in sc["transition_list"]:
        rows.append([str(t["year"]), t["country"], t["direction"], num(t["prev_rate"], 2), num(t["rate"], 2),
                     num(t["p_LR"], 3), "Yes" if t["flagged_LR"] else "No", "Yes" if t["interval_contains_tau"] else "No",
                     "—" if t["est_deaths"] is None else intc(int(t["est_deaths"]))])
    return {"title": "Class Transitions in the Prospective Review Scenario, 2010–2024",
            "columns": ["Year", "Country", "Direction", "Rate t − 1", "Rate t", "LR p", f"Flagged (LR, k = {sc['k_primary']})",
                        "Interval contains τ", "Estimated deaths"],
            "rows": rows,
            "note": ("Rates in deaths per 100,000; LR p is the rolling-origin probability of high burden from a model "
                     "trained on earlier years. Estimated deaths from GHO MALARIA_EST_DEATHS. 'Interval contains τ' "
                     "marks transitions whose year-t uncertainty interval includes the threshold, i.e. class changes "
                     "that the estimates themselves do not resolve.")}


def table_L1(audit, results):
    c = results["revision"]["continuous"]; rows = []
    lab = {"RW": "Random walk on log(1 + rate)", "RWD": "Random walk with drift", "LIN": "Gaussian linear model, lagged inputs"}
    for scheme, sl in (("cv", "Stratified 10-fold CV"), ("rolling", "Rolling origin 2010–2024")):
        for n in ("RW", "RWD", "LIN"):
            b = c[scheme][n]
            rows.append([sl if n == "RW" else "", lab[n], num(b["crps"], 4), num(b["mae_log"], 4), num(b["mae_rate"], 2),
                         pct(b["pi90_coverage_pct"], 1), pct(b["class_accuracy"]), num(b["class_log_loss"]),
                         nolead(b["auc_uncertainty"], 3)])
    return {"title": "Continuous-Rate Companion: Probabilistic Forecasts of the Log Mortality Rate",
            "columns": ["Scheme", "Forecast", "CRPS", "MAE (log)", "MAE (rate)", "90% PI coverage (%)",
                        "Implied class Acc (%)", "Implied class Log loss", "AUC of uncertainty"],
            "rows": rows,
            "note": (f"Gaussian predictive distributions on log(1 + rate) with variance from training residuals; CRPS in "
                     f"log units (lower is better). The linear model improves CRPS over the random walk by "
                     f"{pct(c['cv']['crps_skill_LIN_vs_RW_pct'])}% (CV) and {pct(c['rolling']['crps_skill_LIN_vs_RW_pct'])}% "
                     f"(rolling origin). Implied class quantities use P(rate ≥ τ) from the predictive distribution; "
                     f"for comparison, the logistic-regression classifier has out-of-fold log loss "
                     f"{num(c['LR_cv_class_log_loss'])}.")}


MAIN = {"1": table_1, "2": table_2, "3": table_3, "4": table_4, "5": table_5, "6": table_6, "7": table_7, "8": table_8,
        "9": table_9, "10": table_10}
APPENDIX = {"A1": table_A1, "A2": table_A2, "B1": table_B1, "C1": table_C1, "C2": table_C2, "C3": table_C3,
            "D1": table_D1, "E1": table_E1, "E2": table_E2, "E3": table_E3, "F1": table_F1, "F2": table_F2,
            "F3": table_F3, "G1": table_G1, "G2": table_G2, "H1": table_H1, "I1": table_I1, "J1": table_J1,
            "J2": table_J2, "K1": table_K1, "K2": table_K2, "L1": table_L1}


def build_all(audit, results, write: bool = True) -> dict:
    out = {}
    for k, f in {**MAIN, **APPENDIX}.items():
        t = f(audit, results)
        out[k] = t
        if write:
            C.TABLE_DIR.mkdir(parents=True, exist_ok=True)
            with open(C.TABLE_DIR / f"table_{k}.csv", "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(t["columns"])
                w.writerows(t["rows"])
    return out
