"""Fast tests of the dataset construction, the leakage gate and the core metrics.

Run with `pytest -q` from the repository root, or directly with `python tests/test_pipeline.py`.
They take a few seconds; the full study is reproduced by scripts/run_analysis.py.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from malaria_burden import config as C  # noqa: E402
from malaria_burden.data import build_dataset, build_design_matrix, load_raw  # noqa: E402
from malaria_burden.inference import holm, mcnemar  # noqa: E402
from malaria_burden.metrics import brier, expected_calibration_error, logloss  # noqa: E402
from malaria_burden.models import persistence_rule  # noqa: E402

_RAW = load_raw()
_CLEAN, _AUDIT = build_dataset(_RAW)


def test_record_accounting():
    steps = _AUDIT["cleaning_steps"]
    assert _AUDIT["raw_rows"] == 2659
    assert [s["removed"] for s in steps] == [0, 1, 415, 270]
    assert _AUDIT["final_rows"] == 1973
    assert _AUDIT["final_countries"] == 90
    assert _AUDIT["final_year_range"] == [2003, 2024]


def test_threshold_and_balance():
    assert abs(_AUDIT["median_threshold"] - 4.88) < 1e-9
    assert _AUDIT["class_counts"] == {"High": 987, "Low": 986}


def test_leakage_gate_rejects_year_t_fields():
    X, y, features = build_design_matrix(_CLEAN)
    assert not set(features) & set(C.LEAKAGE_EXCLUDED)
    assert X.shape == (1973, 10)
    leaky = _CLEAN.copy()
    original = C.NUMERIC_PREDICTORS.copy()
    try:
        C.NUMERIC_PREDICTORS.append("MortalityRate")
        raised = False
        try:
            build_design_matrix(leaky)
        except AssertionError:
            raised = True
        assert raised, "the leakage gate must reject a year-t field"
    finally:
        C.NUMERIC_PREDICTORS[:] = original


def test_persistence_errors_are_exactly_transitions():
    pred = persistence_rule(_CLEAN["Prev_Rate"].to_numpy(), _AUDIT["median_threshold"])
    errors = pred != _CLEAN["HighBurden"].to_numpy()
    assert np.array_equal(errors.astype(int), _CLEAN["Transition"].to_numpy())
    assert int(errors.sum()) == 44


def test_lags_use_only_past_observations():
    d = _CLEAN
    assert (d["Prev_Year"] < d["Year"]).all()
    assert (d["Baseline_Year"] < d["Year"]).all()


def test_metric_definitions():
    y = np.array([0, 0, 1, 1])
    p = np.array([0.1, 0.4, 0.6, 0.9])
    assert abs(brier(y, p) - np.mean((p - y) ** 2)) < 1e-12
    assert abs(logloss(y, p) + np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))) < 1e-12
    ece, bins = expected_calibration_error(y, p)
    assert sum(b["n"] for b in bins) == 4 and ece >= 0


def test_mcnemar_and_holm():
    y = np.array([1, 1, 1, 1, 0, 0])
    a = np.array([1, 1, 1, 1, 0, 0])
    b = np.array([0, 0, 1, 1, 0, 1])
    r = mcnemar(a, b, y)
    assert (r["n01"], r["n10"]) == (0, 3)
    assert holm([0.01, 0.04, 0.03]) == [0.03, 0.06, 0.06]


def test_revision_helpers():
    from malaria_burden.revision import crps_gaussian, min_k_mcnemar, relabel
    # the exact McNemar test needs six uncontested corrections, and always more corrections than new errors
    assert min_k_mcnemar(0) == 6
    assert all(min_k_mcnemar(e) > e for e in (1, 5, 22))
    # relabelling at the primary threshold reproduces the primary labels and transitions
    d = relabel(_CLEAN, _AUDIT["median_threshold"])
    assert np.array_equal(d["HighBurden"].to_numpy(), _CLEAN["HighBurden"].to_numpy())
    assert int(d["Transition"].sum()) == 44
    # CRPS of a Gaussian forecast centred on the outcome equals sigma * (sqrt(2) - 1) / sqrt(pi)
    assert abs(float(crps_gaussian(np.array([0.0]), 0.0, 1.0)[0]) - (np.sqrt(2) - 1) / np.sqrt(np.pi)) < 1e-12


if __name__ == "__main__":
    tests = [v for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for t in tests:
        t()
        print(f"PASS  {t.__name__}")
    print(f"{len(tests)} tests passed")
